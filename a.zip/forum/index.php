<?php
session_start();

$chatFile = __DIR__ . '/pesan.json';
$configPath = __DIR__ . '/data/config.json';

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $pesan = trim($_POST['pesan'] ?? '');

    if (strlen($pesan) > 100) {
        $_SESSION['error'] = "Pesan maksimal 100 karakter!";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

    if ($nama !== '' && $pesan !== '') {
        $data = file_exists($chatFile) ? json_decode(file_get_contents($chatFile), true) : [];
        if (!is_array($data)) $data = [];

        $data[] = [
            'nama' => htmlspecialchars($nama),
            'pesan' => htmlspecialchars($pesan),
            'waktu' => date('H:i:s')
        ];

        file_put_contents($chatFile, json_encode($data, JSON_PRETTY_PRINT));
        $_SESSION['success'] = true;
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Chat Mini</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #101820;
      color: #fff;
      font-family: 'Segoe UI', sans-serif;
      padding-bottom: 100px;
    }
    .chat-container {
      max-width: 600px;
      margin: auto;
      padding-top: 30px;
    }
    .chat-box {
      background: #1c1f2b;
      border-radius: 10px;
      padding: 20px;
      max-height: 400px;
      overflow-y: auto;
      box-shadow: 0 0 5px rgba(0,0,0,0.3);
    }
    .bubble {
      padding: 10px 15px;
      background: #2f80ed;
      color: #fff;
      border-radius: 20px;
      display: inline-block;
      margin-bottom: 10px;
      max-width: 75%;
    }
    .bubble-wrap {
      margin-bottom: 15px;
    }
    .bubble-time {
      font-size: 0.75rem;
      color: #ccc;
      margin-top: 2px;
    }
    .form-chat {
      background: #1a1d26;
      padding: 20px;
      border-radius: 10px;
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      box-shadow: 0 -2px 10px rgba(0,0,0,0.4);
    }
    .form-control, .btn {
      border-radius: 10px;
    }
    .alert {
      max-width: 600px;
      margin: 10px auto;
    }
  </style>
</head>
<body>

<div class="chat-container">
  <h2 class="text-center mb-4">💬 Chat Mini</h2>

  <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
  <?php elseif (isset($_SESSION['success'])): ?>
    <div class="alert alert-success">Pesan berhasil dikirim!</div>
    <?php unset($_SESSION['success']); ?>
  <?php endif; ?>

  <div class="chat-box" id="chat-box">
    <?php
    $data = file_exists($chatFile) ? json_decode(file_get_contents($chatFile), true) : [];
    if (!is_array($data)) $data = [];

    foreach ($data as $item):
    ?>
      <div class="bubble-wrap">
        <div class="bubble"><?= htmlspecialchars($item['pesan']) ?></div><br>
        <div class="bubble-time">
          <?= htmlspecialchars($item['nama']) ?> - <?= htmlspecialchars($item['waktu']) ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Form -->
<form method="POST" class="form-chat">
  <div class="container">
    <div class="row g-2">
      <div class="col-md-4">
        <input type="text" name="nama" class="form-control bg-dark text-light" placeholder="Nama" required>
      </div>
      <div class="col-md-6">
        <input type="text" name="pesan" maxlength="100" class="form-control bg-dark text-light" placeholder="Pesan kamu..." required>
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-success w-100">Kirim</button>
      </div>
    </div>
  </div>
</form>

<script>
  // Auto scroll ke bawah
  const box = document.getElementById('chat-box');
  box.scrollTop = box.scrollHeight;
</script>
</body>
</html>