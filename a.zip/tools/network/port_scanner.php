<?php
$results = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = trim($_POST['target']);
  $common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 3306, 8080];
  if (!empty($target)) {
    foreach ($common_ports as $port) {
      $conn = @fsockopen($target, $port, $errno, $errstr, 1);
      $results[$port] = $conn ? '🟢 Open' : '🔴 Closed';
      if ($conn) fclose($conn);
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Port Scanner</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">
  <div class="container bg-white p-4 rounded shadow">
    <h2 class="mb-4">🧪 Port Scanner</h2>
    <form method="POST" class="mb-3">
      <input type="text" name="target" class="form-control" placeholder="Masukkan IP/domain, contoh: example.com" required>
      <button type="submit" class="btn btn-primary mt-3">Scan</button>
    </form>
    <?php if (!empty($results)): ?>
    <div class="mt-4">
      <label class="form-label">Hasil Scan:</label>
      <ul class="list-group">
        <?php foreach ($results as $port => $status): ?>
          <li class="list-group-item d-flex justify-content-between">
            Port <?= $port ?>
            <span><?= $status ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
    <?php endif; ?>
  </div>
</body>
</html>