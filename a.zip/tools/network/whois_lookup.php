<?php
$whoisData = '';
if (isset($_GET['domain'])) {
  $domain = trim($_GET['domain']);
  if ($domain !== '') {
    $whoisData = shell_exec("whois " . escapeshellarg($domain));
    if (!$whoisData) {
      $whoisData = "❌ Whois data tidak tersedia atau domain tidak valid.";
    }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Whois Lookup | Tools by R07</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #f8f9fa; padding-top: 40px; }
    .container { max-width: 700px; }
    .card-header, .btn-primary { background: #0d6efd; color: white; }
    pre { background: #000; color: #0f0; padding: 10px; border-radius: 5px; max-height: 400px; overflow: auto; }
  </style>
</head>
<body>
<div class="container">
  <div class="card shadow">
    <div class="card-header">
      <h4>🌐 Whois Lookup</h4>
    </div>
    <div class="card-body">
      <form method="get">
        <div class="input-group mb-3">
          <input type="text" name="domain" class="form-control" placeholder="contoh: google.com" required>
          <button type="submit" class="btn btn-primary">Cek Whois</button>
        </div>
      </form>

      <?php if ($whoisData): ?>
        <h5>Hasil untuk: <?= htmlspecialchars($domain) ?></h5>
        <pre><?= htmlspecialchars($whoisData) ?></pre>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>