
<?php
$result = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ip'])) {
    $ip = $_POST['ip'];
    $json = @file_get_contents("https://ipinfo.io/{$ip}/json");
    $result = $json ? $json : "Gagal mendapatkan informasi.";
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>IP Lookup</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #fff; font-family: monospace; }
    .card { background-color: #1e1e1e; border: 1px solid #333; }
    textarea { background: #000; color: #0f0; }
  </style>
</head>
<body>
<div class="container py-5">
  <div class="card shadow">
    <div class="card-body">
      <h3 class="text-info">🧭 IP Lookup</h3>
      <form method="POST" class="mb-3">
        <div class="input-group">
          <input type="text" name="ip" class="form-control" placeholder="Masukkan alamat IP..." required>
          <button class="btn btn-primary">Lookup</button>
        </div>
      </form>
      <?php if ($result): ?>
        <h5 class="text-warning">Hasil:</h5>
        <textarea rows="10" class="form-control" readonly><?= $result ?></textarea>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
