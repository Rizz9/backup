<!DOCTYPE html>
<html lang='en'><head><meta charset='UTF-8'><title>website_screenshot</title>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
</head><body class='p-4 bg-light'>
<div class='container bg-white p-4 rounded shadow'><h2 class='mb-4'>Website Screenshot</h2>
<p class='text-muted'>Tools ini masih tahap pengembangan. Silakan tunggu update selanjutnya.</p>
</div></body></html>