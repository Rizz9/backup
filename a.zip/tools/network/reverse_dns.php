
<?php
$result = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ip'])) {
    $ip = $_POST['ip'];
    $host = gethostbyaddr($ip);
    $result = $host ? $host : "Tidak ditemukan.";
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Reverse DNS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #fff; font-family: monospace; }
    .card { background-color: #1e1e1e; border: 1px solid #333; }
    .output-box { background: #000; color: #0f0; padding: 10px; border-radius: 5px; }
  </style>
</head>
<body>
<div class="container py-5">
  <div class="card shadow">
    <div class="card-body">
      <h3 class="text-info">🕵️ Reverse DNS Lookup</h3>
      <form method="POST" class="mb-3">
        <div class="input-group">
          <input type="text" name="ip" class="form-control" placeholder="Masukkan IP address..." required>
          <button class="btn btn-primary">Lookup</button>
        </div>
      </form>
      <?php if ($result): ?>
        <h5 class="text-warning">Hasil:</h5>
        <div class="output-box"><?= htmlspecialchars($result) ?></div>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
