<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = rtrim($_POST['target'], '/') . '/sitemap.xml';
  $xml = @file_get_contents($target);

  echo "<div class='mt-4'>";
  if ($xml && strpos($xml, '<url>') !== false) {
    preg_match_all('/<loc>(.*?)<\/loc>/', $xml, $matches);
    $results = array_filter($matches[1], function($url) {
      return preg_match('/author=|/author\//', $url);
    });

    if (!empty($results)) {
      echo "<h5 class='text-warning'>🔍 Ditemukan kemungkinan URL user/author:</h5><ul class='text-light'>";
      foreach ($results as $r) echo "<li>$r</li>";
      echo "</ul>";
    } else {
      echo "<div class='text-success'>Tidak ditemukan informasi user dari sitemap.</div>";
    }
  } else {
    echo "<div class='text-danger'>Sitemap tidak ditemukan atau tidak bisa diakses.</div>";
  }
  echo "</div>";
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>WP Enumeration via Sitemap</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #f8f9fa; }
    .terminal { font-family: monospace; background: #1e1e1e; padding: 20px; border-radius: 10px; }
  </style>
</head>
<body>
<div class="container py-5">
  <h3 class="text-warning">🗺️ WP Enumeration via Sitemap</h3>
  <form method="POST" id="sitemapForm">
    <div class="mb-3">
      <input type="url" name="target" class="form-control" placeholder="Masukkan URL target, contoh: https://example.com" required>
    </div>
    <button class="btn btn-warning">Cek Sitemap</button>
  </form>
  <div id="result" class="terminal mt-4"></div>
</div>
<script>
document.getElementById('sitemapForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  document.getElementById('result').innerHTML = '<span class="text-info">Memproses sitemap...</span>';
  const formData = new FormData(this);
  const res = await fetch('', { method: 'POST', body: formData });
  document.getElementById('result').innerHTML = await res.text();
});
</script>
</body>
</html>
