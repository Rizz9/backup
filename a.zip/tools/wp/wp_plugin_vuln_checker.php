<?php
$plugin_vulns = [
  'revslider' => 'CVE-2014-9734 - Arbitrary File Upload',
  'wp-file-manager' => 'CVE-2020-25213 - Unauthenticated File Upload',
  'duplicator' => 'CVE-2020-11738 - Sensitive File Disclosure',
  'easy-wp-smtp' => 'CVE-2020-35234 - Option Update Vulnerability',
  'themegrill-demo-importer' => 'CVE-2020-8417 - Unauthenticated Reset'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = rtrim($_POST['target'], '/');
  $found = [];

  foreach ($plugin_vulns as $plugin => $vuln) {
    $url = $target . "/wp-content/plugins/$plugin/";
    $headers = @get_headers($url);
    if ($headers && strpos($headers[0], '200') !== false) {
      $found[] = ['name' => $plugin, 'vuln' => $vuln];
    }
  }

  echo "<div class='mt-4'>";
  if (!empty($found)) {
    echo "<h5 class='text-warning'>Plugin Rentan Ditemukan:</h5><ul>";
    foreach ($found as $item) {
      echo "<li class='text-light'><strong>{$item['name']}</strong>: {$item['vuln']}</li>";
    }
    echo "</ul>";
  } else {
    echo "<div class='text-success'>Tidak ditemukan plugin rentan umum di target ini.</div>";
  }
  echo "</div>";
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>WP Plugin Vulnerability Checker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #f8f9fa; }
    .terminal { font-family: monospace; background: #1e1e1e; padding: 20px; border-radius: 10px; }
  </style>
</head>
<body>
<div class="container py-5">
  <h3 class="text-warning">⚠️ WP Plugin Vulnerability Checker</h3>
  <form method="POST" id="vulnForm">
    <div class="mb-3">
      <input type="url" name="target" class="form-control" placeholder="Masukkan URL target, contoh: https://example.com" required>
    </div>
    <button class="btn btn-danger">Cek Plugin Rentan</button>
  </form>
  <div id="result" class="terminal mt-4"></div>
</div>
<script>
document.getElementById('vulnForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  const res = await fetch('', { method: 'POST', body: formData });
  document.getElementById('result').innerHTML = await res.text();
});
</script>
</body>
</html>
