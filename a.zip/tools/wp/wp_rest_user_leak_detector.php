<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = rtrim($_POST['target'], '/') . '/wp-json/wp/v2/users';
  $data = @file_get_contents($target);

  echo "<div class='mt-4'>";
  if ($data && strpos($data, 'name') !== false) {
    $users = json_decode($data, true);
    if (is_array($users)) {
      echo "<h5 class='text-danger'>User leak ditemukan melalui REST API:</h5><ul>";
      foreach ($users as $user) {
        echo "<li class='text-light'>Username: <strong>{$user['slug']}</strong> | Nama: {$user['name']}</li>";
      }
      echo "</ul>";
    } else {
      echo "<div class='text-warning'>Data user tidak bisa diproses.</div>";
    }
  } else {
    echo "<div class='text-success'>REST API tidak membocorkan user.</div>";
  }
  echo "</div>";
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>WP REST API User Leak Detector</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #f8f9fa; }
    .terminal { font-family: monospace; background: #1e1e1e; padding: 20px; border-radius: 10px; }
  </style>
</head>
<body>
<div class="container py-5">
  <h3 class="text-info">🔍 WP REST API User Leak Detector</h3>
  <form method="POST" id="restForm">
    <div class="mb-3">
      <input type="url" name="target" class="form-control" placeholder="Masukkan URL target, contoh: https://example.com" required>
    </div>
    <button class="btn btn-info">Cek REST API</button>
  </form>
  <div id="result" class="terminal mt-4"></div>
</div>
<script>
document.getElementById('restForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  const res = await fetch('', { method: 'POST', body: formData });
  document.getElementById('result').innerHTML = await res.text();
});
</script>
</body>
</html>
