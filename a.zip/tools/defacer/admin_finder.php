<?php
// Admin Finder by R07 🛡️
$common_paths = [
  "admin", "admin/login", "cpanel", "admin.php", "login.php", "administrator", "admin/index.php","login"
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $base = rtrim($_POST['url'], '/') . '/';
  $result = "<ul>";
  foreach ($common_paths as $path) {
    $full = $base . $path;
    $headers = @get_headers($full);
    if ($headers && strpos($headers[0], '200') !== false) {
      $result .= "<li><b style='color:red'>Ditemukan:</b> <a href='$full' target='_blank'>$full</a></li>";
    } else {
      $result .= "<li><code>$full</code> ❌</li>";
    }
  }
  $result .= "</ul>";
} else {
  $result = '';
}
?><!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Admin Page Finder</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-dark text-light">
<div class="container py-5">
  <div class="card bg-secondary text-light shadow">
    <div class="card-body">
      <h4 class="card-title">🔐 Admin Page Finder</h4>
      <form method="post" class="mb-3">
        <input type="text" name="url" class="form-control mb-2" placeholder="http://target.com/" required>
        <button class="btn btn-warning">Cari</button>
      </form>
      <?= $result ?>
    </div>
  </div>
</div>
</body></html>
