<?php
// Backup File Finder by R07 🛡️
$exts = ['.zip', '.bak', '.tar', '.tar.gz', '.rar', '.old'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $base = rtrim($_POST['url'], '/');
  $paths = ['index', 'wp-config', 'db', 'site', 'backup', 'website'];
  $result = "<ul>";
  foreach ($paths as $name) {
    foreach ($exts as $ext) {
      $test = $base . '/' . $name . $ext;
      $headers = @get_headers($test);
      if ($headers && strpos($headers[0], '200') !== false) {
        $result .= "<li><b style='color:red'>Ditemukan:</b> <a href='$test' target='_blank'>$test</a></li>";
      } else {
        $result .= "<li><code>$test</code> ❌</li>";
      }
    }
  }
  $result .= "</ul>";
} else {
  $result = '';
}
?><!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Backup File Finder</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-dark text-light">
<div class="container py-5">
  <div class="card bg-secondary text-light shadow">
    <div class="card-body">
      <h4 class="card-title">🗂️ Backup File Finder</h4>
      <form method="post" class="mb-3">
        <input type="text" name="url" class="form-control mb-2" placeholder="http://target.com" required>
        <button class="btn btn-warning">Scan</button>
      </form>
      <?= $result ?>
    </div>
  </div>
</div>
</body></html>
