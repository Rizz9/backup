<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $allowAll = isset($_POST['allow_all']);
    $disallowAll = isset($_POST['disallow_all']);
    $blockBots = $_POST['block_bots'] ?? [];
    $sitemap = trim($_POST['sitemap']);

    $output = "User-agent: *\n";

    if ($allowAll) {
        $output .= "Disallow:\n";
    } elseif ($disallowAll) {
        $output .= "Disallow: /\n";
    }

    foreach ($blockBots as $bot) {
        $output .= "User-agent: $bot\nDisallow: /\n";
    }

    if ($sitemap !== '') {
        $output .= "\nSitemap: $sitemap\n";
    }

    header('Content-Type: text/plain');
    header('Content-Disposition: attachment; filename="robots.txt"');
    echo $output;
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>robots.txt Generator</title>
  <style>
    body { background: #1e1e2f; color: #fff; font-family: sans-serif; padding: 20px; }
    input, label, button, textarea { display:block; margin: 10px 0; width:100%; max-width:500px; }
    .checkboxes label { display: block; margin: 5px 0; }
  </style>
</head>
<body>
  <h2>🤖 robots.txt Generator</h2>
  <form method="POST">
    <label><input type="checkbox" name="allow_all"> Allow All Bots</label>
    <label><input type="checkbox" name="disallow_all"> Disallow All Bots</label>

    <div class="checkboxes">
      <strong>❌ Block Specific Bots:</strong>
      <label><input type="checkbox" name="block_bots[]" value="Googlebot"> Googlebot</label>
      <label><input type="checkbox" name="block_bots[]" value="Bingbot"> Bingbot</label>
      <label><input type="checkbox" name="block_bots[]" value="Yandex"> Yandex</label>
      <label><input type="checkbox" name="block_bots[]" value="Baiduspider"> Baiduspider</label>
      <label><input type="checkbox" name="block_bots[]" value="AhrefsBot"> AhrefsBot</label>
      <label><input type="checkbox" name="block_bots[]" value="MJ12bot"> MJ12bot</label>
    </div>

    <label>Sitemap URL (optional):</label>
    <input type="text" name="sitemap" placeholder="https://yourdomain.com/sitemap.xml">

    <button type="submit">🎯 Generate robots.txt</button>
  </form>
</body>
</html>