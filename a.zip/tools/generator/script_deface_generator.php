<?php
$hasil = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = htmlspecialchars($_POST['title'] ?? '');
    $message = htmlspecialchars($_POST['message'] ?? '');
    $bgcolor = $_POST['bgcolor'] ?? '#000000';
    $textcolor = $_POST['textcolor'] ?? '#FF0000';

    $hasil = "<html>\n<head><title>" . $title . "</title></head>\n<body style=\"background-color:$bgcolor; color:$textcolor; text-align:center;\">\n<h1>$title</h1>\n<p>$message</p>\n</body>\n</html>";
}
?><!DOCTYPE html><html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Script Deface Generator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-light">
<div class="container py-5">
    <h1 class="text-center mb-4">💀 Script Deface Generator</h1>
    <form method="post" class="card p-4 bg-secondary border-0 rounded-4 shadow">
        <div class="mb-3">
            <label class="form-label">Judul Halaman</label>
            <input type="text" name="title" class="form-control" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Pesan</label>
            <textarea name="message" class="form-control" rows="4" required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Background Color</label>
                <input type="color" name="bgcolor" class="form-control form-control-color" value="<?= $_POST['bgcolor'] ?? '#000000' ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Text Color</label>
                <input type="color" name="textcolor" class="form-control form-control-color" value="<?= $_POST['textcolor'] ?? '#FF0000' ?>">
            </div>
        </div>
        <button type="submit" class="btn btn-danger">Generate Script</button>
    </form><?php if ($hasil): ?>
    <div class="card mt-4 p-4 bg-secondary border-0 rounded-4 shadow">
        <h5 class="mb-3">📄 Hasil Script HTML:</h5>
        <textarea class="form-control bg-dark text-light" rows="10" readonly><?= htmlspecialchars($hasil) ?></textarea>
    </div>
<?php endif; ?>

</div>
</body>
</html>