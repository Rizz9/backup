// Efek Ketik Terminal Footer
const teks = "© COPYRIGHT BY RYZZ";
let i = 0;
let isDeleting = false;
const el = document.getElementById("terminal");

function typeLoop() {
  if (!el) return;
  if (!isDeleting) {
    el.textContent = teks.substring(0, i);
    i++;
    if (i > teks.length) {
      isDeleting = true;
      setTimeout(typeLoop, 1000);
      return;
    }
  } else {
    el.textContent = teks.substring(0, i);
    i--;
    if (i < 0) {
      isDeleting = false;
      setTimeout(typeLoop, 500);
      return;
    }
  }
  setTimeout(typeLoop, 100);
}
typeLoop();

// Jam
setInterval(() => {
  const now = new Date();
  const clockEl = document.getElementById('clock');
  if (clockEl) clockEl.textContent = now.toLocaleTimeString();
}, 1000);

// Auto Show Offcanvas di Desktop
window.addEventListener('load', function () {
  if (window.innerWidth >= 992) {
    const offcanvasEl = document.getElementById('menuTools');
    if (offcanvasEl) {
      const bsOffcanvas = new bootstrap.Offcanvas(offcanvasEl);
      bsOffcanvas.show();
    }
  }
});

// Tutup Offcanvas di Mobile
document.addEventListener('DOMContentLoaded', function () {
  const hamburger = document.querySelector('[data-bs-toggle="offcanvas"]');
  const checkerPanel = document.querySelector('#offcanvasDarkNavbar');
  if (hamburger && checkerPanel) {
    checkerPanel.classList.remove("show");
  }
});

// Toggle Widget Chat AI
let widgetOpen = false;
function toggleChatWidget() {
  const iframe = document.getElementById("chat-iframe");
  const notif = document.getElementById("notif-dot");
  widgetOpen = !widgetOpen;

  if (iframe) iframe.style.display = widgetOpen ? "block" : "none";
  if (notif && widgetOpen) notif.style.display = "none";
}

// Modal Welcome Otomatis
document.addEventListener("DOMContentLoaded", function () {
  const welcomeModalEl = document.getElementById('welcomeModal');
  if (welcomeModalEl) {
    const welcomeModal = new bootstrap.Modal(welcomeModalEl);
    welcomeModal.show();
  }
});

// Card Aktif (klik)
const cards = document.querySelectorAll('.card-clickable');
cards.forEach(card => {
  card.addEventListener('click', () => {
    cards.forEach(c => c.classList.remove('active'));
    card.classList.add('active');
  });
});