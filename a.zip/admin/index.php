<?php
session_start();

// === KONFIGURASI ADMIN ===
$configFile = __DIR__ . '../../data/config.json';
if (!file_exists($configFile)) {
    file_put_contents($configFile, json_encode([
        'username' => 'rizki',
        'password' => password_hash('rizki@123', PASSWORD_DEFAULT),
        'max_upload_kb' => 1024
    ]));
}
$config = json_decode(file_get_contents($configFile), true);

// === LOGIN HANDLER ===
if (isset($_POST['login'])) {
    if ($_POST['user'] == $config['username'] && password_verify($_POST['pass'], $config['password'])) {
        $_SESSION['admin'] = true;
        $_SESSION['admin_name'] = 'OWNER';
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $error = "Login gagal!";
    }
}

// === LOGOUT ===
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// === UPDATE PENGATURAN ===
if (isset($_POST['update']) && isset($_SESSION['admin'])) {
    $config['username'] = $_POST['user'];
    if (!empty($_POST['new_pass'])) {
        $config['password'] = password_hash($_POST['new_pass'], PASSWORD_DEFAULT);
    }
    $config['max_upload_kb'] = (int)$_POST['max'];
    file_put_contents($configFile, json_encode($config));
    $msg = "Pengaturan disimpan.";
}

// === UPLOAD FILE ===
$uploadDir = realpath(__DIR__ . '/../upl');
if (isset($_FILES['file']) && isset($_SESSION['admin'])) {
    $file = $_FILES['file'];
    $maxSize = $config['max_upload_kb'] * 1024;
    if ($file['size'] <= $maxSize) {
        move_uploaded_file($file['tmp_name'], $uploadDir . '/' . basename($file['name']));
        $msg = "Upload sukses.";
    } else {
        $error = "Ukuran file terlalu besar.";
    }
}

// === ZIP SEMUA FILE ===
if (isset($_POST['zip']) && isset($_SESSION['admin'])) {
    $zip = new ZipArchive();
    $zipPath = $uploadDir . '/all_files.zip';
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        foreach (scandir($uploadDir) as $f) {
            if ($f != '.' && $f != '..') {
                $zip->addFile($uploadDir . '/' . $f, $f);
            }
        }
        $zip->close();
        $msg = "Semua file berhasil di-zip.";
    } else {
        $error = "Gagal membuat ZIP.";
    }
}

// === UNZIP FILE ===
if (isset($_FILES['unzip']) && isset($_SESSION['admin'])) {
    $zipFile = $_FILES['unzip']['tmp_name'];
    $zip = new ZipArchive();
    if ($zip->open($zipFile)) {
        $zip->extractTo($uploadDir);
        $zip->close();
        $msg = "Unzip sukses.";
    } else {
        $error = "File ZIP tidak valid.";
    }
}

// === DELETE, RENAME, DOWNLOAD ===
if (isset($_GET['del']) && isset($_SESSION['admin'])) {
    unlink($uploadDir . '/' . basename($_GET['del']));
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
if (isset($_POST['rename']) && isset($_SESSION['admin'])) {
    $old = $uploadDir . '/' . $_POST['old'];
    $new = $uploadDir . '/' . $_POST['new'];
    rename($old, $new);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
if (isset($_GET['dl']) && isset($_SESSION['admin'])) {
    $f = $uploadDir . '/' . basename($_GET['dl']);
    header("Content-Disposition: attachment; filename=" . basename($f));
    readfile($f);
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light text-dark p-3">
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>🛠️ Admin Panel</h3>
        <?php if (isset($_SESSION['admin'])): ?>
            <div>
                <button class="btn btn-outline-secondary me-2" data-bs-toggle="modal" data-bs-target="#chatModal">💬 Pesan</button>
                <a href="?logout" class="btn btn-danger">Logout</a>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!isset($_SESSION['admin'])): ?>
        <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <form method="post">
            <input class="form-control mb-2" name="user" placeholder="Username">
            <input class="form-control mb-2" name="pass" type="password" placeholder="Password">
            <button class="btn btn-primary" name="login">Login</button>
        </form>
    <?php else: ?>
        <form method="post" class="mb-4">
            <input class="form-control mb-2" name="user" value="<?= htmlspecialchars($config['username']) ?>">
            <input class="form-control mb-2" name="new_pass" placeholder="Password Baru">
            <input class="form-control mb-2" name="max" value="<?= $config['max_upload_kb'] ?>">
            <button class="btn btn-success" name="update">Simpan</button>
        </form>
        <form method="post" enctype="multipart/form-data" class="mb-3">
            <input type="file" name="file" class="form-control mb-2">
            <button class="btn btn-primary">Upload</button>
        </form>
        <form method="post" enctype="multipart/form-data" class="mb-3">
            <input type="file" name="unzip" class="form-control mb-2">
            <button class="btn btn-dark">Unzip File</button>
        </form>
        <form method="post" class="mb-3">
            <button class="btn btn-warning" name="zip">Zip Semua File</button>
        </form>

        <h5>📁 File Admin</h5>
        <table class="table table-bordered bg-white text-dark">
            <tr><th>Nama File</th><th>Aksi</th></tr>
            <?php foreach (scandir($uploadDir) as $f): if ($f == '.' || $f == '..') continue; ?>
            <tr>
                <td><?= htmlspecialchars($f) ?></td>
                <td>
                    <a href="?dl=<?= urlencode($f) ?>" class="btn btn-sm btn-info">Download</a>
                    <a href="?del=<?= urlencode($f) ?>" class="btn btn-sm btn-danger">Delete</a>
                    <a href="<?= '../upl/' . urlencode($f) ?>" class="btn btn-sm btn-secondary" target="_blank">View</a>
                    <form method="post" class="d-inline">
                        <input type="hidden" name="old" value="<?= htmlspecialchars($f) ?>">
                        <input type="text" name="new" placeholder="Rename" required>
                        <button name="rename" class="btn btn-sm btn-outline-primary">OK</button>
                    </form>
                </td>
            </tr>
            <?php endforeach ?>
        </table>

        <?php if (isset($msg)) echo "<div class='alert alert-success'>$msg</div>"; ?>
        <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
    <?php endif ?>
</div>

<!-- Modal Pesan -->
<div class="modal fade" id="chatModal" tabindex="-1" aria-labelledby="chatModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content bg-white text-dark">
      <div class="modal-header">
        <h5 class="modal-title" id="chatModalLabel">💬 Obrolan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body">
        <iframe src="../forum.php" width="100%" height="400" style="border:none;"></iframe>
      </div>
    </div>
  </div>
</div>

</body>
</html>