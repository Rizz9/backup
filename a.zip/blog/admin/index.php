<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
  header("Location: ../login");
  exit;
}

$posts = file_exists('../data/posts.json') ? json_decode(file_get_contents('../data/posts.json'), true) : [];
$comments = file_exists('../data/comments.json') ? json_decode(file_get_contents('../data/comments.json'), true) : [];
$counter = file_exists('../data/counter.txt') ? intval(file_get_contents('../data/counter.txt')) : 0;

// Hitung total komentar
$totalKomentar = 0;
foreach ($comments as $koms) {
  $totalKomentar += count($koms);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css">
  <style>
    .profile-icon {
      width: 32px; height: 32px;
      border-radius: 50%;
      background: url('https://i.pravatar.cc/32') no-repeat center/cover;
      border: 2px solid #dee2e6;
      position: relative;
    }
    .profile-icon.online::after {
      content: '';
      width: 10px; height: 10px;
      background: limegreen;
      border: 2px solid #fff;
      border-radius: 50%;
      position: absolute;
      bottom: 0; right: 0;
    }
    #profileCard {
      animation: fadeInDown 0.3s ease-in-out;
    }
    @keyframes fadeInDown {
      0% { opacity: 0; transform: translateY(-10px); }
      100% { opacity: 1; transform: translateY(0); }
    }
    .card-hover {
      transition: all 0.3s ease-in-out;
    }
    .card-hover:hover {
      transform: translateY(-5px);
      background-color: #f8f9fa;
      border-color: #0d6efd;
      box-shadow: 0 0 12px rgba(13, 110, 253, 0.3);
    }
  </style>
</head>
<body class="bg-light text-dark">
<nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm border-bottom">
  <div class="container-fluid d-flex justify-content-between align-items-center">
    <!-- Kiri: Hamburger + Brand -->
    <div class="d-flex align-items-center">
      <button class="navbar-toggler border border-dark me-2" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand fw-bold m-0 text-dark" href="#">Dashboard</a>
    </div>

    <!-- Kanan: Profile -->
    <div class="d-flex align-items-center gap-3">
      <div class="position-relative">
        <div class="profile-icon online" id="profileToggle" style="cursor: pointer;"></div>
        <div id="profileCard" class="card shadow-sm position-absolute end-0 mt-2" style="width: 220px; display: none; z-index: 999;">
          <div class="card-body text-center">
            <img src="https://i.pravatar.cc/80" class="rounded-circle mb-3" width="80" height="80" alt="Profile">
            <div class="d-grid gap-2">
              <a href="../login/ganti_username.php" class="btn btn-warning btn-sm">✏️ Ganti Username</a>
              <a href="../login/ganti_password.php" class="btn btn-danger btn-sm">🔐 Ganti Password</a>
              <a href="../login/logout.php" class="btn btn-outline-secondary btn-sm">🚪 Logout</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Menu -->
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="tambah.php">➕ Tambah Postingan</a></li>
        <li class="nav-item"><a class="nav-link" href="kelola.php">🗂️ Kelola Postingan</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-5 mt-5">
  <h1 class="mb-4">📊 Dashboard</h1>
  <div class="row">
    <div class="col-md-4 mb-4" data-aos="zoom-in">
      <div class="card card-hover shadow-sm border-0 h-100 text-center">
        <div class="card-body">
          <i class="bi bi-journal-text fs-1 text-primary mb-2"></i>
          <h5 class="card-title">Jumlah Postingan</h5>
          <p class="card-text fs-4"><?= count($posts) ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4 mb-4" data-aos="zoom-in" data-aos-delay="100">
      <div class="card card-hover shadow-sm border-0 h-100 text-center">
        <div class="card-body">
          <i class="bi bi-chat-left-text fs-1 text-success mb-2"></i>
          <h5 class="card-title">Jumlah Komentar</h5>
          <p class="card-text fs-4"><?= $totalKomentar ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4 mb-4" data-aos="zoom-in" data-aos-delay="200">
      <div class="card card-hover shadow-sm border-0 h-100 text-center">
        <div class="card-body">
          <i class="bi bi-people fs-1 text-danger mb-2"></i>
          <h5 class="card-title">Jumlah Pengunjung</h5>
          <p class="card-text fs-4"><?= $counter ?></p>
        </div>
      </div>
    </div>
  </div>
</div>

<footer class="footer bg-white text-center text-muted py-3 border-top mt-auto">
  © <?= date('Y') ?> Admin Panel RizDev.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();
  const profileToggle = document.getElementById('profileToggle');
  const profileCard = document.getElementById('profileCard');
  profileToggle.addEventListener('click', () => {
    profileCard.style.display = profileCard.style.display === 'block' ? 'none' : 'block';
  });
  document.addEventListener('click', function(event) {
    if (!profileToggle.contains(event.target) && !profileCard.contains(event.target)) {
      profileCard.style.display = 'none';
    }
  });
</script>
</body>
</html>