<?php
session_start();
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
  header("Location: ../admin/index.php");
  exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $user = $_POST['username'] ?? '';
  $pass = $_POST['password'] ?? '';
  $userFile = '../data/user.json';

  if (file_exists($userFile)) {
    $data = json_decode(file_get_contents($userFile), true);
    if ($user === $data['username'] && $pass === $data['password']) {
      $_SESSION['login'] = true;
      header("Location: index.php");
      exit;
    } else {
      $error = "Username atau password salah!";
    }
  } else {
    $error = "File user.json tidak ditemukan!";
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center justify-content-center" style="height: 100vh;">
  <form method="post" class="p-4 bg-white shadow rounded" style="min-width: 300px;">
    <h4 class="mb-3 text-center">🔐 Login Admin</h4>
    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    <div class="mb-3">
      <input type="text" name="username" class="form-control" placeholder="Username" required>
    </div>
    <div class="mb-3">
      <input type="password" name="password" class="form-control" placeholder="Password" required>
    </div>
    <button type="submit" class="btn btn-primary w-100">Login</button>
  </form>
</body>
</html>