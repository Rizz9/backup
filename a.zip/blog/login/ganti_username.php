<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
  header("Location: index.php");
  exit;
}

$userFile = '../data/user.json';
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $newUser = trim($_POST['username'] ?? '');
  $password = $_POST['password'] ?? '';

  if (file_exists($userFile)) {
    $userData = json_decode(file_get_contents($userFile), true);

    if ($password === $userData['password']) {
      $userData['username'] = $newUser;
      file_put_contents($userFile, json_encode($userData, JSON_PRETTY_PRINT));
      $success = "✅ Username berhasil diganti!";
    } else {
      $error = "❌ Password salah!";
    }
  } else {
    $error = "❌ File user.json tidak ditemukan!";
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Ganti Username</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css">
  <style>
    .profile-icon {
      width: 32px; height: 32px;
      border-radius: 50%;
      background: url('https://i.pravatar.cc/32') no-repeat center/cover;
      border: 2px solid #dee2e6;
      position: relative;
    }
    .profile-icon.online::after {
      content: ''; width: 10px; height: 10px;
      background: limegreen; border: 2px solid #fff;
      border-radius: 50%; position: absolute;
      bottom: 0; right: 0;
    }
    #profileCard {
      animation: fadeInDown 0.3s ease-in-out;
    }
    @keyframes fadeInDown {
      0% { opacity: 0; transform: translateY(-10px); }
      100% { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body class="bg-light text-dark">
<nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm border-bottom">
  <div class="container-fluid d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center">
      <button class="navbar-toggler border border-dark me-2" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand fw-bold m-0 text-dark" href="index.php">Dashboard</a>
    </div>
    <div class="d-flex align-items-center gap-3">
      <div class="position-relative">
        <div class="profile-icon online" id="profileToggle" style="cursor: pointer;"></div>
        <div id="profileCard" class="card shadow-sm position-absolute end-0 mt-2" style="width: 220px; display: none; z-index: 999;">
          <div class="card-body text-center">
            <img src="https://i.pravatar.cc/80" class="rounded-circle mb-3" width="80" height="80" alt="Profile">
            <div class="d-grid gap-2">
              <a href="ganti_username.php" class="btn btn-warning btn-sm">✏️ Ganti Username</a>
              <a href="ganti_password.php" class="btn btn-danger btn-sm">🔐 Ganti Password</a>
              <a href="logout.php" class="btn btn-outline-secondary btn-sm">🚪 Logout</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="tambah.php">➕ Tambah Postingan</a></li>
        <li class="nav-item"><a class="nav-link" href="kelola.php">🗂️ Kelola Postingan</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-5 mt-5">
  <h2 class="mb-4">✏️ Ganti Username</h2>
  <?php if ($success): ?>
    <div class="alert alert-success"><?= $success ?></div>
  <?php elseif ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <form method="post" class="card shadow-sm p-4" data-aos="zoom-in">
    <div class="mb-3">
      <label for="username" class="form-label">Username Baru</label>
      <input type="text" name="username" id="username" class="form-control" required>
    </div>
    <div class="mb-3">
      <label for="password" class="form-label">Password Saat Ini</label>
      <input type="password" name="password" id="password" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();
  const profileToggle = document.getElementById('profileToggle');
  const profileCard = document.getElementById('profileCard');
  profileToggle.addEventListener('click', () => {
    profileCard.style.display = profileCard.style.display === 'block' ? 'none' : 'block';
  });
  document.addEventListener('click', function(event) {
    if (!profileToggle.contains(event.target) && !profileCard.contains(event.target)) {
      profileCard.style.display = 'none';
    }
  });
</script>
</body>
</html>