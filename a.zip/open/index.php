<meta http-equiv="refresh" content="0;url=https://rizxdev.ct.ws">


<h1 style="color : red;> YOUR ACCOUNT HAS BEN SUSPEND!!!!!! REDIRECT TO RIZXDEV</h1>