<?php
date_default_timezone_set('Asia/Jakarta');

// Ambil daftar kota dari API
$kota = json_decode(file_get_contents("https://api.myquran.com/v2/sholat/kota/semua"), true);
$semuaKota = $kota['data'] ?? [];

// Proses pilihan lokasi
$lokasiDipilih = $_GET['lokasi'] ?? 'jakarta';

// Ambil jadwal berdasarkan kota
$jadwal = json_decode(file_get_contents("https://api.myquran.com/v2/sholat/jadwal/$lokasiDipilih/" . date("Y/m/d")), true);
$jadwal = $jadwal['data']['jadwal'] ?? [];

function isWaktuAdzan($jam) {
    $now = strtotime(date('H:i'));
    $jadwal = strtotime($jam);
    return abs($now - $jadwal) <= 300; // 5 menit toleransi
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Jadwal Adzan Real-time</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f8f9fa;
      padding: 10px;
      font-family: sans-serif;
    }
    .card-adzan {
      transition: 0.3s;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
      margin-bottom: 10px;
    }
    .card-adzan:hover {
      transform: scale(1.01);
      box-shadow: 0 3px 12px rgba(0,0,0,0.1);
    }
    .active-adzan {
      background-color: #d1e7dd !important;
      border-left: 5px solid #198754;
    }
    @media (min-width: 768px) {
      body {
        max-width: 400px;
        margin: auto;
      }
    }
  </style>
</head>
<body>

<div class="mb-3">
  <form method="GET">
    <label class="form-label">Pilih Lokasi</label>
    <select name="lokasi" class="form-select" onchange="this.form.submit()">
      <?php foreach ($semuaKota as $k): ?>
        <option value="<?= $k['id'] ?>" <?= $lokasiDipilih == $k['id'] ? 'selected' : '' ?>>
          <?= ucwords($k['lokasi']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<h5 class="mb-3">Jadwal Adzan Hari Ini (<?= strtoupper(htmlspecialchars($lokasiDipilih)) ?>)</h5>

<?php if (!$jadwal): ?>
  <div class="alert alert-warning">Gagal memuat jadwal adzan. Lokasi mungkin tidak ditemukan.</div>
<?php else: ?>
  <?php foreach ($jadwal as $nama => $jam): ?>
    <?php if ($nama === "tanggal") continue; ?>
    <div class="card card-adzan <?= isWaktuAdzan($jam) ? 'active-adzan' : '' ?>">
      <div class="card-body">
        <h6 class="card-title mb-1"><?= ucfirst($nama) ?></h6>
        <p class="card-text mb-0"><strong><?= $jam ?></strong></p>
        <?php if (isWaktuAdzan($jam)): ?>
          <small class="text-success">Sedang Adzan</small>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

</body>
</html>