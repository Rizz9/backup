<?php
// Fungsi untuk fetch API
function getApi($url) {
    $data = @file_get_contents($url);
    return $data ? json_decode($data, true) : null;
}

$idSurat = $_GET['surat'] ?? null;
$idTafsir = $_GET['tafsir'] ?? null;
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Al-Quran Digital</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f4f6f9;
      font-family: 'Segoe UI', sans-serif;
      font-size: 14px;
    }
    .card {
      margin-bottom: 10px;
      border-left: 4px solid #0d6efd;
      transition: 0.3s;
    }
    .card:hover {
      transform: scale(1.02);
      box-shadow: 0 0 10px rgba(0,0,0,0.08);
    }
    .ayat {
      border-bottom: 1px dashed #ccc;
      padding: 8px 0;
    }
    pre {
      white-space: pre-wrap;
    }
    h4, h5 {
      font-size: 1.1rem;
    }
    p {
      margin: 0;
    }
    @media (min-width: 768px) {
      .container {
        max-width: 600px;
      }
    }
  </style>
</head>
<body>
<div class="container mt-3">
  <h4 class="mb-4 text-center">📖 Al-Quran Digital</h4>

  <?php if ($idSurat): ?>
    <?php
    $surah = getApi("https://equran.id/api/v2/surat/$idSurat");
    if ($surah):
    ?>
      <div class="card shadow-sm">
        <div class="card-body">
          <h5><?= $surah['data']['namaLatin'] ?> (<?= $surah['data']['nama'] ?>)</h5>
          <p class="text-muted">Jumlah ayat: <?= $surah['data']['jumlahAyat'] ?></p>
          <hr>
          <?php foreach ($surah['data']['ayat'] as $a): ?>
            <div class="ayat">
              <b><?= $a['nomorAyat'] ?>.</b>
              <p style="font-size: 18px"><?= $a['teksArab'] ?></p>
              <small><?= $a['teksLatin'] ?></small><br>
              <small><i><?= $a['teksIndonesia'] ?></i></small>
            </div>
          <?php endforeach; ?>
          <a href="quran.php?tafsir=<?= $idSurat ?>" class="btn btn-outline-primary btn-sm mt-3">Lihat Tafsir</a>
          <a href="quran.php" class="btn btn-secondary btn-sm mt-3">⬅ Kembali</a>
        </div>
      </div>
    <?php else: ?>
      <div class="alert alert-danger">Surat tidak ditemukan.</div>
    <?php endif; ?>

  <?php elseif ($idTafsir): ?>
    <?php
    $tafsir = getApi("https://equran.id/api/v2/tafsir/$idTafsir");
    if ($tafsir):
    ?>
      <div class="card shadow-sm">
        <div class="card-body">
          <h5>Tafsir: <?= $tafsir['data']['namaLatin'] ?> (<?= $tafsir['data']['nama'] ?>)</h5>
          <hr>
          <?php foreach ($tafsir['data']['tafsir'] as $t): ?>
            <div class="mb-3">
              <b>Ayat <?= $t['ayat'] ?>:</b>
              <p><?= nl2br($t['teks']) ?></p>
            </div>
          <?php endforeach; ?>
          <a href="quran.php?surat=<?= $idTafsir ?>" class="btn btn-outline-primary btn-sm mt-3">⬅ Kembali ke Surah</a>
        </div>
      </div>
    <?php else: ?>
      <div class="alert alert-danger">Tafsir tidak ditemukan.</div>
    <?php endif; ?>

  <?php else: ?>
    <?php
    $list = getApi("https://equran.id/api/v2/surat");
    if ($list && isset($list['data'])):
    ?>
      <div class="row">
        <?php foreach ($list['data'] as $surat): ?>
          <div class="col-12">
            <div class="card shadow-sm">
              <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                  <h6 class="mb-1"><?= $surat['nomor'] ?>. <?= $surat['namaLatin'] ?> <span class="text-muted">(<?= $surat['nama'] ?>)</span></h6>
                  <small class="text-muted"><?= $surat['arti'] ?> - <?= $surat['jumlahAyat'] ?> ayat</small>
                </div>
                <div class="text-end">
                  <a href="?surat=<?= $surat['nomor'] ?>" class="btn btn-sm btn-primary">📖</a>
                  <a href="?tafsir=<?= $surat['nomor'] ?>" class="btn btn-sm btn-outline-secondary">🧠</a>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="alert alert-danger">Gagal mengambil daftar surat.</div>
    <?php endif; ?>
  <?php endif; ?>

</div>
</body>
</html>