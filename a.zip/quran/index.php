<?php
// Counter pengunjung
$counter_file = "counter.txt";
$pengunjung = 1;
if (file_exists($counter_file)) {
    $pengunjung = (int)file_get_contents($counter_file) + 1;
}
file_put_contents($counter_file, $pengunjung);

// Online checker
session_start();
$_SESSION['last_activity'] = time();
$online_file = "online.json";
$online_data = file_exists($online_file) ? json_decode(file_get_contents($online_file), true) : [];
$time = time();
foreach ($online_data as $ip => $lastSeen) {
    if ($time - $lastSeen > 60) unset($online_data[$ip]);
}
$ip_user = $_SERVER['REMOTE_ADDR'];
$online_data[$ip_user] = $time;
file_put_contents($online_file, json_encode($online_data));
$pengunjung_online = count($online_data);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Al-Qur'an Online - RizxDev</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { font-size: 0.9rem; background: #f8f9fa; }
    .card { padding: 0.5rem; margin-bottom: 0.8rem; }
    .card-title { font-size: 1rem; margin-bottom: .5rem; }
    .card-body p { font-size: 0.85rem; margin-bottom: 0.4rem; }
    .navbar-brand { font-size: 1rem; }
    .list-group-item { font-size: 0.9rem; padding: .5rem .75rem; }
    .modal-content { font-size: 0.9rem; }
    footer { font-size: 0.85rem; }
  </style>
</head>
<body>

<nav class="navbar navbar-dark bg-primary px-3 py-2">
  <button class="navbar-toggler me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#">RizxDev Qur'an</a>
  <div class="ms-auto">
    <i class="bi bi-chat-right-dots-fill text-white" data-bs-toggle="modal" data-bs-target="#infoModal" style="cursor:pointer;"></i>
  </div>
</nav>

<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasMenu">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title">Menu</h5>
    <button class="btn-close" data-bs-dismiss="offcanvas"></button>
  </div>
  <div class="offcanvas-body">
    <ul class="list-group">
      <a href="quran.php" class="list-group-item"><i class="bi bi-book"></i> Al-Qur'an</a>
      <a href="adzan.php" class="list-group-item"><i class="bi bi-clock"></i> Jadwal Adzan</a>
      <a href="hadist.php" class="list-group-item"><i class="bi bi-journal-richtext"></i> Hadist</a>
      <hr>
      <a href="https://rizxdev.ct.ws" class="list-group-item"><i class="bi bi-tools"></i> Tools Online</a>
      <a href="https://rizxshared.ct.ws" class="list-group-item"><i class="bi bi-hdd-network"></i> Shared Hosting</a>
      <a href="https://rizxdev.ct.ws/upl/" class="list-group-item"><i class="bi bi-upload"></i> Uploader</a>
      <a href="https://rizxdesign.ct.ws" class="list-group-item"><i class="bi bi-camera-video"></i> Hack Cam</a>
      <a href="https://rizxcode.ct.ws" class="list-group-item"><i class="bi bi-code-slash"></i> Code Editor</a>
      <a href="https://rizxblog.ct.ws" class="list-group-item"><i class="bi bi-journal"></i> My Blog</a>
      <a href="https://rizxdev.ct.ws/forum" class="list-group-item"><i class="bi bi-chat-dots"></i> Forum</a>
    </ul>
  </div>
</div>

<div class="modal fade" id="infoModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content text-dark">
      <div class="modal-header">
        <h5 class="modal-title">Informasi</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p>Jam: <span id="popupJam"></span></p>
        <p>Hari: <span id="popupHari"></span></p>
        <p>Source code? WhatsApp 087776353541</p>
      </div>
    </div>
  </div>
</div>
<br>
<center>
 <h5> [ + ] HARI DAN WAKTU [ + ] </h5>
</center>
<div class="container my-3 px-2" style="max-width: 600px;">
  <div class="row g-2">
    <div class="col-6">
      <div class="card shadow">
        <div class="card-body">
          <h5 class="card-title"><i class="bi bi-clock-history"></i> JAM</h5>
          <p id="jam"></p>
        </div>
      </div>
    </div>
    <div class="col-6">
      <div class="card shadow">
        <div class="card-body">
          <h5 class="card-title"><i class="bi bi-calendar3"></i> HARI</h5>
          <p id="hari"></p>
        </div>
      </div>
    </div>
<center>
<h5> [ + ] MENU ISLAMIC [ + ] </h5>
</center>
    <div class="col-6">
      <div class="card shadow text-center"><div class="card-body"><a href="quran.php" class="text-decoration-none"><i class="bi bi-book"></i> Al-Qur'an</a></div></div>
    </div>
    <div class="col-6">
      <div class="card shadow text-center"><div class="card-body"><a href="hadist.php" class="text-decoration-none"><i class="bi bi-journal"></i> Hadist</a></div></div>
    </div>
    <div class="col-12">
      <div class="card shadow text-center"><div class="card-body"><a href="adzan.php" class="text-decoration-none"><i class="bi bi-broadcast-pin"></i> Jadwal Adzan</a></div></div>
    </div>
<center>
 <h5> [ + ] INFORMASI [ + ] </h5>
</center>
    <div class="col-12">
      <div class="card shadow">
        <div class="card-body">
          <h5><i class="bi bi-info-circle"></i> Info Anda</h5>
          <p><i class="bi bi-globe"></i> IP: <?= $_SERVER['REMOTE_ADDR'] ?></p>
          <p><i class="bi bi-person-circle"></i> Total: <?= $pengunjung ?></p>
          <p><i class="bi bi-person-video3"></i> Online: <?= $pengunjung_online ?></p>
        </div>
      </div>
    </div>
<center>
 <h5> [ + ] INFORMASI SELANJUTNYA [ + ] </h5>
</center>
    <div class="col-12"><div class="card shadow text-center"><div class="card-body"><p><i class="bi bi-lightning-charge-fill"></i><br>Layanan Al-Qur'an Online | Created by Rizxdev</p></div></div></div>
    <div class="col-12"><div class="card shadow text-center"><div class="card-body"><p><i class="bi bi-terminal"></i><br>Tools Online, Hack Cam, dan lainnya</p></div></div></div>
  </div>
</div>

<footer class="bg-dark text-white text-center py-2 mt-3">Copyright by RizxDev</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function updateTime() {
  const now = new Date();
  document.getElementById('jam').innerText = now.toLocaleTimeString();
  document.getElementById('popupJam').innerText = now.toLocaleTimeString();
  const tgl = now.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  document.getElementById('hari').innerText = tgl;
  document.getElementById('popupHari').innerText = tgl;
}
setInterval(updateTime, 1000); updateTime();
</script>
</body>
</html>