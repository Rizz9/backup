<?php
$msg = '';
$fileCount = 0;
$uploadDir = __DIR__;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $extAllow = ['txt', 'html'];
    $fileName = $_FILES['file']['name'];
    $tmpName = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if (!in_array($fileExt, $extAllow)) {
        $msg = "<div class='alert alert-danger'>❌ Ekstensi tidak diizinkan! (hanya .txt & .html)</div>";
    } elseif ($fileSize > 2 * 1024 * 1024) {
        $msg = "<div class='alert alert-danger'>❌ File terlalu besar. Max 2MB!</div>";
    } else {
        $targetPath = $uploadDir . '/' . basename($fileName);
        if (move_uploaded_file($tmpName, $targetPath)) {
            $msg = "<div class='alert alert-success'>✅ Upload berhasil: <code>$fileName</code></div>";
        } else {
            $msg = "<div class='alert alert-danger'>❌ Upload gagal!</div>";
        }
    }
}

foreach (scandir($uploadDir) as $f) {
    if (!is_dir($f) && !in_array($f, [basename(__FILE__), '.htaccess']) && in_array(pathinfo($f, PATHINFO_EXTENSION), ['txt', 'html'])) {
        $fileCount++;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Uploader R07 - Dark</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #121212;
      color: #f8f9fa;
      font-family: 'Segoe UI', sans-serif;
    }
    .navbar, .modal-content, .card {
      background-color: #1e1e1e !important;
      color: #f8f9fa;
    }
    .dropzone {
      border: 2px dashed #0d6efd;
      border-radius: 12px;
      padding: 40px;
      background: #2c2c2c;
      text-align: center;
      color: #bbb;
      cursor: pointer;
      transition: 0.3s;
    }
    .dropzone:hover {
      background: #333;
    }
    .table {
      color: #white;
    }
    .table th, .table td {
      background-color: #white;
    }
    .table-secondary {
      background-color: #white !important;
      color: #white;
    }
    .info-box {
      position: fixed;
      top: 80px;
      right: 10px;
      width: 280px;
      z-index: 999;
      display: none;
      background-color: #2c2c2c;
    }
    .notif-dot {
      position: absolute;
      top: -4px;
      right: -4px;
      width: 10px;
      height: 10px;
      background: red;
      border-radius: 50%;
      animation: pulse 1.5s infinite;
    }
    @keyframes pulse {
      0% { transform: scale(0.9); opacity: 1; }
      100% { transform: scale(1.5); opacity: 0; }
    }
  </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark px-3">
  <span class="navbar-brand fw-bold">Uploader R07</span>
  <div>
    <button class="btn btn-secondary position-relative me-2" onclick="toggleNotif()">🔔
      <span class="notif-dot"></span>
    </button>
    <button class="btn btn-secondary" onclick="toggleInfoBox()">☰ Info</button>
  </div>
</nav>

<div class="container mt-4">
  <h3 class="mb-3">Free upload your file html txt</h3>
  <p style="color: white;">Allowed: <code>.txt</code> and <code>.html</code></p>

  <?= $msg ?>

  <form method="post" enctype="multipart/form-data" id="dropForm">
    <label class="dropzone" for="fileInput">
      📁 PILIH FILE LU ONLY HTML TXT
      <input type="file" name="file" id="fileInput" class="d-none" onchange="document.getElementById('dropForm').submit()">
    </label>
  </form>

  <h5 class="mt-5">📂 File List</h5>
  <table class="table table-bordered table-hover">
    <thead class="table-secondary">
      <tr><th>Name</th><th>Size</th><th>Action</th></tr>
    </thead>
    <tbody>
<?php
$dir = __DIR__;
$allowed_ext = ['txt', 'html'];
foreach (scandir($dir) as $file) {
  if ($file === basename(__FILE__) || is_dir($file) || pathinfo($file, PATHINFO_EXTENSION) === 'php') continue;
  $size = filesize($file);
  $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
  echo "<tr><td>" . htmlspecialchars($file) . "</td><td>" . $size . " B</td><td>";
  if (in_array($ext, $allowed_ext)) {
    echo "<a href='?download=" . urlencode($file) . "' class='btn btn-sm btn-success'>📥 Download</a> ";
    echo "<a href='" . htmlspecialchars($file) . "' target='_blank' class='btn btn-sm btn-info'>🌐 Open</a>";
  } else {
    echo "<span class='text-muted'>No access</span>";
  }
  echo "</td></tr>";
}
?>
    </tbody>
  </table>
</div>

<!-- Info Box -->
<div class="card shadow info-box border" id="infoBox">
  <div class="card-body">
    <h6 class="card-title">🔍 Info Pengguna</h6>
    <p>🌐 <strong>IP:</strong> <?= $_SERVER['REMOTE_ADDR'] ?></p>
    <p>📱 <strong>UA:</strong> <?= $_SERVER['HTTP_USER_AGENT'] ?></p>
    <p>📁 <strong>Upload Count:</strong> <?= $fileCount ?></p>
    <p>🔐 <a href="../admin" class="btn btn-sm btn-outline-light">Login Admin</a></p>
  </div>
</div>

<!-- Notif Modal -->
<div class="modal fade" id="notifModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content text-light bg-dark">
      <div class="modal-header border-secondary">
        <h5 class="modal-title">🔔 Update Terbaru</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p>🚀 Tools diperbarui pada: <strong>26 Juni 2025</strong></p>
        <ul>
          <li>Dark mode support</li>
          <li>Drag & drop upload</li>
          <li>Notifikasi update 🔔</li>
         <br><br>
         <li>UPLOAD FILE LU HASIL CODINGAN LU HASIL KARYA LU APAPUN HASIL NYA UPLOAD DISINI </li>
        </ul>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  function toggleInfoBox() {
    const box = document.getElementById('infoBox');
    box.style.display = box.style.display === 'none' ? 'block' : 'none';
  }
  function toggleNotif() {
    const notif = new bootstrap.Modal(document.getElementById('notifModal'));
    notif.show();
  }
</script>
</body>
</html>