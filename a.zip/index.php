<?php
$counterFile = 'counter.txt';
if (!file_exists($counterFile)) {
    file_put_contents($counterFile, '0');
}
$count = (int)file_get_contents($counterFile);
$count++;
file_put_contents($counterFile, $count);
?>

<?php
function getOS() {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $os_array = array(
        '/windows nt 10/i'     => 'Windows 10',
        '/windows nt 6.3/i'    => 'Windows 8.1',
        '/windows nt 6.2/i'    => 'Windows 8',
        '/windows nt 6.1/i'    => 'Windows 7',
        '/windows nt 6.0/i'    => 'Windows Vista',
        '/windows nt 5.1/i'    => 'Windows XP',
        '/macintosh|mac os x/i'=> 'Mac OS X',
        '/linux/i'             => 'Linux',
        '/android/i'           => 'Android',
        '/iphone|ipad/i'       => 'iOS'
    );
    foreach ($os_array as $regex => $value) {
        if (preg_match($regex, $user_agent)) {
            return $value;
        }
    }
    return 'Unknown';
}

function getBrowser() {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];

    // Urutan penting (dari paling spesifik ke umum)
    $browser_array = array(
        '/edg/i'               => 'Microsoft Edge',
        '/opr\/|opera/i'       => 'Opera',
        '/chrome/i'            => 'Google Chrome',
        '/safari/i'            => 'Safari',
        '/firefox/i'           => 'Mozilla Firefox',
        '/msie|trident/i'      => 'Internet Explorer',
        '/ucbrowser/i'         => 'UC Browser',
        '/instagram/i'         => 'Instagram In-App',
        '/facebook/i'          => 'Facebook In-App',
        '/tiktok/i'            => 'TikTok In-App',
        '/mobile/i'            => 'Mobile Browser'
    );

    foreach ($browser_array as $regex => $browser) {
        if (preg_match($regex, $user_agent)) {
            return $browser;
        }
    }

    return 'Tidak diketahui'; // fallback
}
?>

<!DOCTYPE html>
<html lang="en">
 <head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1" name="viewport"/>
  <!-- Bootstrap Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <title>
   Tools Online | Mr.R07
  </title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="style.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js">
  </script>
  

</head>
 <body class="pb-5">
  <nav class="navbar navbar-expand-lg navbar-dark shadow-sm px-3">
   <div class="container-fluid d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center gap-2">
     <button class="btn btn-outline-light" data-bs-target="#menuTools" data-bs-toggle="offcanvas" type="button">
      <span class="navbar-toggler-icon">
      </span>
     </button>
     <span class="fw-bold fs-5 text-white">
      Home
     </span>
    </div>
    <div class="d-flex align-items-center gap-3">
     <div class="position-relative">
      <button class="btn btn-outline-light" data-bs-target="#pesanAdmin" data-bs-toggle="modal" type="button">
       💬
      </button>
      <span class="notif-dot">
      </span>
     </div>
     <div class="dropdown">
      <a class="d-flex align-items-center" data-bs-toggle="dropdown" href="#" id="profileDropdown">
       <div class="avatar">
       </div>
      </a>
      <ul class="dropdown-menu dropdown-menu-end shadow bg-dark text-white">
       <li>
        <h6 class="dropdown-header">
         📞
         <a class="text-info" href="https://wa.me/6287776353541">
          WA Admin
         </a>
        </h6>
       </li>
       <li>
        <a class="dropdown-item text-white" href="/admin">
         🚪 Login
        </a>
       </li>
      </ul>
     </div>
    </div>
   </div>
  </nav>
 <!-- OFFCANVAS MENU -->
  <div class="offcanvas offcanvas-start text-white" id="menuTools" tabindex="-1">
   <div class="offcanvas-header">
    <h5 class="offcanvas-title">
     🧰 Semua Tools
    </h5>
    <button class="btn-close btn-close-white" data-bs-dismiss="offcanvas" type="button">
    </button>
   </div>
   <div class="offcanvas-body">
    <div class="accordion" id="accordionTools">
     <!-- Checker Tools -->
     <div class="accordion-item bg-dark text-white">
      <h2 class="accordion-header">
       <button class="accordion-button bg-dark text-white" data-bs-target="#checker" data-bs-toggle="collapse">
        🧪 Checker Tools
       </button>
      </h2>
      <div class="accordion-collapse collapse" id="checker">
       <div class="accordion-body">
        <ul class="list-group list-group-flush">
         <li class="list-group-item">
          <a href="tools/network/asn_lookup.php">
           ASN Lookup
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/cloudflare_checker.php">
           Cloudflare Checker
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/da_pa_checker.php">
           DA/PA Checker
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/dns_lookup.php">
           DNS Lookup
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/hsts_checker.php">
           HSTS Checker
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/html_validator.php">
           HTML Validator
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/http_header_checker.php">
           HTTP Header Checker
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/http_headers_viewer.php">
           HTTP Headers Viewer
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/http_status_checker.php">
           HTTP Status Checker
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/ip.php">
           IP Info
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/ip_lookup.php">
           IP Lookup
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/open_port_checker.php">
           Open Port Checker
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/pagespeed_checker.php">
           Pagespeed Checker
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/ping_tool.php">
           Ping Tool
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/port_scanner.php">
           Port Scanner
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/reverse_dns.php">
           Reverse DNS
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/ssl_checker.php">
           SSL Checker
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/subdomain_checker.php">
           Subdomain Checker
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/subdomain_finder.php">
           Subdomain Finder
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/tcp_ping.php">
           TCP Ping
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/website_screenshot.php">
           Website Screenshot
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/network/whois_lookup.php">
           Whois Lookup
          </a>
         </li>
        </ul>
       </div>
      </div>
     </div>
    <!-- DEFACER -->
<div class="accordion-item bg-dark text-white">
  <h2 class="accordion-header">
    <button class="accordion-button collapsed bg-dark text-white" data-bs-target="#df" data-bs-toggle="collapse">
      🖥️ Deface Tools
    </button>
  </h2>
  <div class="accordion-collapse collapse" id="df">
    <div class="accordion-body">
      <ul class="list-group list-group-flush">
        <li class="list-group-item">
          <a href="/tools/wp/admin_finder.php" class="text-decoration-none text-light" target="_blank">
            admin finder
          </a>
        </li>
          <li class="list-group-item">
          <a href="/tools/defacer/csrf_online.php" class="text-decoration-none text-light" target="_blank">
            csrf online
          </a>
        </li>
           <li class="list-group-item">
          <a href="/tools/defacer/perl_alfa.php" class="text-decoration-none text-light" target="_blank">
            Perl Alfa rce
          </a>
        </li>
            <li class="list-group-item">
          <a href="/tools/defacer/admin_finder.php" class="text-decoration-none text-light" target="_blank">
            sqli scanner
          </a>
        </li>
            <li class="list-group-item">
          <a href="/tools/defacer/xss_scanner.php" class="text-decoration-none text-light" target="_blank">
            xss scanner
          </a>
        </li>
         <li class="list-group-item">
          <a href="/tools/defacer/rfi_exploiter.php" class="text-decoration-none text-light" target="_blank">
            rfi exploiter
          </a>
        </li>
           <li class="list-group-item">
          <a href="/tools/defacer/lfi_scanner.php" class="text-decoration-none text-light" target="_blank">
            lfi scanner
          </a>
        </li>
          <li class="list-group-item">
          <a href="/tools/defacer/backup_finder.php" class="text-decoration-none text-light" target="_blank">
            backup finder
          </a>
        </li>
      </ul>
    </div>
  </div>
</div>
     <!-- WP Tools Start -->
<div class="accordion-item bg-dark text-white">
      <h2 class="accordion-header">
       <button class="accordion-button collapsed bg-dark text-white" data-bs-target="#wp" data-bs-toggle="collapse">
        📂 Tools wp
       </button>
      </h2>
<div class="accordion-collapse collapse" id="wp">
       <div class="accordion-body">
        <ul class="list-group list-group-flush">
    <div class="card-body">
               <li class="list-group-item">
        <a href="/tools/wp/wp_author_enum.php" class="text-decoration-none text-light" target="_blank">WP Author Enum</a></li>
             <li class="list-group-item"><a href="/tools/wp/wp_backup_file_finder.php" class="text-decoration-none text-light" target="_blank">WP Backup File Finder</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_config_exposure_checker.php" class="text-decoration-none text-light" target="_blank">WP Config Exposure</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_debug_mode_checker.php" class="text-decoration-none text-light" target="_blank"> WP Debug Mode Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_default_cred_checker.php" class="text-decoration-none text-light" target="_blank">WP Default Credential Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_deff_checker.php" class="text-decoration-none text-light" target="_blank"> WP Deff Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_directory_listing_checker.php" class="text-decoration-none text-light" target="_blank"> WP Directory Listing Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_install_checker.php" class="text-decoration-none text-light" target="_blank">WP Install Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_leak.php" class="text-decoration-none text-light" target="_blank">  WP Leak Checker</a></li>
                 <li class="list-group-item"> <a href="/tools/wp/wp_license_checker.php" class="text-decoration-none text-light" target="_blank"> WP License Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_login_bruteforce_tool.php" class="text-decoration-none text-light" target="_blank">WP Login Bruteforce Tool</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_login_header_exposure.php" class="text-decoration-none text-light" target="_blank"> WP Login Header Exposure</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_pingback_enabled_checker.php" class="text-decoration-none text-light" target="_blank">WP Pingback Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_plugin_detector.php" class="text-decoration-none text-light" target="_blank"> WP Plugin Detector</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_plugin_exposure_checker.php" class="text-decoration-none text-light" target="_blank"> WP Plugin Exposure Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_plugin_vuln_checker.php" class="text-decoration-none text-light" target="_blank">WP Plugin Vuln Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_readme_exposure_checker.php" class="text-decoration-none text-light" target="_blank">WP Readme Exposure</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_readme_finder.php" class="text-decoration-none text-light" target="_blank"> WP Readme Finder</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_rest_api_checker.php" class="text-decoration-none text-light" target="_blank">WP REST API Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_rest_user_leak_detector.php" class="text-decoration-none text-light" target="_blank"> WP REST User Leak</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_robots_checker.php" class="text-decoration-none text-light" target="_blank"> WP Robots.txt Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_sitemap_checker.php" class="text-decoration-none text-light" target="_blank">WP Sitemap Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_sitemap_enum.php" class="text-decoration-none text-light" target="_blank"> WP Sitemap Enum</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_theme_detector.php" class="text-decoration-none text-light" target="_blank"> WP Theme Detector</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_user_avatar_finder.php" class="text-decoration-none text-light" target="_blank"> WP User Avatar Finder</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_user_enum.php" class="text-decoration-none text-light" target="_blank">WP User Enumeration</a></li>
                 <li class="list-group-item"> <a href="/tools/wp/wp_version_detector.php" class="text-decoration-none text-light" target="_blank">WP Version Detector</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wp_xmlrpc_checker.php" class="text-decoration-none text-light" target="_blank">WP XMLRPC Checker</a></li>
                 <li class="list-group-item"><a href="/tools/wp/wpbf_tester.php" class="text-decoration-none text-light" target="_blank">WP BruteForce Tester</a></li>
      </ul>
    </div>
  </div>
</div>

<!-- WP Tools End -->
     <!-- Generator -->
     <div class="accordion-item bg-dark text-white">
      <h2 class="accordion-header">
       <button class="accordion-button collapsed bg-dark text-white" data-bs-target="#generator" data-bs-toggle="collapse">
        🧪 Generator Tools
       </button>
      </h2>
      <div class="accordion-collapse collapse" id="generator">
       <div class="accordion-body">
        <ul class="list-group list-group-flush">
         <li class="list-group-item">
          <a href="tools/generator/hash_generator.php">
           Hash Generator
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/generator/encode_decode.php">
           Encode/Decode
          </a>
         </li>
         <li class="list-group-item">
          <a href="tools/generator/script_deface_generator.php">
           Script Deface Generator
          </a>
         </li>
           <li class="list-group-item">
          <a href="/tools/generator/jso.php" class="text-decoration-none text-light" target="_blank">
            jso generator
          </a>
        </li>
      <a href="/tools/generator/htaccess.php" class="text-decoration-none text-light" target="_blank">
            htaccess generator
          </a>
        </li>
      <a href="/tools/generator/robots.php" class="text-decoration-none text-light" target="_blank">
            robots generator 
          </a>
        </li>
      <a href="/tools/generator/shell_enc.php" class="text-decoration-none text-light" target="_blank">
            Shell Obfuscated
          </a>
        </li>
        </ul>
       </div>
      </div>
     </div>
     <!-- Uploader -->
     <div class="accordion-item bg-dark text-white">
      <h2 class="accordion-header">
       <button class="accordion-button collapsed bg-dark text-white" data-bs-target="#uploader" data-bs-toggle="collapse">
        📤 Uploader
       </button>
      </h2>
      <div class="accordion-collapse collapse" id="uploader">
       <div class="accordion-body">
        <ul class="list-group list-group-flush">
         <li class="list-group-item">
          <a href="upl">
           Uploader
          </a>
         </li>
        </ul>
       </div>
      </div>
     </div>
    </div>
   </div>
</div>
  <!-- MODAL PESAN ADMIN -->
  <div class="modal fade" id="pesanAdmin" tabindex="-1">
   <div class="modal-dialog">
    <div class="modal-content shadow">
     <div class="modal-header">
      <h5 class="modal-title">
       📢 Pesan Admin
      </h5>
      <button class="btn-close btn-close-white" data-bs-dismiss="modal" type="button">
      </button>
     </div>
     <div class="modal-body">
      <p>
       Welcome minasan!. Tools masih tahap pengembangan ya bro. Saran &amp; kritik? Langsung aja WA admin 🙌
      </p>
     </div>
    </div>
   </div>
  </div>
  <br/>
 <div class="container mt-4">
  <div class="text-center mb-4">
    <div class="alert alert-success">
      <h5>Selamat Datang</h5>
    </div>
  </div>
<br>

  <h4 class="text-center mb-4">Informasi Anda</h4>
  <div class="row g-3">


    <!-- IP Address -->
    <div class="col-md-6">
      <div class="card shadow-sm border-0 bg-white rounded">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-wifi fs-1 text-primary me-3"></i>
          <div>
            <h6 class="mb-0 text-muted">IP Anda</h6>
            <strong class="text-primary"><?= $_SERVER['REMOTE_ADDR'] ?></strong>
          </div>
        </div>
      </div>
    </div>

    <!-- Browser -->
    <div class="col-md-6">
      <div class="card shadow-sm border-0 bg-white rounded">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-globe2 fs-1 text-danger me-3"></i>
          <div>
            <h6 class="mb-0 text-muted">Browser</h6>
            <strong class="text-danger">
              <?php
                $ua = $_SERVER['HTTP_USER_AGENT'];
                if (strpos($ua, 'Chrome') !== false) echo 'Chrome';
                elseif (strpos($ua, 'Firefox') !== false) echo 'Firefox';
                elseif (strpos($ua, 'Safari') !== false) echo 'Safari';
                elseif (strpos($ua, 'Edge') !== false) echo 'Edge';
                else echo 'Tidak diketahui';
              ?>
            </strong>
          </div>
        </div>
      </div>
    </div>

    <!-- Visitor Hari Ini -->
    <div class="col-md-6">
      <div class="card shadow-sm border-0 bg-white rounded">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-people-fill fs-1 text-success me-3"></i>
          <div>
            <h6 class="mb-0 text-muted">Visitor Hari Ini</h6>
            <strong class="text-success"><?= file_get_contents('counter.txt') ?></strong>
          </div>
        </div>
      </div>
    </div>

    <!-- Hostname -->
    <div class="col-md-6">
      <div class="card shadow-sm border-0 bg-white rounded">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-cloud fs-1 text-info me-3"></i>
          <div>
            <h6 class="mb-0 text-muted">Hostname</h6>
            <strong class="text-info"><?= gethostbyaddr($_SERVER['REMOTE_ADDR']) ?></strong>
          </div>
        </div>
      </div>
    </div>

    <!-- OS -->
    <div class="col-md-6">
      <div class="card shadow-sm border-0 bg-white rounded">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-cpu fs-1 text-danger me-3"></i>
          <div>
            <h6 class="mb-0 text-muted">OS Anda</h6>
            <strong class="text-danger"><?= PHP_OS ?></strong>
          </div>
        </div>
      </div>
    </div>

    <!-- Perangkat -->
    <div class="col-md-6">
      <div class="card shadow-sm border-0 bg-white rounded">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-phone fs-1 text-secondary me-3"></i>
          <div>
            <h6 class="mb-0 text-muted">Perangkat</h6>
            <strong class="text-secondary">
              <?= strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false ? 'Mobile' : 'Komputer / Laptop' ?>
            </strong>
          </div>
        </div>
      </div>
    </div>

    <!-- Jam -->
    <div class="col-md-6">
  <div class="card shadow-sm border-0 bg-white rounded hover-border">
    <div class="card-body d-flex align-items-center">
      <i class="bi bi-clock-fill fs-1 text-warning me-3"></i>
      <div>
        <h6 class="mb-0 text-muted">Jam</h6>
        <strong class="text-warning" id="clock">00:00:00</strong>
      </div>
    </div>
  </div>
</div>
     
  </div>
</div>

<!-- Info Selengkapnya -->
<div class="container mt-5">
  <div class="text-center mb-4">
    <div class="alert alert-success">
      <h5 class="text-muted">INFO SELENGKAPNYA</h5>
    </div>
  </div>

  <div class="row g-4">

    <!-- CODE -->
    <div class="col-md-4">
      <div class="card text-center shadow-sm border-0 bg-white rounded">
        <div class="card-body">
          <div class="mb-3">
            <div class="bg-light rounded-circle d-inline-flex p-3 shadow-sm">
              <i class="bi bi-code-slash fs-2 text-primary"></i>
            </div>
          </div>
          <h5 class="card-title text-muted fw-bold">CODE</h5>
          <p class="card-text text-muted small">DIBUAT DENGAN PERPADUAN PHP / HTML / CSS</p>
        </div>
      </div>
    </div>

    <!-- FORUM -->
    <div class="col-md-4">
      <div class="card text-center shadow-sm border-0 bg-white rounded">
        <div class="card-body">
          <div class="mb-3">
            <div class="bg-light rounded-circle d-inline-flex p-3 shadow-sm">
              <i class="bi bi-chat-left-text fs-2 text-primary"></i>
            </div>
          </div>
          <h5 class="card-title text-muted fw-bold">FORUM OBROLAN</h5>
          <p class="card-text text-muted small">MASUK KE FORUM OBROLAN</p>
          <a href="/forum" class="btn btn-gradient w-100 text-muted"><i class="bi bi-box-arrow-up-right me-1"></i> FORUM</a>
        </div>
      </div>
    </div>

    <!-- ARTIKEL -->
    <div class="col-md-4">
      <div class="card text-center shadow-sm border-0 bg-white rounded">
        <div class="card-body">
          <div class="mb-3">
            <div class="bg-light rounded-circle d-inline-flex p-3 shadow-sm">
              <i class="bi bi-menu-up fs-2 text-primary"></i>
            </div>
          </div>
          <h5 class="card-title text-muted fw-bold">ARTIKEL</h5>
          <p class="card-text text-muted small">KUNJUNGI JUGA ARTIKEL RIZXDEV</p>
          <a href="/blog" class="btn btn-gradient w-100 text-muted"><i class="bi bi-box-arrow-up-right me-1"></i> KUNJUNGI</a>
        </div>
      </div>
    </div>

    <!-- HACK KAMERA -->
    <div class="col-md-4">
      <div class="card text-center shadow-sm border-0 bg-white rounded">
        <div class="card-body">
          <div class="mb-3">
            <div class="bg-light rounded-circle d-inline-flex p-3 shadow-sm">
              <i class="bi bi-diagram-3-fill fs-2 text-primary"></i>
            </div>
          </div>
          <h5 class="card-title text-muted fw-bold">HACK KAMERA</h5>
          <p class="card-text text-muted small">BIKIN LINK HACK CAMERA DAN TRACK DATA</p>
          <a href="https://rizxdesign.ct.ws" class="btn btn-gradient w-100 text-muted"><i class="bi bi-box-arrow-up-right me-1"></i> DISINI</a>
        </div>
      </div>
    </div>


    <!-- EDITOR -->
    <div class="col-md-4">
      <div class="card text-center shadow-sm border-0 bg-white rounded">
        <div class="card-body">
          <div class="mb-3">
            <div class="bg-light rounded-circle d-inline-flex p-3 shadow-sm">
              <i class="bi bi-braces fs-2 text-primary"></i>
            </div>
          </div>
          <h5 class="card-title text-muted fw-bold">EDITOR CODE HTML CSS JS</h5>
          <p class="card-text text-muted small">TOOLS CODE EDITOR ONLINE | LIVE CODING</p>
          <a href="/code" class="btn btn-gradient w-100 text-muted"><i class="bi bi-box-arrow-up-right me-1"></i> DISINI</a>
        </div>
      </div>
    </div>

    <!-- SHARED FILE -->
    <div class="col-md-4">
      <div class="card text-center shadow-sm border-0 bg-white rounded">
        <div class="card-body">
          <div class="mb-3">
            <div class="bg-light rounded-circle d-inline-flex p-3 shadow-sm">
              <i class="bi bi-reply-all-fill fs-2 text-primary"></i>
            </div>
          </div>
          <h5 class="card-title text-muted fw-bold">SHARED FILE</h5>
          <p class="card-text text-muted small">TOOLS UNTUK SHARE DAN DOWNLOAD FILE | MEMBANTU UNTUK MEMBUAT LINK DOWNLOAD SEPERTI MEDIAFIRE</p>
          <a href="/shared" class="btn btn-gradient w-100 text-muted"><i class="bi bi-box-arrow-up-right me-1"></i> DISINI</a>
        </div>
      </div>
    </div>


    <!-- QURAN-->
    <div class="col-md-4">
      <div class="card text-center shadow-sm border-0 bg-white rounded">
        <div class="card-body">
          <div class="mb-3">
            <div class="bg-light rounded-circle d-inline-flex p-3 shadow-sm">
              <i class="bi bi-book fs-2 text-primary"></i>
            </div>
          </div>
          <h5 class="card-title text-muted fw-bold">Al-Qur'an</h5>
          <p class="card-text text-muted small">AL-QURAN BERBASIS WEBSITE </p>
          <a href="/quran" class="btn btn-gradient w-100 text-muted"><i class="bi bi-box-arrow-up-right me-1"></i> DISINI</a>
        </div>
      </div>
    </div>


    <!-- LINKMEET-->
    <div class="col-md-4">
      <div class="card text-center shadow-sm border-0 bg-white rounded">
        <div class="card-body">
          <div class="mb-3">
            <div class="bg-light rounded-circle d-inline-flex p-3 shadow-sm">
              <i class="bi bi-link-45deg fs-2 text-primary"></i>
            </div>
          </div>
          <h5 class="card-title text-muted fw-bold">Link Meet</h5>
          <p class="card-text text-muted small">BUAT LINK PORTOFOLIO ANDA DISINI</p>
          <a href="#COMINGSOON" class="btn btn-gradient w-100 text-muted"><i class="bi bi-box-arrow-up-right me-1"></i> DISINI</a>
        </div>
      </div>
    </div>


    <!-- REPORT -->
    <div class="col-md-4">
      <div class="card text-center shadow-sm border-0 bg-white rounded">
        <div class="card-body">
          <div class="mb-3">
            <div class="bg-light rounded-circle d-inline-flex p-3 shadow-sm">
              <i class="bi bi-exclamation-square-fill fs-2 text-primary"></i>
            </div>
          </div>
          <h5 class="card-title text-muted fw-bold">REPORT BUG</h5>
          <p class="card-text text-muted small">LAPORKAN ADMIN JIKA MENEMUKAN BUG</p>
        </div>
      </div>
    </div>



  </div>
</div>

<!-- CHAT AI -->
<div id="floating-chat">
  <button id="chat-toggle" onclick="toggleChatWidget()">
    💬 <span id="notif-dot"></span>
  </button>
  <iframe id="chat-iframe" src="/backup/index.php" allow="clipboard-write"></iframe>
</div>

<br>

<!-- FOOTER -->
<footer class="text-center py-3 bg-dark text-white fixed-bottom">
  <div class="container">
    <strong id="terminal"></strong>
  </div>
</footer>

<!-- Modal -->
<div class="modal fade" id="welcomeModal" tabindex="-1" aria-labelledby="welcomeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content bg-dark text-white">
      <div class="modal-header">
        <h5 class="modal-title" id="welcomeModalLabel"><i class="bi bi-info-circle-fill text-info me-2"></i> Info</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body text-center">
        <h5>SELAMAT DATANG BRO 😎</h5>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Siap</button>
      </div>
    </div>
  </div>
</div>

<!-- Link ke file JS terpisah -->
<script src="script.js"></script>

</body>
</html>