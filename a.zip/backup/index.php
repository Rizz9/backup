<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $apiKey = "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";
    $userMessage = $_POST["message"] ?? "";

    $data = [
        "model" => "gpt-4o-mini",
        "messages" => [
            ["role" => "system", "content" => "Kamu adalah RizxDev AI, asisten yang ramah, gaul, dan suka ngobrol santai tapi cerdas."],
            ["role" => "user", "content" => $userMessage]
        ],
        "temperature" => 0.7,
        "max_tokens" => 1000
    ];

    $ch = curl_init("https://api.openai.com/v1/chat/completions");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "Authorization: Bearer $apiKey"
        ],
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data)
    ]);

    $result = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    header("Content-Type: application/json");

    if ($error) {
        echo json_encode(["reply" => "❌ Gagal koneksi ke OpenAI"]);
    } else {
        $response = json_decode($result, true);
        echo json_encode(["reply" => $response["choices"][0]["message"]["content"] ?? "Gagal membalas."]);
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>RizxDev AI</title>
   <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>🤖 RizxDev AI</h1>
    <div id="chat"></div>
    <form id="form">
        <input type="text" id="message" placeholder="Tulis pesan..." autocomplete="off" required />
        <button type="submit">Kirim</button>
    </form>

    <script>
        const form = document.getElementById('form');
        const chat = document.getElementById('chat');

        form.onsubmit = async (e) => {
            e.preventDefault();
            const input = document.getElementById('message');
            const message = input.value;
            input.value = "";

            addBubble(message, "user");

            const loader = addTypingBubble();

            const res = await fetch("", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({ message })
            });

            const data = await res.json();
            loader.remove();
            addBubble(data.reply || "Gagal membalas.", "ai");
        };

        function addBubble(text, type) {
            const div = document.createElement("div");
            div.className = `bubble ${type}`;
            div.textContent = text;
            chat.appendChild(div);
            chat.scrollTop = chat.scrollHeight;
        }

        function addTypingBubble() {
            const div = document.createElement("div");
            div.className = "bubble ai";
            div.innerHTML = `
                <div class="typing">
                    <span></span><span></span><span></span>
                </div>
            `;
            chat.appendChild(div);
            chat.scrollTop = chat.scrollHeight;
            return div;
        }
    </script>
</body>
</html>