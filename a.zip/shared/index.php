<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 'user_' . substr(str_shuffle('abcdefghijklmnopqrstuvwxyz0123456789'), 0, 6);
}
$userId = $_SESSION['user_id'];

if (!is_dir('upload')) mkdir('upload');
if (!file_exists('data.json')) file_put_contents('data.json', '{}');
$data = json_decode(file_get_contents('data.json'), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $filename = $file['name'];
    $password = $_POST['password'] ?? '';

    if (isset($data[$filename])) {
        echo json_encode(['status' => 'error', 'message' => 'File sudah ada']);
        exit;
    }

    $id = substr(str_shuffle('abcdefghijklmnopqrstuvwxyz0123456789'), 0, 8);
    $target = "upload/$id";
    move_uploaded_file($file['tmp_name'], $target);

    $data[$filename] = [
        'id' => $id,
        'owner' => $userId,
        'views' => 0,
        'timestamp' => date('Y-m-d H:i'),
        'password' => $password
    ];
    file_put_contents('data.json', json_encode($data, JSON_PRETTY_PRINT));

    echo json_encode(['status' => 'success', 'filename' => $filename]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Upload Cyber Breee</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #1a001a, #2b0040, #220044);
      background-size: 400% 400%;
      animation: bgMove 10s ease infinite;
      color: #fff;
    }
    @keyframes bgMove {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
    .dropzone {
      border: 2px dashed #b300ff;
      border-radius: 10px;
      padding: 60px;
      text-align: center;
      background-color: #2d0033;
      cursor: pointer;
      transition: 0.3s;
    }
    .dropzone:hover {
      animation: glow 1.5s infinite alternate;
    }
    @keyframes glow {
      0% { box-shadow: 0 0 10px #b300ff; }
      100% { box-shadow: 0 0 30px #ff00ff; }
    }
    .progress-container { display: none; margin-top: 20px; }
    #passwordField { display: none; margin-top: 15px; }
    .pulse {
      animation: pulse 1.5s infinite;
    }
    @keyframes pulse {
      0% { box-shadow: 0 0 0 0 rgba(255, 0, 255, 0.4); }
      70% { box-shadow: 0 0 0 15px rgba(255, 0, 255, 0); }
      100% { box-shadow: 0 0 0 0 rgba(255, 0, 255, 0); }
    }
    .fade-in { animation: fadeIn 0.5s ease-in-out; }
    @keyframes fadeIn {
      0% { opacity: 0; transform: scale(0.95); }
      100% { opacity: 1; transform: scale(1); }
    }
  </style>
</head>
<body>
<div class="container py-5">
  <h1 id="heroTitle" class="text-center text-light mb-4"></h1>

  <div class="card bg-dark text-light shadow">
    <div class="card-body">
      <div id="dropzone" class="dropzone mb-3">
        <p><i class="bi bi-upload fs-1"></i></p>
        <h4>Drag & Drop File ke sini</h4>
        <p>OPSIONAL JIKA MAU MENGGUNAKAN PASSWORD HARAP ISI PASSWORD DULU SEBELUM UPLOAD FILE</p>
        <input type="file" id="fileInput" hidden>
      </div>

      <div class="form-check mb-2">
        <input class="form-check-input" type="checkbox" id="usePassword">
        <label class="form-check-label" for="usePassword">Gunakan Password</label>
      </div>

      <div id="passwordField">
        <input type="text" class="form-control" id="passwordInput" placeholder="Masukkan password">
      </div>

      <div class="progress-container" id="progressBox">
        <div class="progress mt-4">
          <div class="progress-bar progress-bar-striped progress-bar-animated bg-warning" 
               role="progressbar" style="width: 0%;" id="progressBar"></div>
        </div>
        <p class="text-center mt-2"><span class="dot-anim">Proses...</span></p>
      </div>

      <div id="resultBox" class="card-link text-center mt-4"></div>
    </div>
  </div>
</div>

<script>
const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');
const progressBar = document.getElementById('progressBar');
const progressBox = document.getElementById('progressBox');
const resultBox = document.getElementById('resultBox');
const usePassword = document.getElementById('usePassword');
const passwordField = document.getElementById('passwordField');
const passwordInput = document.getElementById('passwordInput');

usePassword.addEventListener('change', () => {
  passwordField.style.display = usePassword.checked ? 'block' : 'none';
});

dropzone.addEventListener('click', () => fileInput.click());
dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('bg-purple'); });
dropzone.addEventListener('dragleave', () => dropzone.classList.remove('bg-purple'));
dropzone.addEventListener('drop', e => { e.preventDefault(); uploadFile(e.dataTransfer.files[0]); });
fileInput.addEventListener('change', () => uploadFile(fileInput.files[0]));

function uploadFile(file) {
  const formData = new FormData();
  formData.append('file', file);
  if (usePassword.checked && passwordInput.value) {
    formData.append('password', passwordInput.value);
  }

  progressBox.style.display = 'block';
  progressBar.style.width = '0%';
  resultBox.innerHTML = '';

  const xhr = new XMLHttpRequest();
  xhr.open('POST', '', true);

  xhr.upload.onprogress = function (e) {
    if (e.lengthComputable) {
      let percent = Math.round((e.loaded / e.total) * 100);
      progressBar.style.width = percent + '%';
    }
  };

  xhr.onload = function () {
    if (xhr.status === 200) {
      let res = JSON.parse(xhr.responseText);
      if (res.status === 'success') {
        setTimeout(() => { progressBox.style.display = 'none'; }, 300);

        // Optional: play sound (add /sfx/success.mp3 to your project)
        // new Audio('/sfx/success.mp3').play();

        resultBox.innerHTML = `
          <div class="alert alert-success fade-in mt-3"><i class="bi bi-check-circle"></i> File berhasil diupload!</div>
          <div class="card bg-secondary text-light p-3 fade-in">
            <div><i class="bi bi-download"></i> 
              <a href="/download/index.php?file=${encodeURIComponent(res.filename)}" class="text-info">
              /download/index.php?file=${res.filename}</a>
            </div>
            <div class="mt-2">
              <a href="/dashboard/index.php" class="btn btn-outline-light pulse">Lihat Dashboard</a>
            </div>
          </div>
        `;
      } else {
        progressBox.style.display = 'none';
        resultBox.innerHTML = `<div class="alert alert-danger">${res.message}</div>`;
      }
    }
  };

  xhr.send(formData);
}

// Typing animation for title
const title = "Sharing filemanager online...";
let i = 0;
setInterval(() => {
  if (i <= title.length) {
    document.getElementById("heroTitle").innerText = title.substring(0, i++);
  }
}, 50);
</script>
</body>
</html>