<?php
session_start();

$data = json_decode(file_get_contents(__DIR__ . '/../data.json'), true);
$filename = $_GET['file'] ?? null;

if (!$filename || !isset($data[$filename])) {
    http_response_code(404);
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
      <meta charset="UTF-8">
      <title>404 - Link Ga Ada</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <style>
        body {
          background-color: #1a001a;
          color: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          height: 100vh;
          flex-direction: column;
          text-align: center;
        }
        .big-404 {
          font-size: 8rem;
          font-weight: bold;
          animation: pop 1s ease infinite alternate;
          color: #ff00ff;
        }
        @keyframes pop {
          from { transform: scale(1); color: #ff00ff; }
          to { transform: scale(1.1); color: #ff33cc; }
        }
      </style>
    </head>
    <body>
      <div class="big-404">404</div>
      <h3 class="text-danger">ERROR BREE GA ADA LINK 😵‍💫</h3>
    </body>
    </html>
    <?php
    exit;
}

$fileInfo = $data[$filename];
$id = $fileInfo['id'];
$filepath = __DIR__ . "/../upload/$id";
$password = $fileInfo['password'] ?? null;

// Download trigger
if (isset($_GET['get']) && $_GET['get'] == 1) {
    $data[$filename]['views'] = ($data[$filename]['views'] ?? 0) + 1;
    file_put_contents(__DIR__ . '/../data.json', json_encode($data, JSON_PRETTY_PRINT));

    header('Content-Type: application/octet-stream');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    readfile($filepath);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Unduh <?= htmlspecialchars($filename) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background-color: #1a001a; color: #fff; }
    .box {
      background: #2d0033;
      padding: 30px;
      border-radius: 10px;
      max-width: 500px;
      margin: 80px auto;
      text-align: center;
    }
    .preview-box img, .preview-box video, .preview-box i {
      max-width: 300px;
      max-height: 200px;
      animation: fadeIn 0.4s ease-in-out;
    }
    .spin {
      animation: spin 1s linear infinite;
    }
    @keyframes fadeIn {
      0% { opacity: 0; transform: scale(0.95); }
      100% { opacity: 1; transform: scale(1); }
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  </style>
</head>
<body>

<div class="box shadow">
  <h3 class="mb-3"><i class="bi bi-cloud-arrow-down-fill"></i> <?= htmlspecialchars($filename) ?></h3>
  <?php if ($password): ?>
    <div id="passwordBox">
      <input type="password" class="form-control mb-3" id="inputPassword" placeholder="Masukkan password">
      <button class="btn btn-warning" onclick="checkPassword()">Lanjut</button>
      <div class="mt-3 text-danger" id="wrongPass" style="display:none;">Password salah bre!</div>
    </div>
  <?php endif; ?>

  <div id="loadingMsg" style="display:<?= $password ? 'none' : 'block' ?>;">Menyiapkan unduhan <span class="dot">...</span></div>

  <div id="previewArea" style="display:none;" class="preview-box my-3"></div>

  <a href="javascript:void(0)" class="btn btn-warning mt-3" id="downloadBtn" style="display:none;">
    <i class="bi bi-download"></i> Unduh Sekarang
  </a>

  <div id="downloadingMsg" class="mt-3 text-warning" style="display:none;">
    <i class="bi bi-arrow-repeat spin me-2"></i> Mengunduh file<span class="dot">...</span>
  </div>
</div>

<script>
const previewBox = document.getElementById('previewArea');
const loadingMsg = document.getElementById('loadingMsg');
const downloadBtn = document.getElementById('downloadBtn');
const downloadingMsg = document.getElementById('downloadingMsg');
const ext = "<?= pathinfo($filename, PATHINFO_EXTENSION) ?>".toLowerCase();
const fileUrl = "/upload/<?= $id ?>";
const hasPassword = <?= $password ? 'true' : 'false' ?>;
const realPassword = <?= json_encode($password) ?>;

const mimeMap = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp',
  gif: 'image/gif', mp4: 'video/mp4', webm: 'video/webm'
};

const iconMap = {
  pdf: 'filetype-pdf', zip: 'file-earmark-zip-fill', txt: 'filetype-txt',
  html: 'filetype-html', php: 'filetype-php', doc: 'filetype-doc',
  xls: 'filetype-xls', ppt: 'filetype-ppt', default: 'file-earmark-fill'
};

function getPreviewElement() {
  if (mimeMap[ext]?.startsWith('image')) {
    return `<img src="${fileUrl}" class="rounded">`;
  } else if (mimeMap[ext]?.startsWith('video')) {
    return `<video src="${fileUrl}" controls class="rounded"></video>`;
  } else {
    const icon = iconMap[ext] || iconMap.default;
    return `<i class="bi bi-${icon} display-1 text-warning"></i>`;
  }
}

function simulateReady() {
  loadingMsg.style.display = 'none';
  previewBox.innerHTML = getPreviewElement();
  previewBox.style.display = 'block';
  downloadBtn.style.display = 'inline-block';
}

setInterval(() => {
  document.querySelectorAll('.dot').forEach(dot => {
    dot.textContent = dot.textContent.length >= 3 ? '.' : dot.textContent + '.';
  });
}, 500);

downloadBtn.addEventListener("click", () => {
  downloadBtn.style.display = 'none';
  downloadingMsg.style.display = 'block';
  setTimeout(() => {
    window.location.href = "index.php?file=<?= rawurlencode($filename) ?>&get=1";
  }, 5000);
});

function checkPassword() {
  const input = document.getElementById("inputPassword").value;
  if (input === realPassword) {
    document.getElementById("passwordBox").style.display = 'none';
    loadingMsg.style.display = 'block';
    setTimeout(simulateReady, 5000);
  } else {
    document.getElementById("wrongPass").style.display = 'block';
  }
}

if (!hasPassword) {
  setTimeout(simulateReady, 5000);
}
</script>

</body>
</html>