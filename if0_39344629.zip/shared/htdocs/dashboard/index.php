<?php
session_start();

// Generate session user ID jika belum ada
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 'user_' . substr(str_shuffle('abcdefghijklmnopqrstuvwxyz0123456789'), 0, 6);
}

$userId = $_SESSION['user_id'];
$data = json_decode(file_get_contents(__DIR__ . '/../data.json'), true);

// Ambil data file milik user ini
$userFiles = array_filter($data, function($f) use ($userId) {
    return $f['owner'] === $userId;
});

// Handle hapus
if (isset($_GET['hapus']) && isset($data[$_GET['hapus']])) {
    $fileName = $_GET['hapus'];
    if ($data[$fileName]['owner'] === $userId) {
        unlink(__DIR__ . '/../upload/' . $data[$fileName]['id']);
        unset($data[$fileName]);
        file_put_contents(__DIR__ . '/../data.json', json_encode($data, JSON_PRETTY_PRINT));
        header("Location: index.php?deleted=1");
        exit;
    }
}

// Pagination
$perPage = 5;
$total = count($userFiles);
$pages = ceil($total / $perPage);
$page = max(1, min($_GET['page'] ?? 1, $pages));
$offset = ($page - 1) * $perPage;
$displayFiles = array_slice($userFiles, $offset, $perPage);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Link File</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background-color: #1a001a; color: #fff; }
    .card-stat { background-color: #2d0033; border-left: 4px solid #b300ff; }
    .table-container { background-color: #2d0033; padding: 20px; border-radius: 10px; }
    .pagination a { color: #fff; margin: 0 5px; text-decoration: none; }
    .pagination a.active { font-weight: bold; color: #ffc107; }
  </style>
</head>
<body>
<div class="container py-5">
  <h1 class="mb-4 text-center">📁 Dashboard File Kamu</h1>

  <div class="row mb-4">
    <div class="col-md-4">
      <div class="card card-stat text-light p-3 shadow">
        <h5><i class="bi bi-file-earmark-plus-fill"></i> Link Dibuat</h5>
        <h2><?= count($userFiles) ?></h2>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card card-stat text-light p-3 shadow">
        <h5><i class="bi bi-bar-chart-line-fill"></i> Total Akses</h5>
        <h2><?= array_sum(array_column($userFiles, 'views')) ?></h2>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card card-stat text-light p-3 shadow">
        <h5><i class="bi bi-cloud-upload-fill"></i> Upload Baru</h5>
        <a href="/index.php" class="btn btn-warning mt-2">+ Upload</a>
      </div>
    </div>
  </div>

  <div class="table-container shadow">
    <h4>📄 Daftar File Kamu</h4>
    <?php if (isset($_GET['deleted'])): ?>
      <div class="alert alert-success">File berhasil dihapus!</div>
    <?php endif; ?>

    <table class="table table-dark table-bordered table-hover mt-3">
      <thead>
        <tr>
          <th>Nama File</th>
          <th>Tanggal</th>
          <th>View</th>
          <th>Link</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($displayFiles as $name => $info): ?>
        <tr>
          <td><?= htmlspecialchars($name) ?></td>
          <td><?= $info['timestamp'] ?></td>
          <td><?= $info['views'] ?? 0 ?></td>
          <td><a href="/download/index.php?file=<?= urlencode($name) ?>" class="text-info">Link</a></td>
          <td><a href="?hapus=<?= urlencode($name) ?>" class="btn btn-sm btn-danger">Hapus</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>

    <?php if ($pages > 1): ?>
    <div class="pagination text-center mt-3">
      <?php for ($i = 1; $i <= $pages; $i++): ?>
        <a href="?page=<?= $i ?>" class="<?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
      <?php endfor; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>