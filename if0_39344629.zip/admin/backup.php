<?php
session_start();

// === KONFIGURASI ===
$adminUser = 'rizki';
$adminPass = 'rizki@123';
$uploadDir = realpath(__DIR__ . '/../upl');
if (!$uploadDir || !is_dir($uploadDir)) {
  die("❌ Folder upload tidak ditemukan!");
}

$maxUploadSize = $_SESSION['max_size'] ?? 500 * 1024;
$allowed_ext = ['$file'];

$msg = null;

if (isset($_POST['login'])) {
  if ($_POST['user'] === $adminUser && $_POST['pass'] === $adminPass) {
    $_SESSION['admin'] = true;
  } else {
    $msg = "❌ Login gagal!";
  }
}

if (isset($_GET['logout'])) {
  session_destroy();
  header("Location: ?");
  exit;
}

if ($_SESSION['admin']) {
  if (isset($_POST['newpass'])) {
    $adminPass = $_POST['newpass'];
    $msg = "✅ Password diubah (sementara)";
  }

  if (isset($_POST['maxsize'])) {
    $_SESSION['max_size'] = intval($_POST['maxsize']) * 1024;
    $msg = "✅ Max upload diubah ke {$_POST['maxsize']} KB";
  }

  if ($_FILES['file']['name'] ?? false) {
    $filename = basename($_FILES['file']['name']);
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $size = $_FILES['file']['size'];

    if ($size > $maxUploadSize) {
      $msg = "❌ File terlalu besar!";
    } elseif (!in_array($ext, $allowed_ext)) {
      $msg = "❌ Ekstensi tidak diizinkan!";
    } else {
      $target = $uploadDir . '/' . $filename;
      if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
        $msg = "✅ Upload berhasil!";
        if ($ext === 'zip' && isset($_POST['unzip'])) {
          $zip = new ZipArchive;
          if ($zip->open($target) === TRUE) {
            $zip->extractTo($uploadDir);
            $zip->close();
            $msg .= " ZIP berhasil diextract.";
          } else {
            $msg .= " Tapi gagal extract ZIP.";
          }
        }
      } else {
        $msg = "❌ Upload gagal!";
      }
    }
  }

  if (isset($_GET['delete'])) {
    $target = $uploadDir . '/' . basename($_GET['delete']);
    if (is_file($target)) unlink($target);
    header("Location: ?");
    exit;
  }

  if (isset($_POST['renamebtn'])) {
    $old = $uploadDir . '/' . basename($_POST['oldname']);
    $new = $uploadDir . '/' . basename($_POST['newname']);
    rename($old, $new);
    header("Location: ?");
    exit;
  }

  if (isset($_POST['saveedit'])) {
    $fileToEdit = $uploadDir . '/' . basename($_POST['editname']);
    file_put_contents($fileToEdit, $_POST['filecontent']);
    $msg = "✅ File berhasil disimpan.";
  }

  if (isset($_GET['download_zip'])) {
    $zipname = 'all_files.zip';
    $zip = new ZipArchive();
    $zip->open($zipname, ZipArchive::CREATE | ZipArchive::OVERWRITE);
    foreach (scandir($uploadDir) as $file) {
      $path = $uploadDir . '/' . $file;
      if (is_file($path)) $zip->addFile($path, $file);
    }
    $zip->close();
    header('Content-Type: application/zip');
    header("Content-Disposition: attachment; filename=$zipname");
    readfile($zipname);
    unlink($zipname);
    exit;
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Uploader R07</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    .avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
    }
    textarea {
      font-size: 0.85rem;
    }
  </style>
</head>
<body class="bg-dark text-light">
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4>📁 Uploader R07</h4>
    <div class="dropdown">
      <button class="btn btn-outline-light dropdown-toggle" data-bs-toggle="dropdown">
        <img src="https://i.pravatar.cc/30" class="avatar"> Admin
      </button>
      <ul class="dropdown-menu dropdown-menu-end text-small">
        <li class="dropdown-item-text">Status: <?= $_SESSION['admin'] ? 'Admin' : 'User' ?></li>
        <li class="dropdown-item-text">IP: <?= $_SERVER['REMOTE_ADDR'] ?></li>
        <li><hr class="dropdown-divider"></li>
        <?php if ($_SESSION['admin']): ?>
          <li class="px-3 py-2">
            <form method="post">
              <input type="text" name="newpass" class="form-control form-control-sm mb-2" placeholder="New password">
              <button class="btn btn-sm btn-primary w-100">Ubah Password</button>
            </form>
          </li>
          <li class="px-3 py-2">
            <form method="post">
              <input type="number" name="maxsize" class="form-control form-control-sm mb-2" placeholder="Max KB">
              <button class="btn btn-sm btn-secondary w-100">Set Max Upload</button>
            </form>
          </li>
          <li><a class="dropdown-item text-danger" href="?logout=1">Logout</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>

  <?php if (isset($msg)) echo "<div class='alert alert-info'>$msg</div>"; ?>

  <?php if (!isset($_SESSION['admin'])): ?>
    <form method="post" class="row g-2">
      <div class="col"><input type="text" name="user" class="form-control" placeholder="Username"></div>
      <div class="col"><input type="password" name="pass" class="form-control" placeholder="Password"></div>
      <div class="col"><button name="login" class="btn btn-primary">Login</button></div>
    </form>
  <?php else: ?>
    <form method="post" enctype="multipart/form-data" class="mb-3">
      <div class="input-group">
        <input type="file" name="file" class="form-control">
        <button class="btn btn-success">Upload</button>
        <div class="input-group-text">
          <input class="form-check-input mt-0" type="checkbox" name="unzip"> Unzip jika ZIP
        </div>
      </div>
    </form>

    <a href="?download_zip=1" class="btn btn-warning mb-3">📦 Download Semua (ZIP)</a>

    <div class="table-responsive">
      <table class="table table-dark table-bordered table-hover small">
        <thead><tr><th>Nama</th><th>Ukuran</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php
        foreach (scandir($uploadDir) as $file) {
          if (is_dir($uploadDir . '/' . $file)) continue;
          $size = filesize($uploadDir . '/' . $file);
          echo "<tr><td>$file</td><td>{$size} B</td><td>";
          echo "<a href='../upl/" . rawurlencode($file) . "' target='_blank' class='btn btn-sm btn-info'>View</a> ";
          echo "<a href='../upl/" . rawurlencode($file) . "' download class='btn btn-sm btn-primary'>Download</a> ";
          echo "<a href='?delete=" . urlencode($file) . "' class='btn btn-sm btn-danger' onclick=\"return confirm('Hapus?')\">Delete</a><br>";
          echo "<form method='post' class='d-inline-block mt-2 me-2'><input type='hidden' name='oldname' value='$file'>";
          echo "<input type='text' name='newname' class='form-control form-control-sm mb-1' placeholder='Rename'>";
          echo "<button name='renamebtn' class='btn btn-sm btn-warning w-100'>Rename</button></form>";
          echo "<form method='post' class='d-inline-block'><input type='hidden' name='editname' value='$file'>";
          echo "<textarea name='filecontent' class='form-control' rows='3'>" . htmlspecialchars(file_get_contents($uploadDir . '/' . $file)) . "</textarea>";
          echo "<button name='saveedit' class='btn btn-sm btn-success w-100 mt-1'>Save Edit</button></form>";
          echo "</td></tr>";
        }
        ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
</body>
</html>