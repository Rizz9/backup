<?php
// === HANDLE POST SAVE ===
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_decode(file_get_contents("php://input"), true);
  if (!$data || !isset($data['id']) || !isset($data['files'])) {
    http_response_code(400);
    echo "Invalid data";
    exit;
  }

  $id = preg_replace("/[^a-zA-Z0-9]/", "", $data['id']);
  $folder = __DIR__ . "/code/" . $id;
  if (!is_dir($folder)) mkdir($folder, 0777, true);

  $safeFiles = [];
  foreach ($data['files'] as $fname => $content) {
    if (preg_match('/\.php$/i', $fname)) continue;
    if (stripos($content, '<?php') !== false || stripos($content, 'shell_exec') !== false || stripos($content, 'system(') !== false) continue;
    $safeFiles[$fname] = $content;
  }

  file_put_contents("$folder/files.json", json_encode($safeFiles));
  echo "Saved";
  exit;
}

// === RAW VIEW ===
if (isset($_GET['raw']) && preg_match('/^[a-zA-Z0-9]+$/', $_GET['raw'])) {
  $file = __DIR__ . "/code/" . $_GET['raw'] . "/files.json";
  if (file_exists($file)) {
    $data = json_decode(file_get_contents($file), true);
    header("Content-Type: text/plain");
    foreach ($data as $fname => $code) {
      echo "/* ----- $fname ----- */\n";
      echo $code . "\n\n";
    }
    exit;
  }
}

// === VIEWER MODE ===
if (isset($_GET['view']) && preg_match('/^[a-zA-Z0-9]+$/', $_GET['view'])) {
  $file = __DIR__ . "/code/" . $_GET['view'] . "/files.json";
  if (!file_exists($file)) {
    echo "<h3 style='color:red;'>Project tidak ditemukan</h3>";
    exit;
  }

  $data = json_decode(file_get_contents($file), true);
  $html = '';
  $css = '';
  $js = '';
  $badCode = false;

  foreach ($data as $fname => $content) {
    if (stripos($content, '<?php') !== false || stripos($content, 'shell_exec') !== false || stripos($content, 'system(') !== false) {
      $badCode = true;
      break;
    }
    $ext = strtolower(pathinfo($fname, PATHINFO_EXTENSION));
    if ($ext === 'html') $html .= $content;
    if ($ext === 'css') $css .= $content;
    if ($ext === 'js') $js .= $content;
  }

  echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Viewer</title>";
  echo "<style>body{font-family:sans-serif;background:#fff;padding:20px;}</style>";

  if ($badCode) {
    echo "</head><body><h1 style='color:red;text-align:center;'>CIE MAU NGAPAIN C WKWKWK!!!!</h1></body></html>";
    exit;
  }

  if ($css) echo "<style>$css</style>";
  echo "</head><body>$html";
  if ($js) echo "<script>try{eval(`".addslashes($js)."`);}catch(e){document.body.innerHTML='<h3 style=\"color:red;\">JS Error: '+e.message+'</h3>'}</script>";
  echo "</body></html>";
  exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Code Editor Online</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body { background:#f1f3f5; padding:20px; font-family:sans-serif; }
    .editor-container { background:#fff; border-radius:8px; padding:1rem; box-shadow:0 0 10px rgba(0,0,0,0.05); }
    .tab-list { display:flex; gap:10px; flex-wrap:wrap; }
    .tab-item { background:#dee2e6; border-radius:5px; padding:3px 10px; cursor:pointer; display:flex; align-items:center; font-weight:500; }
    .tab-item.active { background:#fff; border:1px solid #ccc; }
    .tab-item span { margin-left:5px; color:red; font-weight:bold; cursor:pointer; }
    textarea.editor { width:100%; height:300px; font-family:monospace; font-size:14px; border:1px solid #ccc; padding:10px; border-radius:5px; margin-top:10px; }
    iframe { width:100%; height:300px; border:1px solid #ccc; border-radius:8px; background:#fff; margin-top:10px; }
  </style>
</head>
<body>

<h4>Code Editor Online</h4>
<div class="editor-container">
  <div class="d-flex justify-content-between align-items-center mb-2">
    <div class="tab-list" id="tabList"></div>
    <button class="btn btn-sm btn-outline-secondary" onclick="addTab()">+</button>
  </div>
  <textarea class="editor" id="editor"></textarea>
  <div class="d-flex justify-content-end gap-2 mt-2">
    <button class="btn btn-sm btn-primary" onclick="runCode()">▶ Run</button>
    <button class="btn btn-sm btn-success" onclick="downloadCode()">📥 Download</button>
    <button class="btn btn-sm btn-warning" onclick="copyShareLink()">🔗 Share</button>
  </div>
</div>

<div class="mt-3">
  <h6>Hasil:</h6>
  <iframe id="outputFrame"></iframe>
</div>

<!-- Share Modal -->
<div class="modal fade" id="shareModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Bagikan Link</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <label class="form-label">Viewer URL</label>
        <input class="form-control mb-2" id="viewerURL" readonly>
        <label class="form-label">RAW URL</label>
        <input class="form-control" id="rawURL" readonly>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const STORAGE_KEY = "userCodeID";
let userID = localStorage.getItem(STORAGE_KEY);
if (!userID) {
  userID = Math.random().toString(36).substring(2, 10);
  localStorage.setItem(STORAGE_KEY, userID);
}

let files = { "main.html": "<!-- Mulai koding HTML-mu di sini -->\n<h1>Hello!</h1>" };
let currentFile = "main.html";
const editor = document.getElementById("editor");

function renderTabs() {
  const tabList = document.getElementById("tabList");
  tabList.innerHTML = "";
  Object.keys(files).forEach(filename => {
    const tab = document.createElement("div");
    tab.className = "tab-item" + (filename === currentFile ? " active" : "");
    tab.innerHTML = `${filename} <span onclick="removeTab(event, '${filename}')">&times;</span>`;
    tab.onclick = () => switchTab(filename);
    tabList.appendChild(tab);
  });
}

function switchTab(name) {
  files[currentFile] = editor.value;
  currentFile = name;
  editor.value = files[currentFile];
  renderTabs();
}

function addTab() {
  let name = prompt("Masukkan nama file (misal: about.html)");
  if (!name || name.includes("php")) return alert("File PHP tidak diizinkan!");
  let base = name, ext = "";
  if (name.includes(".")) [base, ext] = name.split(".");
  let counter = 1;
  while (files[name]) name = `${base} (${counter++}).${ext}`;
  files[name] = "<!-- File baru -->";
  switchTab(name);
  saveToServer();
}

function removeTab(e, name) {
  e.stopPropagation();
  if (Object.keys(files).length === 1) return alert("Minimal 1 file!");
  delete files[name];
  if (currentFile === name) currentFile = Object.keys(files)[0];
  editor.value = files[currentFile];
  renderTabs();
  saveToServer();
}

function runCode() {
  const code = editor.value;
  const ext = currentFile.split('.').pop().toLowerCase();
  const out = document.getElementById("outputFrame");

  const bad = code.includes("<" + "?php") || code.includes("system(") || code.includes("shell_exec");

  if (bad || ext === "php") {
    out.srcdoc = "<h1 style='color:red;text-align:center;'>CIE MAU NGAPAIN C WKWKWK!!!!</h1>";
    return;
  }

  let result = "";

  if (ext === "html") {
    result = code;
  } else if (ext === "css") {
    result = `<html><head><style>${code}</style></head><body></body></html>`;
  } else if (ext === "js") {
    const encoded = btoa(unescape(encodeURIComponent(code)));
    result = `
      <html><body>
        <script>
        try {
          const decoded = decodeURIComponent(escape(atob("${encoded}")));
          eval(decoded);
        } catch(e) {
          document.body.innerHTML = '<h3 style="color:red;">JS Error: ' + e.message + '</h3>';
        }
       
      
    `;
  } else {
    result = "<h1 style='color:red;text-align:center;'>HET DISURUH HTML, CSS DAN JS AJA SUSAH BANGET SI SEGALA PAKE EXT LAIN WKWK LAMER !!</h1>";
  }

  out.srcdoc = result;
}

function downloadCode() {
  const blob = new Blob([editor.value], { type: 'text/plain' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = currentFile;
  link.click();
}

function saveToServer() {
  files[currentFile] = editor.value;
  fetch(location.pathname, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id: userID, files })
  });
}

function loadFromServer() {
  fetch(location.pathname + "?load=" + userID)
    .then(res => res.json())
    .then(data => {
      if (data && typeof data === 'object') {
        files = data;
        currentFile = Object.keys(files)[0];
        editor.value = files[currentFile];
        renderTabs();
      } else {
        saveToServer();
        editor.value = files[currentFile];
        renderTabs();
      }
    });
}

function copyShareLink() {
  const base = location.origin + location.pathname;
  const viewer = `${base}?view=${userID}`;
  const raw = `${base}?raw=${userID}`;
  document.getElementById("viewerURL").value = viewer;
  document.getElementById("rawURL").value = raw;
  const modal = new bootstrap.Modal(document.getElementById("shareModal"));
  modal.show();
}

editor.addEventListener("input", saveToServer);
loadFromServer();
</script>
</body>
</html>