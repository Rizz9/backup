<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = rtrim($_POST['target'], '/') . '/wp-content/themes/';
  $themes = ['twentytwentyfour', 'twentytwentythree', 'twentytwentytwo', 'astra', 'hello-elementor'];
  $found = [];

  foreach ($themes as $theme) {
    $url = $target . $theme . '/style.css';
    $style = @file_get_contents($url);

    if ($style && preg_match('/Theme Name:(.*)/i', $style, $match)) {
      $found[] = trim($match[1]);
    }
  }

  echo "<div class='mt-4'>";
  if (!empty($found)) {
    echo "<h5 class='text-success'>🎨 Tema WordPress terdeteksi:</h5><ul class='text-light'>";
    foreach ($found as $theme) echo "<li>$theme</li>";
    echo "</ul>";
  } else {
    echo "<div class='text-danger'>Tidak ada tema default populer yang terdeteksi.</div>";
  }
  echo "</div>";
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>WP Theme Detector</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #f8f9fa; }
    .terminal { font-family: monospace; background: #1e1e1e; padding: 20px; border-radius: 10px; }
  </style>
</head>
<body>
<div class="container py-5">
  <h3 class="text-info">🎭 WP Theme Detector</h3>
  <form method="POST" id="themeForm">
    <div class="mb-3">
      <input type="url" name="target" class="form-control" placeholder="Masukkan URL target, contoh: https://example.com" required>
    </div>
    <button class="btn btn-info">Deteksi Tema</button>
  </form>
  <div id="result" class="terminal mt-4"></div>
</div>
<script>
document.getElementById('themeForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  document.getElementById('result').innerHTML = '<span class="text-warning">Memeriksa tema...</span>';
  const formData = new FormData(this);
  const res = await fetch('', { method: 'POST', body: formData });
  document.getElementById('result').innerHTML = await res.text();
});
</script>
</body>
</html>
