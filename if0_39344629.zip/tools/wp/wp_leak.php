<?php
function getUsername($url) {
    $json = @file_get_contents(rtrim($url, '/') . '/wp-json/wp/v2/users');
    $users = @json_decode($json, true);
    if (!empty($users[0]['slug'])) {
        return $users[0]['slug'];
    }

    $author = @file_get_contents(rtrim($url, '/') . '/?author=1');
    if (preg_match('/<title>(.*?)</', $author, $match)) {
        return strtolower(trim(strip_tags($match[1])));
    }

    return false;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>WP Leak Check Lite</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #eee; font-family: monospace; }
    .container { max-width: 700px; padding-top: 60px; }
    a { color: #00d9ff; }
  </style>
</head>
<body>
<div class="container">
  <h3 class="mb-4">🔍 WP Leak Check (Lite)</h3>
  <form method="POST">
    <input type="url" name="target" class="form-control mb-2" placeholder="https://targetwp.com" required>
    <button class="btn btn-warning">Cek Username</button>
  </form>
  <div class="mt-3">
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $url = $_POST['target'];
    $user = getUsername($url);
    if ($user) {
        echo "<div class='text-success'>Username ditemukan: <strong>$user</strong></div>";
        echo "<div class='mt-2'>🔗 Cek bocoran: <a target='_blank' href='https://haveibeenpwned.com/unifiedsearch/$user'>https://haveibeenpwned.com/unifiedsearch/$user</a></div>";
    } else {
        echo "<div class='text-danger'>Gagal mendeteksi username WordPress</div>";
    }
}
?>
  </div>
</div>
</body>
</html>