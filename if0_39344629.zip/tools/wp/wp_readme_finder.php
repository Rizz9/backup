<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = rtrim($_POST['target'], '/');
  $url = $target . '/readme.html';
  $readme = @file_get_contents($url);

  echo "<div class='mt-4'>";
  if ($readme && stripos($readme, 'wordpress') !== false) {
    echo "<h5 class='text-success'>File readme.html ditemukan!</h5>";
    if (preg_match('/Version\s+([\d.]+)/i', $readme, $match)) {
      echo "<div class='text-light'>Versi WordPress: <strong>{$match[1]}</strong></div>";
    }
    echo "<a href='" . htmlspecialchars($url) . "' target='_blank' class='btn btn-outline-info mt-3'>Lihat File</a>";
  } else {
    echo "<div class='text-danger'>File readme.html tidak ditemukan atau tidak bisa diakses publik.</div>";
  }
  echo "</div>";
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>WP Readme Finder</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #f8f9fa; }
    .terminal { font-family: monospace; background: #1e1e1e; padding: 20px; border-radius: 10px; }
  </style>
</head>
<body>
<div class="container py-5">
  <h3 class="text-info">📄 WP Readme Finder</h3>
  <form method="POST" id="readmeForm">
    <div class="mb-3">
      <input type="url" name="target" class="form-control" placeholder="Masukkan URL target, contoh: https://example.com" required>
    </div>
    <button class="btn btn-primary">Cek readme.html</button>
  </form>
  <div id="result" class="terminal mt-4"></div>
</div>
<script>
document.getElementById('readmeForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  const res = await fetch('', { method: 'POST', body: formData });
  document.getElementById('result').innerHTML = await res.text();
});
</script>
</body>
</html>
