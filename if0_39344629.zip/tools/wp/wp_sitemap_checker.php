<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = rtrim($_POST['target'], '/') . '/wp-sitemap.xml';
  $content = @file_get_contents($target);

  echo "<div class='mt-4'>";
  if ($content && stripos($content, '<sitemapindex') !== false) {
    echo "<h5 class='text-success'>🗺️ File Sitemap WordPress Terdeteksi!</h5>";
    echo "<a href='".htmlspecialchars($target)."' target='_blank'>$target</a>";
  } else {
    echo "<div class='text-danger'>File wp-sitemap.xml tidak ditemukan atau tidak bisa diakses.</div>";
  }
  echo "</div>";
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>WP Sitemap Checker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #f8f9fa; }
    .terminal { font-family: monospace; background: #1e1e1e; padding: 20px; border-radius: 10px; }
  </style>
</head>
<body>
<div class="container py-5">
  <h3 class="text-success">🗺️ WP Sitemap Checker</h3>
  <form method="POST" id="sitemapForm">
    <div class="mb-3">
      <input type="url" name="target" class="form-control" placeholder="Masukkan URL target, contoh: https://example.com" required>
    </div>
    <button class="btn btn-success">Cek Sitemap</button>
  </form>
  <div id="result" class="terminal mt-4"></div>
</div>
<script>
document.getElementById('sitemapForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  document.getElementById('result').innerHTML = '<span class="text-warning">Memeriksa sitemap WordPress...</span>';
  const formData = new FormData(this);
  const res = await fetch('', { method: 'POST', body: formData });
  document.getElementById('result').innerHTML = await res.text();
});
</script>
</body>
</html>
