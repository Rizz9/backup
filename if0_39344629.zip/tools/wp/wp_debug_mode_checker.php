<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = rtrim($_POST['target'], '/') . '/wp-config.php';
  $source = @file_get_contents($target);

  echo "<div class='mt-4'>";
  if ($source && preg_match('/WP_DEBUG\s*,\s*true/i', $source)) {
    echo "<h5 class='text-warning'>WP_DEBUG aktif!</h5>";
    echo "<div class='text-light'>Mode debug dapat mengekspos informasi sensitif.</div>";
  } else {
    echo "<div class='text-success'>WP_DEBUG tidak terdeteksi aktif.</div>";
  }
  echo "</div>";
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>WP Debug Mode Checker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #f8f9fa; }
    .terminal { font-family: monospace; background: #1e1e1e; padding: 20px; border-radius: 10px; }
  </style>
</head>
<body>
<div class="container py-5">
  <h3 class="text-warning">🐞 WP Debug Mode Checker</h3>
  <form method="POST" id="debugForm">
    <div class="mb-3">
      <input type="url" name="target" class="form-control" placeholder="Masukkan URL target, contoh: https://example.com" required>
    </div>
    <button class="btn btn-warning">Cek WP_DEBUG</button>
  </form>
  <div id="result" class="terminal mt-4"></div>
</div>
<script>
document.getElementById('debugForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  const res = await fetch('', { method: 'POST', body: formData });
  document.getElementById('result').innerHTML = await res.text();
});
</script>
</body>
</html>
