<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = rtrim($_POST['target'], '/');
  $paths = ['/wp-content/', '/wp-includes/', '/wp-content/uploads/'];
  $vulnerable = [];

  foreach ($paths as $path) {
    $url = $target . $path;
    $content = @file_get_contents($url);
    if ($content && preg_match('/Index of/i', $content)) {
      $vulnerable[] = $url;
    }
  }

  echo "<div class='mt-4'>";
  if (!empty($vulnerable)) {
    echo "<h5 class='text-danger'>Directory Listing Terbuka!</h5><ul>";
    foreach ($vulnerable as $url) {
      echo "<li class='text-light'><a href='" . htmlspecialchars($url) . "' target='_blank'>$url</a></li>";
    }
    echo "</ul>";
  } else {
    echo "<div class='text-success'>Tidak ditemukan direktori yang terbuka untuk listing.</div>";
  }
  echo "</div>";
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>WP Directory Listing Checker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #f8f9fa; }
    .terminal { font-family: monospace; background: #1e1e1e; padding: 20px; border-radius: 10px; }
  </style>
</head>
<body>
<div class="container py-5">
  <h3 class="text-danger">📁 WP Directory Listing Checker</h3>
  <form method="POST" id="dirlistForm">
    <div class="mb-3">
      <input type="url" name="target" class="form-control" placeholder="Masukkan URL target, contoh: https://example.com" required>
    </div>
    <button class="btn btn-danger">Cek Direktori</button>
  </form>
  <div id="result" class="terminal mt-4"></div>
</div>
<script>
document.getElementById('dirlistForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  const res = await fetch('', { method: 'POST', body: formData });
  document.getElementById('result').innerHTML = await res.text();
});
</script>
</body>
</html>
