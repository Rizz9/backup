<?php
$result = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $text = $_POST['text'] ?? '';
    $method = $_POST['method'] ?? 'base64_encode';

    switch ($method) {
        case 'base64_encode':
            $result = base64_encode($text);
            break;
        case 'base64_decode':
            $result = base64_decode($text);
            break;
        case 'url_encode':
            $result = urlencode($text);
            break;
        case 'url_decode':
            $result = urldecode($text);
            break;
        case 'htmlspecialchars':
            $result = htmlspecialchars($text);
            break;
        case 'htmlspecialchars_decode':
            $result = htmlspecialchars_decode($text);
            break;
    }
}
?><!DOCTYPE html><html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Encode / Decode Tool</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-light">
<div class="container py-5">
    <h1 class="text-center mb-4">🔄 Encode / Decode Tool</h1>
    <form method="post" class="card p-4 bg-secondary border-0 rounded-4 shadow">
        <div class="mb-3">
            <label for="text" class="form-label">Enter Text</label>
            <textarea class="form-control" id="text" name="text" rows="3" required><?= htmlspecialchars($_POST['text'] ?? '') ?></textarea>
        </div>
        <div class="mb-3">
            <label for="method" class="form-label">Choose Method</label>
            <select class="form-select" name="method" id="method">
                <option value="base64_encode" <?= ($_POST['method'] ?? '') === 'base64_encode' ? 'selected' : '' ?>>Base64 Encode</option>
                <option value="base64_decode" <?= ($_POST['method'] ?? '') === 'base64_decode' ? 'selected' : '' ?>>Base64 Decode</option>
                <option value="url_encode" <?= ($_POST['method'] ?? '') === 'url_encode' ? 'selected' : '' ?>>URL Encode</option>
                <option value="url_decode" <?= ($_POST['method'] ?? '') === 'url_decode' ? 'selected' : '' ?>>URL Decode</option>
                <option value="htmlspecialchars" <?= ($_POST['method'] ?? '') === 'htmlspecialchars' ? 'selected' : '' ?>>HTML Specialchars</option>
                <option value="htmlspecialchars_decode" <?= ($_POST['method'] ?? '') === 'htmlspecialchars_decode' ? 'selected' : '' ?>>HTML Specialchars Decode</option>
            </select>
        </div>
        <button type="submit" class="btn btn-warning">Convert</button>
    </form><?php if ($result !== ''): ?>
    <div class="card mt-4 p-4 bg-secondary border-0 rounded-4 shadow">
        <h5 class="mb-3">🧾 Result:</h5>
        <div class="bg-dark p-3 rounded text-light" style="word-break: break-all;">
            <?= htmlspecialchars($result) ?>
        </div>
    </div>
<?php endif; ?>

</div>
</body>
</html>