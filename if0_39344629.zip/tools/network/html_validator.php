<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['html'])) {
  $html = $_POST['html'];
  $errors = [];

  if (!preg_match('/<html.*?>/i', $html)) $errors[] = "Tag <html> tidak ditemukan.";
  if (!preg_match('/<head>.*?<\/head>/is', $html)) $errors[] = "Tag <head> tidak ditemukan atau tidak lengkap.";
  if (!preg_match('/<body.*?>.*?<\/body>/is', $html)) $errors[] = "Tag <body> tidak ditemukan atau tidak lengkap.";

  if (empty($errors)) {
    $result = "<div class='alert alert-success'>HTML valid ✅</div>";
  } else {
    $result = "<div class='alert alert-danger'><ul><li>" . implode("</li><li>", $errors) . "</li></ul></div>";
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset='UTF-8'>
  <title>HTML Validator</title>
  <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>
</head>
<body class='bg-dark text-white'>
<div class='container py-5'>
  <h3 class='mb-4'>🧪 HTML Validator</h3>
  <form method='post'>
    <textarea name='html' class='form-control bg-light text-dark' rows='10' placeholder='Tempel kode HTML di sini...'><?= htmlspecialchars($_POST['html'] ?? '') ?></textarea>
    <button class='btn btn-primary mt-3'>Validasi</button>
  </form>
  <div class='mt-4'><?= $result ?? '' ?></div>
</div>
</body>
</html>
