<?php
if (isset($_POST['domain'])) {
    $domain = trim($_POST['domain']);
    $common_subs = ['www', 'mail', 'ftp', 'cpanel', 'webmail', 'blog'];
    $results = [];

    foreach ($common_subs as $sub) {
        $subdomain = "$sub.$domain";
        $ip = gethostbyname($subdomain);
        if ($ip !== $subdomain) {
            $results[] = ['subdomain' => $subdomain, 'ip' => $ip];
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Subdomain Checker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
<div class="container py-5">
  <h2 class="mb-4">🌐 Subdomain Checker</h2>
  <form method="post" class="mb-3">
    <div class="input-group">
      <input type="text" name="domain" class="form-control" placeholder="example.com" required>
      <button class="btn btn-primary">Check</button>
    </div>
  </form>
  <?php if (!empty($results)): ?>
    <div class="card bg-secondary text-white">
      <div class="card-body">
        <h5>Hasil Deteksi:</h5>
        <ul>
          <?php foreach ($results as $res): ?>
            <li><?= htmlspecialchars($res['subdomain']) ?> - <?= $res['ip'] ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  <?php elseif (isset($_POST['domain'])): ?>
    <div class="alert alert-warning">Tidak ditemukan subdomain umum pada domain ini.</div>
  <?php endif; ?>
</div>
</body>
</html>
