<?php
if (isset($_POST['url'])) {
  $url = trim($_POST['url']);
  $headers = @get_headers($url, 1);
}
?><!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>HTTP Headers Viewer</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #fff; }
    .card { background-color: #1e1e1e; border: none; }
    input, .form-control { background-color: #222; color: #fff; border: 1px solid #444; }
    code { color: #0f0; }
  </style>
</head>
<body>
<div class="container py-5">
  <div class="card shadow">
    <div class="card-body">
      <h3 class="mb-4">📄 HTTP Headers Viewer</h3>
      <form method="post" class="mb-4">
        <div class="input-group">
          <input type="text" name="url" class="form-control" placeholder="https://example.com" required>
          <button class="btn btn-primary">Check</button>
        </div>
      </form>
      <?php if (!empty($headers)): ?>
        <h6>🔍 Headers dari: <?= htmlspecialchars($url) ?></h6>
        <ul class="mt-3">
        <?php foreach ($headers as $key => $value): ?>
          <li><code><?= is_string($key) ? htmlspecialchars($key) . ": " : "" ?><?= is_array($value) ? implode(", ", $value) : htmlspecialchars($value) ?></code></li>
        <?php endforeach; ?>
        </ul>
      <?php elseif (isset($_POST['url'])): ?>
        <div class="alert alert-warning mt-3">Tidak bisa mengambil header dari URL tersebut.</div>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
