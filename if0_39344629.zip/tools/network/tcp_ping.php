<?php
$result = '';
if (isset($_POST['host']) && isset($_POST['port'])) {
  $host = $_POST['host'];
  $port = (int) $_POST['port'];
  $start = microtime(true);
  $conn = @fsockopen($host, $port, $errno, $errstr, 2);
  $latency = round((microtime(true) - $start) * 1000, 2);
  if ($conn) {
    fclose($conn);
    $result = "✅ $host:$port terbuka (latency: {$latency}ms)";
  } else {
    $result = "❌ $host:$port tidak terbuka ($errstr)";
  }
}
?><!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>TCP Ping</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #fff; }
    .card { background-color: #1e1e1e; border: none; }
    input, .form-control { background-color: #222; color: #fff; border: 1px solid #444; }
  </style>
</head>
<body>
<div class="container py-5">
  <div class="card shadow">
    <div class="card-body">
      <h3 class="mb-4">📡 TCP Ping</h3>
      <form method="post" class="row g-2 mb-4">
        <div class="col-md-5">
          <input type="text" name="host" class="form-control" placeholder="Hostname or IP" required>
        </div>
        <div class="col-md-3">
          <input type="number" name="port" class="form-control" placeholder="Port" required>
        </div>
        <div class="col-md-2">
          <button class="btn btn-primary w-100">Ping</button>
        </div>
      </form>
      <?php if (!empty($result)): ?>
        <div class="alert alert-info"><?= $result ?></div>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
