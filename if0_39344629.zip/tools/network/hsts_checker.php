<?php
function checkHSTS($url) {
  $stream = @stream_context_create(["ssl" => ["capture_peer_cert" => true]]);
  $headers = @get_headers($url, 1, stream_context_create(["http" => ["method" => "HEAD"]]));
  if ($headers) {
    foreach ($headers as $key => $val) {
      if (stripos($key, "Strict-Transport-Security") !== false) {
        return true;
      }
    }
  }
  return false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url'])) {
  $url = trim($_POST['url']);
  if (!preg_match('/^https?:\/\//', $url)) $url = "https://" . $url;
  $hsts = checkHSTS($url);
  $result = $hsts 
    ? "<div class='alert alert-success'>🔒 HSTS diaktifkan pada server ini.</div>"
    : "<div class='alert alert-warning'>⚠️ HSTS <strong>tidak</strong> diaktifkan pada server ini.</div>";
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset='UTF-8'>
  <title>HSTS Checker</title>
  <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>
</head>
<body class='bg-dark text-white'>
<div class='container py-5'>
  <h3 class='mb-4'>🔐 HSTS Checker</h3>
  <form method='post'>
    <input type='text' name='url' class='form-control bg-light text-dark' placeholder='Masukkan domain atau URL...' value='<?= htmlspecialchars($_POST['url'] ?? '') ?>'>
    <button class='btn btn-primary mt-3'>Cek HSTS</button>
  </form>
  <div class='mt-4'><?= $result ?? '' ?></div>
</div>
</body>
</html>
