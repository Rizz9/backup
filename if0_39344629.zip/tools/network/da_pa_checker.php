<?php
$result = [];
$data = [];

if (isset($_GET['domain'])) {
    $domain = trim($_GET['domain']);
    $api = "https://api.yogik.id/tools/rankdomain?domain=" . urlencode($domain);
    $response = file_get_contents($api);
    $result = json_decode($response, true);

    if (isset($result['data'][$domain])) {
        $data = $result['data'][$domain];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>DA/PA Checker </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #0d0d0d;
      color: #33ff33;
      font-family: 'Courier New', Courier, monospace;
    }
    .terminal-box {
      background-color: #1a1a1a;
      border: 1px solid #333;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 0 20px #00ff00a0;
    }
    .input-group input {
      background-color: #000;
      color: #33ff33;
      border: 1px solid #555;
    }
    .input-group .btn {
      background-color: #00cc00;
      border: none;
      color: #000;
    }
    .input-group .btn:hover {
      background-color: #00ff00;
      color: #000;
    }
    .line {
      border-bottom: 1px dashed #555;
      margin: 10px 0;
    }
    .label {
      color: #00ffff;
    }
    .value {
      color: #ffffff;
    }
  </style>
</head>
<body>
<div class="container py-5">
  <div class="terminal-box">
    <h3>🖥️ DA/PA ( API 🔥)</h3>
    <form method="get" class="mb-4">
      <div class="input-group">
        <input type="text" name="domain" class="form-control" placeholder="Ketik domain disini..." required>
        <button class="btn" type="submit">Cek</button>
      </div>
    </form>

    <?php if (!empty($data)): ?>
      <div>
        <div><span class="label">Hasil untuk:</span> <span class="value"><?= htmlspecialchars($_GET['domain']) ?></span></div>
        <div class="line"></div>
        <div><span class="label">Domain Authority (DA):</span> <span class="value"><?= $data['domain_authority'] ?></span></div>
        <div><span class="label">Page Authority (PA):</span> <span class="value"><?= $data['page_authority'] ?? '-' ?></span></div>
        <div><span class="label">Moz Rank:</span> <span class="value"><?= $data['moz_rank'] ?? '-' ?></span></div>
        <div><span class="label">Spam Score:</span> <span class="value"><?= $data['spam_score'] ?? '-' ?></span></div>
        <div><span class="label">Total Links:</span> <span class="value"><?= $data['external_nofollow_urls_to_pld'] ?? '-' ?></span></div>
      </div>
    <?php elseif (isset($_GET['domain'])): ?>
      <div class="text-danger mt-3">[!] Gagal mengambil data. Cek kembali domain.</div>
    <?php endif; ?>
  </div>
</div>

<footer class="text-center mt-5" style="color:#999; font-size: 14px; text-shadow: 0 0 5px #00ffcc;">
  © API by <span style="color:#00ffcc;">YOGIKID</span>
</footer>

</body>
</html>