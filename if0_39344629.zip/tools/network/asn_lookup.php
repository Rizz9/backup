<?php
if (isset($_POST['ip'])) {
  $ip = trim($_POST['ip']);
  $output = @file_get_contents("https://api.iptoasn.com/v1/as/ip/" . urlencode($ip));
  $json = json_decode($output, true);
}
?><!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>ASN Lookup</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #fff; }
    .card { background-color: #1e1e1e; border: none; }
    input, .form-control { background-color: #222; color: #fff; border: 1px solid #444; }
  </style>
</head>
<body>
<div class="container py-5">
  <div class="card shadow">
    <div class="card-body">
      <h3 class="mb-4">🌐 ASN Lookup</h3>
      <form method="post" class="mb-4">
        <div class="input-group">
          <input type="text" name="ip" class="form-control" placeholder="IP Address" required>
          <button class="btn btn-primary">Lookup</button>
        </div>
      </form>
      <?php if (!empty($json)): ?>
        <ul>
          <li><strong>IP:</strong> <?= htmlspecialchars($json['ip']) ?></li>
          <li><strong>ASN:</strong> <?= htmlspecialchars($json['as_number']) ?></li>
          <li><strong>ASN Name:</strong> <?= htmlspecialchars($json['as_description']) ?></li>
          <li><strong>Country:</strong> <?= htmlspecialchars($json['country_code']) ?></li>
        </ul>
      <?php elseif(isset($_POST['ip'])): ?>
        <div class="alert alert-warning">Data tidak ditemukan.</div>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
