<?php
function isUsingCloudflare($domain) {
    $dns = dns_get_record($domain, DNS_A + DNS_CNAME);
    foreach ($dns as $record) {
        if (isset($record['ip']) && preg_match('/^104\.|^172\.|^198\.41\./', $record['ip'])) {
            return true;
        }
        if (isset($record['target']) && stripos($record['target'], 'cloudflare') !== false) {
            return true;
        }
    }
    return false;
}

$result = null;
if (isset($_POST['domain'])) {
    $domain = trim($_POST['domain']);
    $result = isUsingCloudflare($domain);
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Cloudflare Checker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
<div class="container py-5">
  <h2 class="mb-4">☁️ Cloudflare Checker</h2>
  <form method="post" class="mb-3">
    <div class="input-group">
      <input type="text" name="domain" class="form-control" placeholder="example.com" required>
      <button class="btn btn-primary">Check</button>
    </div>
  </form>
  <?php if ($result !== null): ?>
    <div class="alert <?= $result ? 'alert-success' : 'alert-danger' ?>">
      <?= $result ? '✅ Menggunakan Cloudflare' : '❌ Tidak terdeteksi menggunakan Cloudflare' ?>
    </div>
  <?php endif; ?>
</div>
</body>
</html>
