
<?php
$pingResult = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['host'])) {
    $host = escapeshellarg($_POST['host']);
    $pingResult = shell_exec("ping -c 4 " . $host);
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Ping Tool</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #fff; font-family: monospace; }
    .card { background-color: #1e1e1e; border: 1px solid #333; }
    .form-control, .btn { border-radius: 0; }
    textarea { background: #000; color: #0f0; }
  </style>
</head>
<body>
<div class="container py-5">
  <div class="card shadow-lg">
    <div class="card-body">
      <h3 class="card-title mb-4 text-info">🌐 Ping Tool</h3>
      <form method="POST">
        <div class="input-group mb-3">
          <input type="text" name="host" class="form-control" placeholder="Masukkan host atau IP..." required>
          <button class="btn btn-success">Ping</button>
        </div>
      </form>
      <?php if ($pingResult): ?>
        <h5 class="text-warning">Hasil Ping:</h5>
        <textarea rows="10" class="form-control" readonly><?= htmlspecialchars($pingResult) ?></textarea>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
