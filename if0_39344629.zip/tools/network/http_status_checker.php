<?php
function getHttpStatus($url) {
  $headers = @get_headers($url);
  if ($headers && isset($headers[0])) {
    return $headers[0];
  }
  return "Tidak dapat terhubung ke URL.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url'])) {
  $url = trim($_POST['url']);
  if (!preg_match('/^https?:\/\//', $url)) $url = "http://" . $url;
  $status = getHttpStatus($url);
  $result = "<div class='alert alert-info'>Status: <strong>$status</strong></div>";
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset='UTF-8'>
  <title>HTTP Status Checker</title>
  <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>
</head>
<body class='bg-dark text-white'>
<div class='container py-5'>
  <h3 class='mb-4'>🌐 HTTP Status Checker</h3>
  <form method='post'>
    <input type='text' name='url' class='form-control bg-light text-dark' placeholder='Masukkan URL...' value='<?= htmlspecialchars($_POST['url'] ?? '') ?>'>
    <button class='btn btn-primary mt-3'>Cek Status</button>
  </form>
  <div class='mt-4'><?= $result ?? '' ?></div>
</div>
</body>
</html>
