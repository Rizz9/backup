<?php
$ip = $_GET['ip'] ?? $_SERVER['REMOTE_ADDR'];
$data = @file_get_contents("http://ip-api.com/json/{$ip}?fields=status,message,country,regionName,city,isp,org,as,query,lat,lon,mobile,proxy,hosting");
$json = json_decode($data, true);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>IP Geolocation Lookup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #121212;
      color: #fff;
      font-family: 'Segoe UI', sans-serif;
    }
    .card {
      background-color: #1f1f1f;
      border: 1px solid #333;
    }
    .form-control,
    .btn {
      background-color: #2a2a2a;
      border: 1px solid #444;
      color: #fff;
    }
    .form-control::placeholder {
      color: #bbb;
    }
    .btn:hover {
      background-color: #333;
    }
    .title-glow {
      text-shadow: 0 0 5px #00bcd4;
    }
  </style>
</head>
<body>
<div class="container py-5">
  <h2 class="mb-4 text-center title-glow">🌐 IP Geolocation Lookup</h2>

  <form class="row justify-content-center mb-4" method="get">
    <div class="col-md-6">
      <input type="text" name="ip" class="form-control" placeholder="Masukkan IP (kosongkan untuk IP Anda)" value="<?= htmlspecialchars($ip) ?>">
    </div>
    <div class="col-auto">
      <button type="submit" class="btn btn-info">Cari</button>
    </div>
  </form>

  <?php if ($json && $json['status'] === 'success'): ?>
  <div class="card shadow p-4 mx-auto" style="max-width: 600px;">
    <h5 class="mb-3 text-info">📍 Informasi Geolokasi</h5>
    <ul class="list-group list-group-flush">
      <li class="list-group-item bg-transparent text-white"><strong>IP:</strong> <?= $json['query'] ?></li>
      <li class="list-group-item bg-transparent text-white"><strong>Negara:</strong> <?= $json['country'] ?></li>
      <li class="list-group-item bg-transparent text-white"><strong>Wilayah:</strong> <?= $json['regionName'] ?></li>
      <li class="list-group-item bg-transparent text-white"><strong>Kota:</strong> <?= $json['city'] ?></li>
      <li class="list-group-item bg-transparent text-white"><strong>ISP:</strong> <?= $json['isp'] ?></li>
      <li class="list-group-item bg-transparent text-white"><strong>ORG:</strong> <?= $json['org'] ?></li>
      <li class="list-group-item bg-transparent text-white"><strong>AS:</strong> <?= $json['as'] ?></li>
      <li class="list-group-item bg-transparent text-white"><strong>Lat/Lon:</strong> <?= $json['lat'] ?>, <?= $json['lon'] ?></li>
      <li class="list-group-item bg-transparent text-white"><strong>Mobile:</strong> <?= $json['mobile'] ? 'Ya' : 'Tidak' ?></li>
      <li class="list-group-item bg-transparent text-white"><strong>Proxy:</strong> <?= $json['proxy'] ? 'Ya' : 'Tidak' ?></li>
      <li class="list-group-item bg-transparent text-white"><strong>Hosting:</strong> <?= $json['hosting'] ? 'Ya' : 'Tidak' ?></li>
    </ul>
  </div>
  <?php elseif ($json): ?>
    <div class="alert alert-danger text-center mt-4">❌ Gagal: <?= htmlspecialchars($json['message'] ?? 'IP tidak valid.') ?></div>
  <?php endif; ?>
</div>
</body>
</html>