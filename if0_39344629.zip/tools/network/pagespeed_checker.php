<?php
function getPageSpeedScore($url) {
    $api = "https://pagespeedonline.googleapis.com/pagespeedonline/v5/runPagespeed?url=" . urlencode($url);
    $json = @file_get_contents($api);

    $score = null;
    if ($json) {
        $data = json_decode($json, true);
        if (isset($data['lighthouseResult']['categories']['performance']['score'])) {
            $score = $data['lighthouseResult']['categories']['performance']['score'] * 100;
        }
    }
    return $score;
}

$score = null;
if (!empty($_GET['url'])) {
    $inputUrl = htmlspecialchars($_GET['url']);
    $score = getPageSpeedScore($inputUrl);
}
?><!DOCTYPE html><html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PageSpeed Checker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #121212; color: #fff; }
    .card { background-color: #1e1e1e; border: none; }
    input, .btn { border-radius: 0.75rem; }
  </style>
</head>
<body>
<div class="container py-5">
  <div class="card mx-auto" style="max-width: 600px;">
    <div class="card-body">
      <h3 class="card-title text-center mb-4">PageSpeed Checker</h3>
      <form method="get">
        <div class="input-group mb-3">
          <input type="text" name="url" class="form-control" placeholder="https://example.com" required>
          <button class="btn btn-primary" type="submit">Cek</button>
        </div>
      </form>
      <?php if ($score !== null): ?>
        <div class="mt-4 text-center">
          <h5>Score PageSpeed:</h5>
          <p class="display-4 text-<?= $score >= 85 ? 'success' : ($score >= 50 ? 'warning' : 'danger') ?>"><?= $score ?></p>
        </div>
      <?php elseif (isset($inputUrl)): ?>
        <div class="alert alert-warning mt-4">Gagal mengambil skor. Coba lagi atau periksa URL.</div>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>