<?php
function detectCMS($url) {
    $headers = @get_headers($url, 1);
    $content = @file_get_contents($url);
    $cms = [];

    if (!$headers || !$content) return ['status' => 'down', 'cms' => []];

    // WordPress
    if (strpos($content, 'wp-content') !== false || strpos($content, 'wp-includes') !== false) {
        $cms[] = 'WordPress';
    }

    // Joomla
    if (strpos($content, 'Joomla!') !== false || strpos($content, 'com_content') !== false) {
        $cms[] = 'Joomla';
    }

    // Drupal
    if (strpos($content, 'sites/all') !== false || strpos($content, 'Drupal') !== false) {
        $cms[] = 'Drupal';
    }

    // PrestaShop
    if (strpos($content, 'PrestaShop') !== false || strpos($content, 'themes/default-bootstrap') !== false) {
        $cms[] = 'PrestaShop';
    }

    // OpenCart
    if (strpos($content, 'index.php?route=common/home') !== false || strpos($content, 'catalog/view') !== false) {
        $cms[] = 'OpenCart';
    }

    // Laravel
    if (strpos($headers[0], 'X-Powered-By: Laravel') !== false || strpos($content, 'laravel.log') !== false) {
        $cms[] = 'Laravel';
    }

    return ['status' => 'live', 'cms' => $cms];
}

if (isset($_POST['url'])) {
    $url = trim($_POST['url']);
    if (!preg_match("#^https?://#i", $url)) $url = "http://$url";

    $result = detectCMS($url);
    echo "<h3>Hasil Scan:</h3>";
    if ($result['status'] === 'down') {
        echo "<p style='color:red'>Website tidak bisa diakses!</p>";
    } elseif (empty($result['cms'])) {
        echo "<p style='color:orange'>CMS tidak terdeteksi atau custom site</p>";
    } else {
        echo "<ul>";
        foreach ($result['cms'] as $cmsName) {
            echo "<li><b>$cmsName</b> terdeteksi ✅</li>";
        }
        echo "</ul>";
    }
    echo "<hr>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>CMS Detector</title>
    <style>
        body { background:#111; color:#eee; font-family:sans-serif; padding:30px; }
        input[type='text'] { padding:10px; width:300px; border-radius:5px; border:none; }
        button { padding:10px 20px; border:none; background:#28a745; color:white; border-radius:5px; }
    </style>
</head>
<body>
    <h2>🔍 CMS Scanner</h2>
    <form method="POST">
        <input type="text" name="url" placeholder="Masukkan URL target..." required>
        <button type="submit">Scan</button>
    </form>
</body>
</html>