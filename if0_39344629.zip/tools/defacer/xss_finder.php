<?php
// XSS Finder by R07 🛡️
$payload = "<script>alert(1)</script>";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $target = trim($_POST['url']);
  $test_url = $target . urlencode($payload);
  $resp = @file_get_contents($test_url);
  if ($resp && strpos($resp, $payload) !== false) {
    $msg = "<div class='alert alert-danger'>💥 VULN: Reflected XSS terdeteksi di <code>$test_url</code></div>";
  } else {
    $msg = "<div class='alert alert-success'>✅ Tidak ditemukan reflected XSS.</div>";
  }
} else {
  $msg = '';
}
?><!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>XSS Finder</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-dark text-light">
<div class="container py-5">
  <div class="card bg-secondary text-light shadow">
    <div class="card-body">
      <h4 class="card-title">🧫 XSS Reflected Finder</h4>
      <form method="post" class="mb-3">
        <input type="text" name="url" class="form-control mb-2" placeholder="http://target.com/page?q=" required>
        <button class="btn btn-warning">Cek XSS</button>
      </form>
      <?= $msg ?>
    </div>
  </div>
</div>
</body></html>
