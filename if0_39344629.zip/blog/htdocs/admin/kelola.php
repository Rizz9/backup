<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
  header("Location: login.php");
  exit;
}

$postFile = '../data/posts.json';
$commentFile = '../data/comments.json';
$posts = file_exists($postFile) ? json_decode(file_get_contents($postFile), true) : [];
$comments = file_exists($commentFile) ? json_decode(file_get_contents($commentFile), true) : [];

// 🗑️ Hapus postingan + komentar + gambar
if (isset($_GET['hapus'])) {
  $id = (int) $_GET['hapus'];
  if (isset($posts[$id])) {
    // hapus gambar
    if (!empty($posts[$id]['gambar'])) {
      $imgPath = '../' . $posts[$id]['gambar'];
      if (file_exists($imgPath)) unlink($imgPath);
    }
    unset($posts[$id]);
    if (isset($comments[$id])) unset($comments[$id]);

    // Reindex array
    $posts = array_values($posts);
    $comments = array_values($comments);

    file_put_contents($postFile, json_encode($posts, JSON_PRETTY_PRINT));
    file_put_contents($commentFile, json_encode($comments, JSON_PRETTY_PRINT));

    header("Location: kelola.php?msg=deleted");
    exit;
  }
}

// 🔁 Pagination
$perPage = 6;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$total = count($posts);
$totalPages = ceil($total / $perPage);
$offset = ($page - 1) * $perPage;
$viewPosts = array_slice($posts, $offset, $perPage);
$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Kelola Postingan</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    .profile-icon {
      width: 32px; height: 32px;
      border-radius: 50%;
      background: url('https://i.pravatar.cc/32') no-repeat center/cover;
      border: 2px solid #dee2e6;
      position: relative;
    }
    .profile-icon.online::after {
      content: ''; width: 10px; height: 10px;
      background: limegreen; border: 2px solid #fff;
      border-radius: 50%; position: absolute;
      bottom: 0; right: 0;
    }
    #profileCard {
      animation: fadeInDown 0.3s ease-in-out;
    }
    @keyframes fadeInDown {
      0% { opacity: 0; transform: translateY(-10px); }
      100% { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body class="bg-light text-dark">
<nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm border-bottom">
  <div class="container-fluid d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center">
      <button class="navbar-toggler border border-dark me-2" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand fw-bold m-0 text-dark" href="index.php">Dashboard</a>
    </div>
    <div class="d-flex align-items-center gap-3">
      <div class="position-relative">
        <div class="profile-icon online" id="profileToggle" style="cursor: pointer;"></div>
        <div id="profileCard" class="card shadow-sm position-absolute end-0 mt-2" style="width: 220px; display: none; z-index: 999;">
          <div class="card-body text-center">
            <img src="https://i.pravatar.cc/80" class="rounded-circle mb-3" width="80" height="80" alt="Profile">
            <div class="d-grid gap-2">
              <a href="../login/ganti_username.php" class="btn btn-warning btn-sm">✏️ Ganti Username</a>
              <a href="../loginl/ganti_password.php" class="btn btn-danger btn-sm">🔐 Ganti Password</a>
              <a href="../login/logout.php" class="btn btn-outline-secondary btn-sm">🚪 Logout</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="tambah.php">➕ Tambah Postingan</a></li>
        <li class="nav-item"><a class="nav-link" href="kelola.php">🗂️ Kelola Postingan</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-5 mt-5">
  <h2 class="mb-4">🗂️ Kelola Postingan</h2>

  <?php if ($msg === 'deleted'): ?>
    <div class="alert alert-success">✅ Postingan berhasil dihapus!</div>
  <?php endif; ?>

  <?php if (count($viewPosts) === 0): ?>
    <div class="alert alert-info">Belum ada postingan.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-bordered align-middle bg-white shadow-sm">
        <thead class="table-light">
          <tr>
            <th>No</th>
            <th>Judul</th>
            <th>Tanggal</th>
            <th>Gambar</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($viewPosts as $i => $post): ?>
            <tr>
              <td><?= $offset + $i + 1 ?></td>
              <td><?= htmlspecialchars($post['judul']) ?></td>
              <td><?= htmlspecialchars($post['tanggal']) ?></td>
              <td>
                <?php if (!empty($post['gambar'])): ?>
                  <img src="../<?= $post['gambar'] ?>" width="80" class="rounded" alt="thumb">
                <?php endif; ?>
              </td>
              <td>
                <a href="edit.php?id=<?= $offset + $i ?>" class="btn btn-sm btn-warning">🖊️ Edit</a>
                <a href="?hapus=<?= $offset + $i ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus postingan ini?')">❌ Hapus</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- 🔢 Pagination -->
    <nav class="mt-4">
      <ul class="pagination justify-content-center">
        <?php if ($page > 1): ?>
          <li class="page-item"><a class="page-link" href="?page=<?= $page - 1 ?>">←</a></li>
        <?php endif; ?>
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
          <li class="page-item <?= $p === $page ? 'active' : '' ?>">
            <a class="page-link" href="?page=<?= $p ?>"><?= $p ?></a>
          </li>
        <?php endfor; ?>
        <?php if ($page < $totalPages): ?>
          <li class="page-item"><a class="page-link" href="?page=<?= $page + 1 ?>">→</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const profileToggle = document.getElementById('profileToggle');
  const profileCard = document.getElementById('profileCard');
  profileToggle.addEventListener('click', () => {
    profileCard.style.display = profileCard.style.display === 'block' ? 'none' : 'block';
  });
  document.addEventListener('click', function(event) {
    if (!profileToggle.contains(event.target) && !profileCard.contains(event.target)) {
      profileCard.style.display = 'none';
    }
  });
</script>
</body>
</html>