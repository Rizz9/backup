<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
  header("Location: ../login/");
  exit;
}

$success = $error = '';
$postFile = '../data/posts.json';
$uploadDir = '../uploads/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $judul = trim($_POST['judul'] ?? '');
  $konten = trim($_POST['konten'] ?? '');
  $penulis = 'admin';
  $tanggal = date('Y-m-d');
  $gambarPath = '';

  if (!empty($_FILES['gambar']['name'])) {
    if (!is_dir($uploadDir)) {
      mkdir($uploadDir, 0755, true);
    }
    $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    $fileType = $_FILES['gambar']['type'];
    if (in_array($fileType, $allowedTypes)) {
      $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
      $newName = uniqid('img_', true) . '.' . $ext;
      $targetPath = $uploadDir . $newName;
      if (move_uploaded_file($_FILES['gambar']['tmp_name'], $targetPath)) {
        $gambarPath = 'uploads/' . $newName;
      } else {
        $error = "❌ Gagal upload gambar!";
      }
    } else {
      $error = "❌ Format gambar tidak didukung!";
    }
  }

  if (!$error) {
    $data = file_exists($postFile) ? json_decode(file_get_contents($postFile), true) : [];
    $data[] = [
      'judul' => $judul,
      'konten' => $konten,
      'gambar' => $gambarPath,
      'penulis' => $penulis,
      'tanggal' => $tanggal
    ];
    file_put_contents($postFile, json_encode($data, JSON_PRETTY_PRINT));
    $success = "✅ Postingan berhasil ditambahkan!";
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Postingan</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css">
  <style>
    .profile-icon {
      width: 32px; height: 32px;
      border-radius: 50%;
      background: url('https://i.pravatar.cc/32') no-repeat center/cover;
      border: 2px solid #dee2e6;
      position: relative;
    }
    .profile-icon.online::after {
      content: ''; width: 10px; height: 10px;
      background: limegreen; border: 2px solid #fff;
      border-radius: 50%; position: absolute;
      bottom: 0; right: 0;
    }
    #profileCard {
      animation: fadeInDown 0.3s ease-in-out;
    }
    @keyframes fadeInDown {
      0% { opacity: 0; transform: translateY(-10px); }
      100% { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body class="bg-light text-dark">
<nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm border-bottom">
  <div class="container-fluid d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center">
      <button class="navbar-toggler border border-dark me-2" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand fw-bold m-0 text-dark" href="index.php">Dashboard</a>
    </div>
    <div class="d-flex align-items-center gap-3">
      <div class="position-relative">
        <div class="profile-icon online" id="profileToggle" style="cursor: pointer;"></div>
        <div id="profileCard" class="card shadow-sm position-absolute end-0 mt-2" style="width: 220px; display: none; z-index: 999;">
          <div class="card-body text-center">
            <img src="https://i.pravatar.cc/80" class="rounded-circle mb-3" width="80" height="80" alt="Profile">
            <div class="d-grid gap-2">
              <a href="../login/ganti_username.php" class="btn btn-warning btn-sm">✏️ Ganti Username</a>
              <a href="../login/ganti_password.php" class="btn btn-danger btn-sm">🔐 Ganti Password</a>
              <a href="../login/logout.php" class="btn btn-outline-secondary btn-sm">🚪 Logout</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="tambah.php">➕ Tambah Postingan</a></li>
        <li class="nav-item"><a class="nav-link" href="kelola.php">🗂️ Kelola Postingan</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-5 mt-5">
  <h2 class="mb-4">📝 Tambah Postingan</h2>
  <?php if ($success): ?>
    <div class="alert alert-success"><?= $success ?></div>
  <?php elseif ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data" class="card shadow-sm p-4" data-aos="zoom-in">
    <div class="mb-3">
      <label for="judul" class="form-label">Judul</label>
      <input type="text" name="judul" id="judul" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Konten</label>
      <div class="d-flex gap-2 mb-2">
        <button type="button" class="btn btn-outline-primary btn-sm" id="btnBiasa">📝 Mode Biasa</button>
        <button type="button" class="btn btn-outline-dark btn-sm" id="btnCode">💻 Mode HTML</button>
      </div>

      <div id="htmlToolbar" class="mb-2" style="display: none;">
        <button type="button" class="btn btn-outline-secondary btn-sm" onclick="insertTag('<img src=&quot;&quot; alt=&quot;&quot;>', '')">🖼 Gambar</button>
        <button type="button" class="btn btn-outline-secondary btn-sm" onclick="insertTag('<a href=&quot;&quot;>', '</a>')">🔗 Link</button>
        <button type="button" class="btn btn-outline-secondary btn-sm" onclick="insertTag('<b>', '</b>')">🅱️ Bold</button>
        <button type="button" class="btn btn-outline-secondary btn-sm" onclick="insertTag('<i>', '</i>')">✏️ Italic</button>
      </div>

      <textarea id="kontenBiasa" class="form-control mb-2" rows="8" placeholder="Tulis artikel biasa..."></textarea>
      <textarea id="kontenHTML" class="form-control mb-2" rows="8" style="display: none; font-family: monospace;" placeholder="<p>Isi HTML di sini...</p>"></textarea>
      <input type="hidden" name="konten" id="kontenFinal">
    </div>

    <div class="mb-3">
      <label for="gambar" class="form-label">Upload Gambar</label>
      <input type="file" name="gambar" id="gambar" class="form-control" accept="image/*">
    </div>
    <button type="submit" class="btn btn-primary">Posting</button>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();

  const profileToggle = document.getElementById('profileToggle');
  const profileCard = document.getElementById('profileCard');
  profileToggle.addEventListener('click', () => {
    profileCard.style.display = profileCard.style.display === 'block' ? 'none' : 'block';
  });
  document.addEventListener('click', function(event) {
    if (!profileToggle.contains(event.target) && !profileCard.contains(event.target)) {
      profileCard.style.display = 'none';
    }
  });

  // Konten Mode
  const btnBiasa = document.getElementById('btnBiasa');
  const btnCode = document.getElementById('btnCode');
  const kontenBiasa = document.getElementById('kontenBiasa');
  const kontenHTML = document.getElementById('kontenHTML');
  const kontenFinal = document.getElementById('kontenFinal');
  const htmlToolbar = document.getElementById('htmlToolbar');

  let mode = 'biasa';

  btnBiasa.addEventListener('click', () => {
    mode = 'biasa';
    kontenBiasa.style.display = 'block';
    kontenHTML.style.display = 'none';
    htmlToolbar.style.display = 'none';
  });

  btnCode.addEventListener('click', () => {
    mode = 'html';
    kontenBiasa.style.display = 'none';
    kontenHTML.style.display = 'block';
    htmlToolbar.style.display = 'block';
  });

  document.querySelector('form').addEventListener('submit', function (e) {
    kontenFinal.value = mode === 'biasa' ? kontenBiasa.value : kontenHTML.value;
  });

  function insertTag(startTag, endTag) {
    const textarea = document.getElementById('kontenHTML');
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selected = textarea.value.substring(start, end);
    const before = textarea.value.substring(0, start);
    const after = textarea.value.substring(end);
    textarea.value = before + startTag + selected + endTag + after;
    textarea.focus();
    textarea.selectionEnd = start + startTag.length + selected.length + endTag.length;
  }
</script>
</body>
</html>