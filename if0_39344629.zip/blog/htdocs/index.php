<?php
$posts = file_exists('data/posts.json') ? json_decode(file_get_contents('data/posts.json'), true) : [];
$counterFile = 'data/counter.txt';

if (!file_exists($counterFile)) file_put_contents($counterFile, 1);
else {
  $count = intval(file_get_contents($counterFile)) + 1;
  file_put_contents($counterFile, $count);
}

$perPage = 6;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$total = count($posts);
$totalPages = ceil($total / $perPage);
$offset = ($page - 1) * $perPage;
$currentPosts = array_slice(array_reverse($posts), $offset, $perPage);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>RizDev - Home</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css">
  <style>
    .card-hover {
      transition: all 0.3s ease-in-out;
    }
    .card-hover:hover {
      transform: translateY(-5px);
      background-color: #f8f9fa;
      border-color: #0d6efd;
      box-shadow: 0 0 12px rgba(13, 110, 253, 0.3);
    }
    .profile-icon {
      width: 32px; height: 32px;
      border-radius: 50%;
      background: url('https://i.pravatar.cc/32') no-repeat center/cover;
      border: 2px solid #dee2e6;
      position: relative;
    }
    .profile-icon.online::after {
      content: ''; width: 10px; height: 10px;
      background: limegreen; border: 2px solid #fff;
      border-radius: 50%;
      position: absolute; bottom: 0; right: 0;
    }
    .notif-animate {
      animation: pulse 1.2s infinite;
    }
    @keyframes pulse {
      0% { transform: scale(1); color: red; }
      50% { transform: scale(1.2); color: #dc3545; }
      100% { transform: scale(1); color: red; }
    }
    /* Splash screen */
    #splash {
      position: fixed;
      background: white;
      top: 0; left: 0; right: 0; bottom: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 2000;
    }
  </style>
</head>
<body class="bg-light text-dark">

<!-- Splash screen -->
<div id="splash">
  <div class="text-center">
    <div class="spinner-border text-primary mb-3" style="width: 3rem; height: 3rem;" role="status"></div>
    <h5>Loading RizDev...</h5>
  </div>
</div>

<!-- 🔝 Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm border-bottom">
  <div class="container-fluid">

    <!-- Brand + Hamburger -->
    <div class="d-flex align-items-center justify-content-between w-100">
      <div class="d-flex align-items-center">
        <button class="btn btn-outline-secondary d-lg-none me-2" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
          <i class="bi bi-list" style="font-size: 1.5rem;"></i>
        </button>
        <a class="navbar-brand fw-bold m-0 text-dark" href="#">RizDev</a>
      </div>

      <!-- Icon Bell + Profile -->
      <div class="d-flex align-items-center gap-3 position-relative">
        <i class="bi bi-bell-fill text-dark notif-animate" data-bs-toggle="modal" data-bs-target="#notifModal" style="cursor: pointer;"></i>
        <div class="profile-icon online" id="profileToggle" style="cursor: pointer;"></div>
        <div id="profileCard" class="card shadow-sm position-absolute end-0 mt-2" style="width: 220px; top: 100%; display: none; z-index: 999;">
          <div class="card-body text-center">
            <img src="https://i.pravatar.cc/80" class="rounded-circle mb-3" width="80" height="80" alt="Profile">
            <div class="d-grid gap-2">
              <?php if ($login): ?>
                <a href="admin/logout.php" class="btn btn-outline-secondary btn-sm">
                  <i class="bi bi-box-arrow-right"></i> Logout
                </a>
              <?php else: ?>
                <a href="login" class="btn btn-primary btn-sm">
                  <i class="bi bi-box-arrow-in-right"></i> Login
                </a>
              <?php endif; ?>
              <a href="https://wa.me/6287776353541" class="btn btn-success btn-sm">
                <i class="bi bi-whatsapp"></i> WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Menu collapsible ke bawah -->
    <div class="collapse navbar-collapse mt-3" id="mainNav">
      <ul class="navbar-nav flex-column text-start w-100">
        <li class="nav-item">
          <a class="nav-link" href="https://rizxdev.ct.ws">
            <i class="bi bi-tools"></i> Tools Online
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="https://rizxdev.ct.ws/upl">
            <i class="bi bi-upload"></i> Uploader
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!-- 📰 Konten utama -->
<div class="container mt-5 pt-5">
  <div class="row">
    <?php if (empty($currentPosts)): ?>
      <div class="alert alert-info">Belum ada postingan.</div>
    <?php else: ?>
      <?php foreach ($currentPosts as $index => $post): ?>
        <div class="col-md-4 mb-4" data-aos="fade-up">
          <div class="card post-card h-100 card-hover">
            <?php if (!empty($post['gambar'])): ?>
              <img src="<?= htmlspecialchars($post['gambar']) ?>" class="img-fluid rounded-top" style="max-height:200px; object-fit:cover;" alt="Thumbnail">
            <?php endif; ?>
            <div class="card-body d-flex flex-column">
              <h5 class="card-title"><?= htmlspecialchars($post['judul'] ?? '-') ?></h5>
              <h6 class="card-subtitle mb-2 text-muted">
                Post by <?= htmlspecialchars($post['penulis'] ?? 'Unknown') ?> <i class="bi bi-patch-check-fill text-primary"></i><br>
                <?= date('d F Y', strtotime($post['tanggal'] ?? '')) ?>
              </h6>
   <p class="card-text">   Baca Selengkapnya....</p>          
              <a href="post.php?id=<?= $total - $offset - $index - 1 ?>" class="btn btn-primary btn-sm mt-auto">Read More</a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- 🔢 Pagination -->
  <?php if ($totalPages > 1): ?>
    <nav class="mt-4">
      <ul class="pagination justify-content-center">
        <?php if ($page > 1): ?>
          <li class="page-item"><a class="page-link" href="?page=<?= $page - 1 ?>">←</a></li>
        <?php endif; ?>
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
          <li class="page-item <?= $p === $page ? 'active' : '' ?>">
            <a class="page-link" href="?page=<?= $p ?>"><?= $p ?></a>
          </li>
        <?php endfor; ?>
        <?php if ($page < $totalPages): ?>
          <li class="page-item"><a class="page-link" href="?page=<?= $page + 1 ?>">→</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  <?php endif; ?>
</div>

<!-- 📢 MODAL Notifikasi -->
<div class="modal fade" id="notifModal" tabindex="-1" aria-labelledby="notifLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content shadow">
      <div class="modal-header">
        <h5 class="modal-title" id="notifLabel">📢 Update Info</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body">
        <p><strong>Update Source:</strong> 29 - June - 2025</p>
        <hr>
        <a href="https://wa.me/6287776353541" class="btn btn-success w-100">📦 Lihat Source Code</a>
      </div>
    </div>
  </div>
</div>

<footer class="footer bg-white text-center text-muted py-3 border-top mt-auto">
  © <?= date('Y') ?> RizDev
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();

  // Splash screen auto hide
  window.addEventListener('load', function() {
    setTimeout(() => {
      document.getElementById('splash').style.display = 'none';
    }, 1500);
  });

  // Profile toggle
  const profileToggle = document.getElementById('profileToggle');
  const profileCard = document.getElementById('profileCard');
  profileToggle.addEventListener('click', () => {
    profileCard.style.display = profileCard.style.display === 'block' ? 'none' : 'block';
  });
  document.addEventListener('click', function(event) {
    if (!profileToggle.contains(event.target) && !profileCard.contains(event.target)) {
      profileCard.style.display = 'none';
    }
  });
</script>
</body>
</html>