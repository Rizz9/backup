<?php
session_start();

$configPath = __DIR__ . '/data/config.json';
$config = file_exists($configPath) ? json_decode(file_get_contents($configPath), true) : [];
$isAdmin = isset($_SESSION['admin']) && $_SESSION['admin'] === true;
$adminName = $config['username'] ?? 'OWNER';

$chatFile = 'pesan.json';
if (!file_exists($chatFile)) file_put_contents($chatFile, '[]');

// Kirim pesan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $pesan = trim($_POST['pesan'] ?? '');

    if ($nama && $pesan) {
        $_SESSION['chat_nama'] = $nama; // Simpan nama di session
        $data = json_decode(file_get_contents($chatFile), true);
        $data[] = [
            'nama' => $nama,
            'pesan' => $pesan,
            'waktu' => date('Y-m-d H:i:s'),
            'is_admin' => ($isAdmin && $nama === $adminName)
        ];
        file_put_contents($chatFile, json_encode($data, JSON_PRETTY_PRINT));
        header('Location: forum.php');
        exit;
    }
}

// Ambil data chat (terbaru di atas)
$data = array_reverse(json_decode(file_get_contents($chatFile), true));
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>💬 Chat</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light text-dark p-4">
<div class="container">
  <h4>💬 Chat</h4>
  <div class="card p-3 mb-3">
    <?php foreach ($data as $d): ?>
      <div class="border-bottom pb-2 mb-2">
        <strong>
          <?= htmlspecialchars($d['nama'] ?? '') ?>
          <?php if (!empty($d['is_admin'])): ?>
            <svg xmlns="http://www.w3.org/2000/svg" width="14" fill="blue" viewBox="0 0 16 16">
              <path d="M16 8a8 8 0 1 0-9.25 7.9.5.5 0 0 0 .41-.49V12.5a.5.5 0 0 1 .5-.5H10a.5.5 0 0 1 .5.5v2.91a.5.5 0 0 0 .41.49A8 8 0 0 0 16 8zM6.354 9.854a.5.5 0 0 1-.708 0L4.5 8.707l-.646.647a.5.5 0 1 1-.708-.708l1-1a.5.5 0 0 1 .708 0L6 9.146l2.646-2.647a.5.5 0 0 1 .708.708l-3 3z"/>
            </svg>
          <?php endif ?>
          [<?= $d['waktu'] ?>]
        </strong><br>
        <?= nl2br(htmlspecialchars($d['pesan'] ?? '')) ?>
      </div>
    <?php endforeach ?>
  </div>

  <!-- Form kirim -->
  <form method="post">
    <input class="form-control mb-2" name="nama" placeholder="Nama Anda" value="<?= htmlspecialchars($_SESSION['chat_nama'] ?? '') ?>" required>
    <textarea class="form-control mb-2" name="pesan" placeholder="Tulis pesan..." required></textarea>
    <button class="btn btn-primary">Kirim</button>
  </form>
</div>
</body>
</html>