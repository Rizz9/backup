<?php
$allowed_ext = ['txt', 'html'];
$base_dir = __DIR__ . '/';
$config_path = "../data/config.json";

function formatSize($size) {
    if ($size >= 1048576) return round($size / 1048576, 2) . ' MB';
    if ($size >= 1024) return round($size / 1024, 2) . ' KB';
    return $size . ' B';
}

// Baca config
if (!file_exists($config_path)) die("⚠️ config.json tidak ditemukan.");
$config = json_decode(file_get_contents($config_path), true);
if (!isset($config['max_upload_kb'])) die("⚠️ max_upload_kb tidak ditemukan di config.json.");
$max_size = (int)$config['max_upload_kb'] * 1024;

// Buat folder otomatis
@mkdir("../open", 0775, true);
@mkdir("../raw", 0775, true);
@mkdir("../download", 0775, true);

// Upload handler
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_FILES)) {
        echo "Upload gagal: ukuran file melebihi batas server (php.ini)";
        exit;
    }

    $f = $_FILES['file'];
    $name = basename($f['name']);
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $path = $base_dir . $name;

    if (!in_array($ext, $allowed_ext)) {
        echo "Gagal $name gagal bukan file html itu jink";
        exit;
    }

    if ($f['size'] > $max_size) {
        echo "File $name ga bisa upload ke gedean";
        exit;
    }

    if (move_uploaded_file($f['tmp_name'], $path)) {
        // copy ke open
        copy($path, "../open/$name");

        // copy ke raw sebagai .txt
        $namafile_txt = pathinfo($name, PATHINFO_FILENAME) . ".txt";
        copy($path, "../raw/$namafile_txt");

        // copy ke download
        copy($path, "../download/$name");

        echo "OK";
    } else {
        echo "Gagal upload $name";
    }
    exit;
}

// Ambil daftar file
$files = array_filter(scandir($base_dir), function($f) use ($base_dir) {
    return is_file($base_dir . $f) && preg_match('/\.(html|txt)$/i', $f);
});
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>📁 RizxDev Uploader</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-gray-100">
<div class="max-w-6xl mx-auto py-10 px-4">
  <h1 class="text-4xl font-bold text-center mb-6">📁 RizxDev Uploader</h1>

  <!-- Upload -->
  <form id="uploadForm" class="border-4 border-dashed border-blue-400 p-8 rounded-xl text-center bg-white shadow hover:bg-blue-50 cursor-pointer mb-8">
    <input type="file" id="fileInput" class="hidden" />
    <p class="text-lg">Drag & Drop file .txt / .html atau klik</p>
    <p class="text-sm text-gray-500">Ukuran maksimal: <?= round($max_size / 1024) ?>KB</p>
    <div id="uploadStatus" class="mt-4 text-blue-600 font-semibold hidden">⏳ Mengupload...</div>
  </form>

  <!-- Search -->
  <div class="mb-4">
    <input type="text" id="searchInput" placeholder="🔍 Cari file..." class="w-full sm:w-1/2 p-3 border rounded shadow" />
  </div>

  <!-- Table Card -->
  <table class="w-full bg-white rounded-xl shadow text-left">
    <thead>
      <tr class="bg-blue-200">
        <th class="p-3">📄 Nama File</th>
        <th class="p-3">Ukuran</th>
        <th class="p-3">Tanggal</th>
        <th class="p-3">Aksi</th>
      </tr>
    </thead>
    <tbody id="fileTable">
      <?php foreach ($files as $file):
        $size = formatSize(filesize($base_dir . $file));
        $date = date("d M Y - H:i", filemtime($base_dir . $file));
        $nameNoExt = pathinfo($file, PATHINFO_FILENAME);
        $ext = pathinfo($file, PATHINFO_EXTENSION);
      ?>
      <tr class="border-t hover:bg-gray-100 file-row" data-name="<?= strtolower($file) ?>">
        <td class="p-3"><?= htmlspecialchars($file) ?></td>
        <td class="p-3"><?= $size ?></td>
        <td class="p-3"><?= $date ?></td>
        <td class="p-3 space-x-2">
          <a href="../open/<?= urlencode($file) ?>" target="_blank" class="bg-blue-500 text-white px-3 py-1 rounded">Open</a>
          <a href="../raw/<?= urlencode($nameNoExt . ".txt") ?>" target="_blank" class="bg-gray-700 text-white px-3 py-1 rounded">Raw</a>
          <a href="../download/<?= urlencode($file) ?>" target="_blank" class="bg-gray-700 text-white px-3 py-1 rounded">Download</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- Pagination -->
  <div id="pagination" class="mt-6 flex justify-center space-x-2"></div>
</div>

<!-- Modal -->
<div class="modal fade" id="resultModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content rounded shadow">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title">📢 Notifikasi</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body text-center text-lg" id="modalMessage">...</div>
      <div class="modal-footer justify-center">
        <button type="button" class="btn btn-primary px-4" data-bs-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>

<script>
const fileInput = document.getElementById("fileInput");
const uploadForm = document.getElementById("uploadForm");
const uploadStatus = document.getElementById("uploadStatus");

uploadForm.addEventListener("click", () => fileInput.click());
uploadForm.addEventListener("dragover", e => {
  e.preventDefault(); uploadForm.classList.add("bg-blue-100");
});
uploadForm.addEventListener("dragleave", () => {
  uploadForm.classList.remove("bg-blue-100");
});
uploadForm.addEventListener("drop", e => {
  e.preventDefault(); uploadForm.classList.remove("bg-blue-100");
  fileInput.files = e.dataTransfer.files; handleUpload();
});
fileInput.addEventListener("change", handleUpload);

function showModal(msg) {
  document.getElementById("modalMessage").textContent = msg;
  new bootstrap.Modal(document.getElementById("resultModal")).show();
}

function handleUpload() {
  const file = fileInput.files[0];
  if (!file) return;

  const ext = file.name.split('.').pop().toLowerCase();
  const allowed = ["txt", "html"];
  if (!allowed.includes(ext)) {
    showModal(`Gagal ${file.name} gagal bukan file html itu jink`);
    return;
  }
  if (file.size > <?= $max_size ?>) {
    showModal(`File ${file.name} ga bisa upload ke gedean`);
    return;
  }

  const formData = new FormData();
  formData.append("file", file);
  uploadStatus.classList.remove("hidden");

  fetch("", { method: "POST", body: formData })
    .then(res => res.text())
    .then(res => {
      uploadStatus.classList.add("hidden");
      if (res.trim() === "OK") {
        showModal(`File ${file.name} sukses diupload`);
        setTimeout(() => location.reload(), 1500);
      } else {
        showModal(res);
      }
    })
    .catch(() => {
      uploadStatus.classList.add("hidden");
      showModal("❌ Upload gagal!");
    });
}

// Search
document.getElementById("searchInput").addEventListener("input", function () {
  const q = this.value.toLowerCase();
  document.querySelectorAll(".file-row").forEach(row => {
    const name = row.getAttribute("data-name");
    row.style.display = name.includes(q) ? "" : "none";
  });
});

// Pagination
const rowsPerPage = 6;
const table = document.getElementById("fileTable");
const rows = table.querySelectorAll(".file-row");
const pagination = document.getElementById("pagination");
let currentPage = 1;

function showPage(page) {
  currentPage = page;
  let start = (page - 1) * rowsPerPage;
  let end = start + rowsPerPage;
  rows.forEach((row, i) => {
    row.style.display = (i >= start && i < end) ? "" : "none";
  });
  updatePagination();
}

function updatePagination() {
  let totalPages = Math.ceil(rows.length / rowsPerPage);
  pagination.innerHTML = "";
  for (let i = 1; i <= totalPages; i++) {
    const btn = document.createElement("button");
    btn.textContent = i;
    btn.className = "px-3 py-1 rounded " + (i === currentPage ? "bg-blue-600 text-white" : "bg-gray-200");
    btn.onclick = () => showPage(i);
    pagination.appendChild(btn);
  }
}
showPage(1);
</script>
</body>
</html>